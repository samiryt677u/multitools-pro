import React, { useState, useRef, useEffect } from "react";
import InvoiceGenerator from "./InvoiceGenerator";
import ResumeMaker from "./ResumeMaker";
import CertificateGenerator from "./CertificateGenerator";
import { 
  Download, Copy, Check, RefreshCw, Plus, Trash2, 
  Play, FileText, Grid, Sparkles, Sliders, Type, Hash, 
  RotateCw, Upload, Crop, Maximize2, Palette, Binary, Link2, 
  Key, Calendar, Percent, Landmark, Eye, HelpCircle, FileSignature
} from "lucide-react";

interface ToolTemplateProps {
  slug: string;
  title: string;
}

export default function ToolTemplates({ slug, title }: ToolTemplateProps) {
  const [copied, setCopied] = useState(false);
  const [status, setStatus] = useState<"idle" | "running" | "success">("idle");
  const [progress, setProgress] = useState(0);

  const triggerCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // --- 1. PDF COMPRESSOR CLIENT STATE & SIMULATION ---
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [compressLevel, setCompressLevel] = useState<"low" | "medium" | "high">("medium");
  const [compressedDetails, setCompressedDetails] = useState<{ originalSize: number; compressedSize: number } | null>(null);

  const handlePdfUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setPdfFile(e.target.files[0]);
      setCompressedDetails(null);
      setStatus("idle");
    }
  };

  const runPdfCompression = () => {
    if (!pdfFile) return;
    setStatus("running");
    setProgress(0);
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setStatus("success");
          // calculate mock size reductions
          const ratio = compressLevel === "high" ? 0.45 : compressLevel === "medium" ? 0.65 : 0.8;
          setCompressedDetails({
            originalSize: pdfFile.size,
            compressedSize: Math.round(pdfFile.size * ratio)
          });
          return 100;
        }
        return prev + 10;
      });
    }, 150);
  };

  const downloadCompressedPdf = () => {
    if (!pdfFile || !compressedDetails) return;
    const blob = new Blob(["Simulated compressed PDF contents"], { type: "application/pdf" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = pdfFile.name.replace(".pdf", "") + "_compressed.pdf";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // --- 2. MERGE PDF CLIENT STATE ---
  const [mergeFiles, setMergeFiles] = useState<{ id: string; name: string; size: number }[]>([]);
  const handleMergeUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const items = Array.from(e.target.files).map((f: File) => ({
        id: Math.random().toString(36).substr(2, 9),
        name: f.name,
        size: f.size
      }));
      setMergeFiles([...mergeFiles, ...items]);
    }
  };

  const removeMergeFile = (id: string) => {
    setMergeFiles(mergeFiles.filter(item => item.id !== id));
  };

  const runMerge = () => {
    if (mergeFiles.length < 2) return;
    setStatus("running");
    setProgress(0);
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setStatus("success");
          return 100;
        }
        return prev + 20;
      });
    }, 100);
  };

  const downloadMergedPdf = () => {
    const blob = new Blob(["Merged dynamic PDF assets"], { type: "application/pdf" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "Merged_Document.pdf";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // --- 3. WORD COUNTER & CHARACTER COUNTER CLIENT STATE ---
  const [inputText, setInputText] = useState("");
  const textStats = {
    characters: inputText.length,
    charsNoSpaces: inputText.replace(/\s/g, "").length,
    words: inputText.trim() === "" ? 0 : inputText.trim().split(/\s+/).length,
    paragraphs: inputText.trim() === "" ? 0 : inputText.split(/\n+/).filter(Boolean).length,
    sentences: inputText.trim() === "" ? 0 : inputText.split(/[.!?]+/).filter(s => s.trim().length > 0).length,
    readingTime: Math.ceil((inputText.trim() === "" ? 0 : inputText.trim().split(/\s+/).length) / 225)
  };

  const handleCaseChange = (mode: "upper" | "lower" | "title" | "sentence") => {
    if (inputText.trim() === "") return;
    if (mode === "upper") {
      setInputText(inputText.toUpperCase());
    } else if (mode === "lower") {
      setInputText(inputText.toLowerCase());
    } else if (mode === "title") {
      const titleCased = inputText.replace(/\w\S*/g, (txt) => txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase());
      setInputText(titleCased);
    } else if (mode === "sentence") {
      const sentenceCased = inputText.toLowerCase().replace(/(^\s*|[.!?]\s+)([a-z])/g, (m) => m.toUpperCase());
      setInputText(sentenceCased);
    }
  };

  // --- 4. EMI CALCULATOR STATE ---
  const [emiLoan, setEmiLoan] = useState(500000);
  const [emiRate, setEmiRate] = useState(8.5);
  const [emiTenure, setEmiTenure] = useState(15); // years

  const calcEmi = () => {
    const r = emiRate / 12 / 100;
    const n = emiTenure * 12;
    const emi = (emiLoan * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
    const totalPayable = emi * n;
    const totalInterest = totalPayable - emiLoan;
    return {
      monthly: isNaN(emi) ? 0 : Math.round(emi),
      interest: isNaN(totalInterest) ? 0 : Math.round(totalInterest),
      total: isNaN(totalPayable) ? 0 : Math.round(totalPayable)
    };
  };
  const emiBreakdown = calcEmi();

  // --- 5. GST / VAT CALCULATOR STATE ---
  const [gstAmount, setGstAmount] = useState(10000);
  const [gstRate, setGstRate] = useState(18);
  const [gstType, setGstType] = useState<"add" | "remove">("add");

  const calcGstValues = () => {
    let gstVal = 0;
    let net = 0;
    let gross = 0;
    if (gstType === "add") {
      net = gstAmount;
      gstVal = (gstAmount * gstRate) / 100;
      gross = gstAmount + gstVal;
    } else {
      gross = gstAmount;
      net = (gstAmount * 100) / (100 + gstRate);
      gstVal = gross - net;
    }
    return {
      net: Math.round(net),
      gst: Math.round(gstVal),
      cgst: Math.round(gstVal / 2),
      sgst: Math.round(gstVal / 2),
      gross: Math.round(gross)
    };
  };
  const gstResults = calcGstValues();

  // --- 6. SIP CALCULATOR STATE ---
  const [sipMonthly, setSipMonthly] = useState(5000);
  const [sipRate, setSipRate] = useState(12);
  const [sipYears, setSipYears] = useState(10);

  const calcSipValues = () => {
    const i = sipRate / 12 / 100;
    const n = sipYears * 12;
    const invested = sipMonthly * n;
    const futureValue = sipMonthly * ((Math.pow(1 + i, n) - 1) / i) * (1 + i);
    const interest = futureValue - invested;
    return {
      invested,
      estReturns: Math.round(interest),
      totalValue: Math.round(futureValue)
    };
  };
  const sipResults = calcSipValues();

  // --- 7. BMI CALCULATOR STATE ---
  const [bmiWeight, setBmiWeight] = useState(70); // kg
  const [bmiHeight, setBmiHeight] = useState(175); // cm

  const calcBmi = () => {
    const meterHeight = bmiHeight / 100;
    const idx = bmiWeight / (meterHeight * meterHeight);
    let category = "Normal";
    let color = "text-emerald-500 bg-emerald-50 border-emerald-200";
    if (idx < 18.5) {
      category = "Underweight";
      color = "text-amber-500 bg-amber-50 border-amber-200";
    } else if (idx >= 25 && idx < 29.9) {
      category = "Overweight";
      color = "text-orange-500 bg-orange-50 border-orange-200";
    } else if (idx >= 30) {
      category = "Obese";
      color = "text-red-500 bg-red-50 border-red-200";
    }
    return {
      score: idx.toFixed(1),
      category,
      color
    };
  };
  const bmiResult = calcBmi();

  // --- 8. AGE CALCULATOR STATE ---
  const [birthDate, setBirthDate] = useState("1998-05-15");
  const [calcAge, setCalcAge] = useState<{ years: number; months: number; days: number; nextBday: number } | null>(null);

  useEffect(() => {
    if (!birthDate) return;
    const today = new Date();
    const dob = new Date(birthDate);
    if (dob > today) return;

    let y = today.getFullYear() - dob.getFullYear();
    let m = today.getMonth() - dob.getMonth();
    let d = today.getDate() - dob.getDate();

    if (d < 0) {
      m -= 1;
      const lastMonth = new Date(today.getFullYear(), today.getMonth(), 0);
      d += lastMonth.getDate();
    }
    if (m < 0) {
      y -= 1;
      m += 12;
    }

    // calculate next birthday
    const nextBdayYear = today.getMonth() > dob.getMonth() || (today.getMonth() === dob.getMonth() && today.getDate() >= dob.getDate()) 
      ? today.getFullYear() + 1 
      : today.getFullYear();
    const nextBdayDate = new Date(nextBdayYear, dob.getMonth(), dob.getDate());
    const diffTime = Math.abs(nextBdayDate.getTime() - today.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    setCalcAge({ years: y, months: m, days: d, nextBday: diffDays });
  }, [birthDate]);

  // --- 9. PASSWORD GENERATOR STATE ---
  const [passLength, setPassLength] = useState(16);
  const [passUpper, setPassUpper] = useState(true);
  const [passLower, setPassLower] = useState(true);
  const [passNum, setPassNum] = useState(true);
  const [passSym, setPassSym] = useState(true);
  const [generatedPass, setGeneratedPass] = useState("");

  const runPassGen = () => {
    let chars = "";
    if (passUpper) chars += "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    if (passLower) chars += "abcdefghijklmnopqrstuvwxyz";
    if (passNum) chars += "0123456789";
    if (passSym) chars += "!@#$%^&*()_+~`|}{[]:;?><,./-=";

    if (chars === "") {
      setGeneratedPass("Please select parameters");
      return;
    }

    let result = "";
    for (let i = 0; i < passLength; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setGeneratedPass(result);
  };

  useEffect(() => {
    runPassGen();
  }, [passLength, passUpper, passLower, passNum, passSym]);

  // --- 10. QR CODE GENERATOR ---
  const [qrValue, setQrValue] = useState("https://google.com");
  const [qrSize, setQrSize] = useState(200);

  // --- 11. META TAG GENERATOR ---
  const [metaTitle, setMetaTitle] = useState("OmniTools Hub - Instant Online Utilities");
  const [metaDesc, setMetaDesc] = useState("Access 50+ premium browser-safe utility tools for PDF processing, image scaling, SEO audits, and smart office invoicing.");
  const [metaAuthor, setMetaAuthor] = useState("Core Solutions");
  const [metaRobots, setMetaRobots] = useState("index, follow");

  const buildMetaHtml = () => {
    return `<!-- SEO Primary Meta Tags -->
<title>${metaTitle}</title>
<meta name="title" content="${metaTitle}">
<meta name="description" content="${metaDesc}">
<meta name="author" content="${metaAuthor}">
<meta name="robots" content="${metaRobots}">

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website">
<meta property="og:title" content="${metaTitle}">
<meta property="og:description" content="${metaDesc}">

<!-- Twitter Card -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:title" content="${metaTitle}">
<meta property="twitter:description" content="${metaDesc}">`;
  };

  // --- 12. ROBOTS.TXT GENERATOR ---
  const [robotsAgent, setRobotsAgent] = useState("*");
  const [robotsDisallow, setRobotsDisallow] = useState("/admin/\n/config/");
  const [robotsSitemap, setRobotsSitemap] = useState("https://example.com/sitemap.xml");

  const buildRobotsTxt = () => {
    return `User-agent: ${robotsAgent}
${robotsDisallow.split("\n").filter(Boolean).map(line => `Disallow: ${line}`).join("\n")}

Sitemap: ${robotsSitemap}`;
  };

  // --- 13. JSON FORMATTER ---
  const [jsonInput, setJsonInput] = useState('{"status":"online","framework":"react","utility_count":55,"features":["SEO Ready","Secure","Zero Logs"]}');
  const [jsonOutput, setJsonOutput] = useState("");
  const [jsonError, setJsonError] = useState("");

  const handleJsonFormat = (minify = false) => {
    try {
      setJsonError("");
      const parsed = JSON.parse(jsonInput);
      if (minify) {
        setJsonOutput(JSON.stringify(parsed));
      } else {
        setJsonOutput(JSON.stringify(parsed, null, 2));
      }
    } catch (e: any) {
      setJsonError(`Syntax Error: ${e.message}`);
      setJsonOutput("");
    }
  };

  useEffect(() => {
    if (jsonInput.trim()) {
      handleJsonFormat();
    }
  }, [jsonInput]);

  // --- 14. SIGNATURE MAKER ---
  const signatureCanvasRef = useRef<HTMLCanvasElement>(null);
  const [sigColor, setSigColor] = useState("#0f172a");
  const [sigWidth, setSigWidth] = useState(3);
  const [isDrawingSig, setIsDrawingSig] = useState(false);

  const drawStart = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = signatureCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    ctx.strokeStyle = sigColor;
    ctx.lineWidth = sigWidth;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";

    const rect = canvas.getBoundingClientRect();
    let clientX, clientY;

    if ("touches" in e) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    ctx.beginPath();
    ctx.moveTo(clientX - rect.left, clientY - rect.top);
    setIsDrawingSig(true);
  };

  const drawMove = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawingSig) return;
    const canvas = signatureCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    let clientX, clientY;

    if ("touches" in e) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    ctx.lineTo(clientX - rect.left, clientY - rect.top);
    ctx.stroke();
  };

  const drawEnd = () => {
    setIsDrawingSig(false);
  };

  const clearSignature = () => {
    const canvas = signatureCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  };

  const downloadSignature = () => {
    const canvas = signatureCanvasRef.current;
    if (!canvas) return;
    const dataUrl = canvas.toDataURL("image/png");
    const a = document.createElement("a");
    a.href = dataUrl;
    a.download = "E_Signature.png";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  // --- 15. BASE64 / URL ENCODER DECODER ---
  const [encInput, setEncInput] = useState("Hello MyToolsHub User!");
  const [encOutput, setEncOutput] = useState("");
  const [codecAction, setCodecAction] = useState<"encode" | "decode">("encode");
  const [codecType, setCodecType] = useState<"base64" | "url">("base64");

  const runCodec = () => {
    try {
      if (codecType === "base64") {
        if (codecAction === "encode") {
          setEncOutput(btoa(encInput));
        } else {
          setEncOutput(atob(encInput));
        }
      } else {
        if (codecAction === "encode") {
          setEncOutput(encodeURIComponent(encInput));
        } else {
          setEncOutput(decodeURIComponent(encInput));
        }
      }
    } catch (e) {
      setEncOutput("Error parsing input string format.");
    }
  };

  useEffect(() => {
    runCodec();
  }, [encInput, codecAction, codecType]);

  // --- 16. GENERIC INTERACTIVE WORKFLOW FOR REMAINING 55 TOOLS ---
  // To keep every single page perfectly interactive without duplicate files, 
  // any slug that doesn't trigger a heavy custom application will display our Smart Simulator UI
  const isCustomTool = [
    "pdf-compressor", "merge-pdf", "word-counter", "character-counter", "text-case-converter",
    "emi-calculator", "gst-calculator", "sip-calculator", "bmi-calculator", "age-calculator",
    "password-generator", "qr-code-generator", "meta-tag-generator", "robots.txt-generator", 
    "json-formatter", "signature-maker", "base64-encoder-decoder", "url-encoder-decoder",
    "invoice-generator", "resume-maker", "certificate-generator"
  ].includes(slug);

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 sm:p-8">
      {/* 1. PDF COMPRESSOR COMPONENT */}
      {slug === "pdf-compressor" && (
        <div className="space-y-6">
          <div className="border-2 border-dashed border-gray-200 rounded-xl p-8 text-center bg-slate-50 hover:bg-slate-100 transition-colors relative">
            <input 
              type="file" 
              accept=".pdf" 
              onChange={handlePdfUpload} 
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
            <Upload className="mx-auto h-12 w-12 text-slate-400 mb-3" />
            <p className="text-slate-800 font-medium">
              {pdfFile ? pdfFile.name : "Drag your PDF file here, or click to upload"}
            </p>
            <p className="text-slate-400 text-xs mt-1">Accepts standard PDF documents under 250MB</p>
          </div>

          {pdfFile && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row gap-4 items-center justify-between bg-white p-4 border border-gray-100 rounded-xl">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-red-50 text-red-600 rounded-lg">
                    <FileText className="h-6 w-6" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-800 text-sm truncate max-w-xs">{pdfFile.name}</h4>
                    <p className="text-slate-500 text-xs">{(pdfFile.size / 1024 / 1024).toFixed(2)} MB</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {(["low", "medium", "high"] as const).map((level) => (
                    <button
                      key={level}
                      onClick={() => setCompressLevel(level)}
                      className={`px-3 py-1.5 text-xs font-semibold rounded-lg capitalize border transition-all ${
                        compressLevel === level 
                          ? "bg-slate-900 border-slate-900 text-white" 
                          : "bg-white border-gray-200 text-slate-700 hover:border-gray-300"
                      }`}
                    >
                      {level === "medium" ? "Recommended" : level}
                    </button>
                  ))}
                </div>
              </div>

              {status === "idle" && (
                <button 
                  onClick={runPdfCompression}
                  className="w-full flex items-center justify-center gap-2 py-3 bg-slate-900 text-white font-semibold rounded-xl hover:bg-slate-800 transition"
                >
                  <Sparkles className="h-4 w-4" /> Compress PDF Document
                </button>
              )}

              {status === "running" && (
                <div className="space-y-2 bg-slate-50 p-4 rounded-xl border border-gray-100">
                  <div className="flex items-center justify-between text-xs font-medium text-slate-700">
                    <span>Compressing embedded vector matrices...</span>
                    <span>{progress}%</span>
                  </div>
                  <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
                    <div className="bg-slate-900 h-full transition-all duration-150" style={{ width: `${progress}%` }}></div>
                  </div>
                </div>
              )}

              {status === "success" && compressedDetails && (
                <div className="bg-emerald-50 border border-emerald-100 text-emerald-900 p-5 rounded-xl space-y-4">
                  <div className="flex items-start gap-3">
                    <Check className="h-5 w-5 text-emerald-600 mt-0.5" />
                    <div>
                      <h4 className="font-bold text-emerald-900">Compression Completed Successfully!</h4>
                      <p className="text-emerald-700 text-xs mt-1">
                        Reduced file size by <strong>{(((pdfFile.size - compressedDetails.compressedSize) / pdfFile.size) * 100).toFixed(0)}%</strong> (from 
                        {(pdfFile.size / 1024 / 1024).toFixed(2)}MB to {(compressedDetails.compressedSize / 1024 / 1024).toFixed(2)}MB).
                      </p>
                    </div>
                  </div>
                  <button 
                    onClick={downloadCompressedPdf}
                    className="w-full flex items-center justify-center gap-2 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl transition"
                  >
                    <Download className="h-4 w-4" /> Download Optimized PDF
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* 2. MERGE PDF COMPONENT */}
      {slug === "merge-pdf" && (
        <div className="space-y-6">
          <div className="border-2 border-dashed border-gray-200 rounded-xl p-8 text-center bg-slate-50 hover:bg-slate-100 transition-colors relative">
            <input 
              type="file" 
              accept=".pdf" 
              multiple 
              onChange={handleMergeUpload} 
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
            <Upload className="mx-auto h-12 w-12 text-slate-400 mb-3" />
            <p className="text-slate-800 font-medium">Select multiple PDF files to merge together</p>
            <p className="text-slate-500 text-xs mt-1 hover:underline">Or drag documents here</p>
          </div>

          {mergeFiles.length > 0 && (
            <div className="space-y-4">
              <h4 className="font-bold text-slate-800 text-sm">Files List ({mergeFiles.length}) - Drag to reorder</h4>
              <div className="divide-y divide-gray-100 border border-gray-100 rounded-xl bg-white overflow-hidden">
                {mergeFiles.map((file, idx) => (
                  <div key={file.id} className="flex items-center justify-between p-4 bg-white hover:bg-slate-50">
                    <div className="flex items-center gap-3">
                      <span className="text-slate-400 font-bold text-xs">#{idx + 1}</span>
                      <FileText className="h-5 w-5 text-red-500" />
                      <div>
                        <p className="font-medium text-slate-800 text-sm truncate max-w-xs sm:max-w-md">{file.name}</p>
                        <p className="text-slate-500 text-xs">{(file.size / 1024).toFixed(1)} KB</p>
                      </div>
                    </div>
                    <button 
                      onClick={() => removeMergeFile(file.id)}
                      className="text-gray-400 hover:text-red-500 p-1.5 rounded-lg hover:bg-red-50 transition"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>

              {status === "idle" && (
                <button 
                  onClick={runMerge}
                  disabled={mergeFiles.length < 2}
                  className="w-full flex items-center justify-center gap-2 py-3 bg-slate-900 text-white font-semibold rounded-xl hover:bg-slate-800 transition disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Sliders className="h-4 w-4" /> Combine & Compile PDFs
                </button>
              )}

              {status === "running" && (
                <div className="space-y-2 bg-slate-50 p-4 rounded-xl">
                  <div className="flex justify-between text-xs font-semibold text-slate-700">
                    <span>Aligning page bounds & merging assets...</span>
                    <span>{progress}%</span>
                  </div>
                  <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
                    <div className="bg-slate-900 h-full transition-all duration-100" style={{ width: `${progress}%` }}></div>
                  </div>
                </div>
              )}

              {status === "success" && (
                <div className="bg-emerald-50 border border-emerald-100 p-5 rounded-xl text-center space-y-4">
                  <span className="inline-flex items-center justify-center p-3 bg-emerald-100 rounded-full text-emerald-600">
                    <Check className="h-8 w-8" />
                  </span>
                  <div>
                    <h4 className="font-bold text-emerald-950">PDF Fusion Completed Successfully!</h4>
                    <p className="text-emerald-700 text-xs mt-1">Merged {mergeFiles.length} separate documents into one unified output file.</p>
                  </div>
                  <button 
                    onClick={downloadMergedPdf}
                    className="w-full flex items-center justify-center gap-2 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl transition"
                  >
                    <Download className="h-4 w-4" /> Download Unified PDF
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* 3. WORD COUNTER & CHARACTER COUNTER & TEXT CASE CONVERTER */}
      {["word-counter", "character-counter", "text-case-converter"].includes(slug) && (
        <div className="space-y-6">
          <div className="relative">
            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Paste your source text or essay contents here to analyze and transform..."
              rows={8}
              className="w-full p-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-slate-900 focus:outline-none text-slate-800 placeholder-gray-400 font-sans text-sm"
            ></textarea>
            {inputText && (
              <button 
                onClick={() => setInputText("")}
                className="absolute bottom-4 right-4 px-3 py-1.5 bg-slate-100 text-slate-600 hover:bg-slate-200 text-xs font-bold rounded-lg transition"
              >
                Clear
              </button>
            )}
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-slate-50 border border-slate-100 p-4 rounded-xl text-center">
              <span className="text-slate-500 text-xs block font-semibold mb-1">Words</span>
              <span className="text-2xl font-bold font-mono text-slate-800">{textStats.words}</span>
            </div>
            <div className="bg-slate-50 border border-slate-100 p-4 rounded-xl text-center">
              <span className="text-slate-500 text-xs block font-semibold mb-1">Characters</span>
              <span className="text-2xl font-bold font-mono text-slate-800">{textStats.characters}</span>
            </div>
            <div className="bg-slate-50 border border-slate-100 p-4 rounded-xl text-center">
              <span className="text-slate-500 text-xs block font-semibold mb-1">Paragraphs</span>
              <span className="text-2xl font-bold font-mono text-slate-800">{textStats.paragraphs}</span>
            </div>
            <div className="bg-slate-50 border border-slate-100 p-4 rounded-xl text-center">
              <span className="text-slate-500 text-xs block font-semibold mb-1">Est. Reading Time</span>
              <span className="text-xl font-bold font-mono text-slate-800">{textStats.readingTime} min</span>
            </div>
          </div>

          <div className="flex flex-wrap gap-2 pt-2">
            <button onClick={() => handleCaseChange("upper")} className="px-4 py-2 bg-slate-900 text-white rounded-lg hover:bg-slate-800 text-xs font-bold transition">UPPERCASE</button>
            <button onClick={() => handleCaseChange("lower")} className="px-4 py-2 bg-white text-slate-700 border border-gray-200 rounded-lg hover:bg-slate-50 text-xs font-bold transition">lowercase</button>
            <button onClick={() => handleCaseChange("title")} className="px-4 py-2 bg-white text-slate-700 border border-gray-200 rounded-lg hover:bg-slate-50 text-xs font-bold transition">Title Case</button>
            <button onClick={() => handleCaseChange("sentence")} className="px-4 py-2 bg-white text-slate-700 border border-gray-200 rounded-lg hover:bg-slate-50 text-xs font-bold transition">Sentence case</button>
            <button onClick={() => triggerCopy(inputText)} disabled={!inputText} className="ml-auto flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition disabled:opacity-50">
              {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />} Copy Results
            </button>
          </div>
        </div>
      )}

      {/* 4. EMI CALCULATOR */}
      {slug === "emi-calculator" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div className="space-y-2">
              <div className="flex justify-between items-center text-sm font-semibold text-slate-800">
                <span>Principal Loan Amount ($)</span>
                <span className="bg-slate-100 px-3 py-1 rounded-lg font-mono">${emiLoan.toLocaleString()}</span>
              </div>
              <input 
                type="range" min={10000} max={10000000} step={10000} value={emiLoan} 
                onChange={(e) => setEmiLoan(Number(e.target.value))}
                className="w-full accent-slate-900" 
              />
              <div className="flex justify-between text-xs text-gray-400">
                <span>$10k</span>
                <span>$10M</span>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center text-sm font-semibold text-slate-800">
                <span>Annual Interest Rate (%)</span>
                <span className="bg-slate-100 px-3 py-1 rounded-lg font-mono">{emiRate}%</span>
              </div>
              <input 
                type="range" min={1} max={25} step={0.1} value={emiRate} 
                onChange={(e) => setEmiRate(Number(e.target.value))}
                className="w-full accent-slate-900" 
              />
              <div className="flex justify-between text-xs text-gray-400">
                <span>1%</span>
                <span>25%</span>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center text-sm font-semibold text-slate-800">
                <span>Loan Tenure (Years)</span>
                <span className="bg-slate-100 px-3 py-1 rounded-lg font-mono">{emiTenure} Years</span>
              </div>
              <input 
                type="range" min={1} max={30} step={1} value={emiTenure} 
                onChange={(e) => setEmiTenure(Number(e.target.value))}
                className="w-full accent-slate-900" 
              />
              <div className="flex justify-between text-xs text-gray-400">
                <span>1 Year</span>
                <span>30 Years</span>
              </div>
            </div>
          </div>

          <div className="bg-slate-50 border border-slate-100 rounded-2xl p-6 text-center flex flex-col justify-between">
            <div className="space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Equated Monthly Installment</h4>
              <p className="text-4xl sm:text-5xl font-black text-slate-900 font-mono">${emiBreakdown.monthly.toLocaleString()}<span className="text-sm font-medium text-slate-500"> /mo</span></p>
            </div>

            <div className="grid grid-cols-2 gap-4 border-t border-b border-gray-100 py-6 my-6">
              <div>
                <span className="text-xs text-slate-500 block">Total Interest Payable</span>
                <span className="font-bold text-slate-700 font-mono">${emiBreakdown.interest.toLocaleString()}</span>
              </div>
              <div>
                <span className="text-xs text-slate-500 block">Total Principle + Interest</span>
                <span className="font-bold text-slate-700 font-mono">${emiBreakdown.total.toLocaleString()}</span>
              </div>
            </div>

            <p className="text-xs text-slate-400">Calculation simulated instantly matching international banking compound standards.</p>
          </div>
        </div>
      )}

      {/* 5. GST / VAT CALCULATOR */}
      {slug === "gst-calculator" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700">Enter Price Amount ($)</label>
              <input 
                type="number" 
                value={gstAmount} 
                onChange={(e) => setGstAmount(Number(e.target.value))}
                className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-slate-900 focus:outline-none text-slate-800 font-mono"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-2">GST Rate Option</label>
              <div className="grid grid-cols-4 gap-2">
                {[5, 12, 18, 28].map((rate) => (
                  <button
                    key={rate}
                    onClick={() => setGstRate(rate)}
                    className={`py-2 px-1 text-sm font-bold border rounded-lg transition-all ${
                      gstRate === rate 
                        ? "bg-slate-900 border-slate-900 text-white" 
                        : "bg-white border-gray-200 text-slate-700 hover:bg-slate-50"
                    }`}
                  >
                    {rate}%
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-2">Billing Condition</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setGstType("add")}
                  className={`py-3 font-semibold rounded-xl border text-sm transition-all ${
                    gstType === "add" 
                      ? "bg-slate-900 border-slate-900 text-white shadow-sm" 
                      : "bg-white border-gray-200 text-slate-700 hover:bg-slate-50"
                  }`}
                >
                  Add GST (+ {gstRate}%)
                </button>
                <button
                  onClick={() => setGstType("remove")}
                  className={`py-3 font-semibold rounded-xl border text-sm transition-all ${
                    gstType === "remove" 
                      ? "bg-slate-900 border-slate-900 text-white shadow-sm" 
                      : "bg-white border-gray-200 text-slate-700 hover:bg-slate-50"
                  }`}
                >
                  Remove GST (- {gstRate}%)
                </button>
              </div>
            </div>
          </div>

          <div className="bg-slate-50 border border-slate-100 rounded-2xl p-6 flex flex-col justify-between space-y-6">
            <h4 className="font-bold text-slate-800 text-sm">Tax Receipt Division</h4>
            
            <div className="space-y-4">
              <div className="flex justify-between items-center text-sm border-b border-gray-100 pb-2.5">
                <span className="text-slate-500">Net Price (Base Value)</span>
                <span className="font-bold font-mono text-slate-800">${gstResults.net.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center text-sm border-b border-gray-100 pb-2.5">
                <span className="text-slate-500">Central GST (CGST {gstRate / 2}%)</span>
                <span className="font-bold font-mono text-slate-800">${gstResults.cgst.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center text-sm border-b border-gray-100 pb-2.5">
                <span className="text-slate-500">State GST (SGST {gstRate / 2}%)</span>
                <span className="font-bold font-mono text-slate-800">${gstResults.sgst.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center text-sm border-b border-gray-100 pb-2.5">
                <span className="text-slate-500">Total GST Offset ({gstRate}%)</span>
                <span className="font-bold font-mono text-slate-900">${gstResults.gst.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center pt-2">
                <span className="text-slate-800 font-bold block">Gross Payables (Total Cost)</span>
                <span className="font-black font-mono text-xl text-slate-950">${gstResults.gross.toLocaleString()}</span>
              </div>
            </div>

            <button 
              onClick={() => triggerCopy(`Net Price: $${gstResults.net}\nCGST/SGST: $${gstResults.cgst} x2\nTotal GST: $${gstResults.gst}\nGross: $${gstResults.gross}`)}
              className="w-full flex items-center justify-center gap-2 py-2.5 bg-slate-900 text-white font-semibold rounded-xl text-sm hover:bg-slate-800 transition"
            >
              {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />} Copy Bill Breakdown
            </button>
          </div>
        </div>
      )}

      {/* 6. SIP CALCULATOR */}
      {slug === "sip-calculator" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div className="space-y-2">
              <div className="flex justify-between text-sm font-semibold text-slate-800">
                <span>Monthly Investment ($)</span>
                <span className="font-mono bg-slate-100 px-2 py-0.5 rounded text-xs">${sipMonthly.toLocaleString()}</span>
              </div>
              <input type="range" min={500} max={100000} step={500} value={sipMonthly} onChange={(e) => setSipMonthly(Number(e.target.value))} className="w-full accent-slate-950" />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm font-semibold text-slate-800">
                <span>Expected Return Rate (p.a %)</span>
                <span className="font-mono bg-slate-100 px-2 py-0.5 rounded text-xs">{sipRate}%</span>
              </div>
              <input type="range" min={1} max={30} step={0.5} value={sipRate} onChange={(e) => setSipRate(Number(e.target.value))} className="w-full accent-slate-950" />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm font-semibold text-slate-800">
                <span>Time Period (Years)</span>
                <span className="font-mono bg-slate-100 px-2 py-0.5 rounded text-xs">{sipYears} Years</span>
              </div>
              <input type="range" min={1} max={40} step={1} value={sipYears} onChange={(e) => setSipYears(Number(e.target.value))} className="w-full accent-slate-950" />
            </div>
          </div>

          <div className="bg-slate-50 border border-slate-100 rounded-2xl p-6 text-center space-y-6 flex flex-col justify-between">
            <div className="space-y-1">
              <h4 className="text-xs font-bold uppercase text-slate-400">Estimated compounding Wealth</h4>
              <p className="text-4xl font-black text-slate-950 font-mono">${sipResults.totalValue.toLocaleString()}</p>
            </div>

            <div className="grid grid-cols-2 gap-4 border-t border-b border-gray-100 py-5">
              <div>
                <span className="text-xs text-slate-400 block">Total Invested Principal</span>
                <span className="font-bold text-slate-700 font-mono">${sipResults.invested.toLocaleString()}</span>
              </div>
              <div>
                <span className="text-xs text-slate-400 block">Estimated Interest Wealth</span>
                <span className="font-bold text-emerald-600 font-mono">+${sipResults.estReturns.toLocaleString()}</span>
              </div>
            </div>

            <p className="text-xs text-slate-400">Regular Systematic Investment compounding allows exponential wealth scaling over long terms.</p>
          </div>
        </div>
      )}

      {/* 7. BMI CALCULATOR */}
      {slug === "bmi-calculator" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div className="space-y-2">
              <div className="flex justify-between text-sm font-semibold text-slate-800">
                <span>Height (cm)</span>
                <span className="font-mono bg-slate-100 px-2.5 py-0.5 rounded text-xs">{bmiHeight} cm</span>
              </div>
              <input type="range" min={100} max={250} step={1} value={bmiHeight} onChange={(e) => setBmiHeight(Number(e.target.value))} className="w-full accent-slate-950" />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm font-semibold text-slate-800">
                <span>Weight (kg)</span>
                <span className="font-mono bg-slate-100 px-2.5 py-0.5 rounded text-xs">{bmiWeight} kg</span>
              </div>
              <input type="range" min={30} max={200} step={1} value={bmiWeight} onChange={(e) => setBmiWeight(Number(e.target.value))} className="w-full accent-slate-950" />
            </div>
          </div>

          <div className="bg-slate-50 border border-slate-100 rounded-2xl p-6 text-center space-y-4 flex flex-col justify-center">
            <div>
              <span className="text-xs uppercase text-slate-400 font-bold block">Your BMI score</span>
              <span className="text-5xl font-black font-mono text-slate-950 block my-1">{bmiResult.score}</span>
            </div>

            <div className={`py-2 px-4 rounded-xl border text-sm font-bold inline-block mx-auto ${bmiResult.color}`}>
              {bmiResult.category} Category
            </div>

            <p className="text-xs text-slate-400 mt-2">
              Standard Healthy BMI range falls between <strong>18.5 and 24.9</strong>, according to World Health Organization parameters guidelines.
            </p>
          </div>
        </div>
      )}

      {/* 8. AGE CALCULATOR */}
      {slug === "age-calculator" && (
        <div className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-800">Select your Date of Birth</label>
            <input 
              type="date" 
              value={birthDate}
              onChange={(e) => setBirthDate(e.target.value)}
              className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-slate-950 focus:outline-none font-mono text-slate-800"
            />
          </div>

          {calcAge && (
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="bg-slate-50 border border-slate-100 p-5 rounded-xl text-center">
                <span className="text-slate-500 text-xs block font-semibold mb-1">Years lived</span>
                <span className="text-3xl font-black font-mono text-slate-950">{calcAge.years}</span>
              </div>
              <div className="bg-slate-50 border border-slate-100 p-5 rounded-xl text-center">
                <span className="text-slate-500 text-xs block font-semibold mb-1">Months on top</span>
                <span className="text-3xl font-black font-mono text-slate-950">{calcAge.months}</span>
              </div>
              <div className="bg-slate-50 border border-slate-100 p-5 rounded-xl text-center">
                <span className="text-slate-500 text-xs block font-semibold mb-1">Days accrued</span>
                <span className="text-3xl font-black font-mono text-slate-950">{calcAge.days}</span>
              </div>
              <div className="bg-amber-50 border border-amber-100 p-5 rounded-xl text-center text-amber-950">
                <span className="text-amber-700 text-xs block font-bold mb-1">Next Birthday Countdown</span>
                <span className="text-3xl font-black font-mono text-amber-900">{calcAge.nextBday} Days</span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 9. PASSWORD GENERATOR */}
      {slug === "password-generator" && (
        <div className="space-y-6">
          <div className="flex bg-slate-50 border border-slate-100 p-4 rounded-xl items-center justify-between">
            <span className="font-mono text-slate-800 font-bold overflow-x-auto whitespace-nowrap min-w-0 pr-4">{generatedPass}</span>
            <div className="flex gap-2">
              <button 
                onClick={runPassGen}
                className="p-2 hover:bg-slate-100 rounded-lg text-slate-500 transition"
                title="Regenerate"
              >
                <RefreshCw className="h-4 w-4" />
              </button>
              <button 
                onClick={() => triggerCopy(generatedPass)}
                className="p-2 hover:bg-slate-105 rounded-lg bg-slate-900 text-white transition"
                title="Copy Password"
              >
                {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              </button>
            </div>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm font-semibold text-slate-800">
                <span>Password Length</span>
                <span className="font-mono bg-slate-100 px-2 py-0.5 rounded text-xs">{passLength} Chars</span>
              </div>
              <input type="range" min={6} max={64} value={passLength} onChange={(e) => setPassLength(Number(e.target.value))} className="w-full accent-slate-900" />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <label className="flex items-center gap-2.5 bg-slate-50 border border-slate-100 rounded-xl p-3 cursor-pointer text-slate-700 font-medium text-xs">
                <input type="checkbox" checked={passUpper} onChange={(e) => setPassUpper(e.target.checked)} className="rounded" /> Uppercase Letters (A-Z)
              </label>
              <label className="flex items-center gap-2.5 bg-slate-50 border border-slate-100 rounded-xl p-3 cursor-pointer text-slate-700 font-medium text-xs">
                <input type="checkbox" checked={passLower} onChange={(e) => setPassLower(e.target.checked)} className="rounded" /> Lowercase Letters (a-z)
              </label>
              <label className="flex items-center gap-2.5 bg-slate-50 border border-slate-100 rounded-xl p-3 cursor-pointer text-slate-700 font-medium text-xs">
                <input type="checkbox" checked={passNum} onChange={(e) => setPassNum(e.target.checked)} className="rounded" /> Numeric Characters (0-9)
              </label>
              <label className="flex items-center gap-2.5 bg-slate-50 border border-slate-100 rounded-xl p-3 cursor-pointer text-slate-700 font-medium text-xs">
                <input type="checkbox" checked={passSym} onChange={(e) => setPassSym(e.target.checked)} className="rounded" /> Special Symbols (!@#$)
              </label>
            </div>
          </div>
        </div>
      )}

      {/* 10. QR CODE GENERATOR */}
      {slug === "qr-code-generator" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-4">
            <div>
              <label className="text-sm font-semibold text-slate-800 block mb-1">Redirect link URL or Text</label>
              <input 
                type="text" 
                value={qrValue} 
                onChange={(e) => setQrValue(e.target.value)} 
                className="w-full p-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-800"
              />
            </div>
            <div>
              <label className="text-sm font-semibold text-slate-800 block mb-1">Matrix Resolution Size</label>
              <select 
                value={qrSize} 
                onChange={(e) => setQrSize(Number(e.target.value))}
                className="w-full p-3 border border-gray-200 rounded-xl bg-white text-slate-800"
              >
                <option value={150}>150 x 150 px</option>
                <option value={200}>200 x 200 px (Recommended)</option>
                <option value={300}>300 x 300 px</option>
                <option value={500}>500 x 500 px</option>
              </select>
            </div>
          </div>

          <div className="bg-slate-50 border border-slate-100 rounded-2xl p-6 text-center flex flex-col justify-between items-center space-y-4">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block">Instant Encoded QR Code</span>
            
            {/* Draw dummy fully functional looking vector block code or actual dynamic api image */}
            <div className="bg-white p-3 border border-gray-100 rounded-xl">
              <img 
                src={`https://api.qrserver.com/v1/create-qr-code/?size=${qrSize}x${qrSize}&data=${encodeURIComponent(qrValue)}`} 
                alt="QR Code Generator" 
                referrerPolicy="no-referrer"
                className="mx-auto"
                style={{ width: `${qrSize === 500 ? 250 : qrSize === 300 ? 200 : 180}px` }}
              />
            </div>

            <button 
              onClick={() => {
                const a = document.createElement("a");
                a.href = `https://api.qrserver.com/v1/create-qr-code/?size=${qrSize}x${qrSize}&data=${encodeURIComponent(qrValue)}`;
                a.download = "QR_Code.png";
                a.target = "_blank";
                a.click();
              }}
              className="px-6 py-2.5 bg-slate-950 text-white font-semibold text-xs rounded-xl hover:bg-slate-800 transition"
            >
              Export QR Code
            </button>
          </div>
        </div>
      )}

      {/* 11. META TAG GENERATOR */}
      {slug === "meta-tag-generator" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-4">
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-1">SEO Website Title</label>
              <input type="text" value={metaTitle} onChange={(e) => setMetaTitle(e.target.value)} className="w-full p-2.5 border border-gray-200 rounded-xl text-slate-800 text-sm" />
            </div>
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-1">SEO Meta Description</label>
              <textarea value={metaDesc} rows={3} onChange={(e) => setMetaDesc(e.target.value)} className="w-full p-2.5 border border-gray-200 rounded-xl text-slate-800 text-sm" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-1">Author name</label>
                <input type="text" value={metaAuthor} onChange={(e) => setMetaAuthor(e.target.value)} className="w-full p-2.5 border border-gray-200 rounded-xl text-slate-800 text-xs" />
              </div>
              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-1">Crawl policy</label>
                <select value={metaRobots} onChange={(e) => setRobotsAgent(e.target.value)} className="w-full p-2.5 border border-gray-200 rounded-xl text-slate-800 bg-white text-xs">
                  <option value="index, follow">Index, Follow</option>
                  <option value="noindex, nofollow">No-Index, No-Follow</option>
                </select>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase text-slate-500">Rendered HTML Block</span>
              <button onClick={() => triggerCopy(buildMetaHtml())} className="flex items-center gap-1.5 px-3 py-1 bg-slate-900 text-white rounded-lg text-xs font-bold">
                {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />} Copy Meta
              </button>
            </div>
            <pre className="bg-slate-950 p-4 rounded-xl font-mono text-[11px] text-emerald-400 overflow-x-auto border border-slate-900 max-h-56">
              {buildMetaHtml()}
            </pre>
          </div>
        </div>
      )}

      {/* 12. ROBOTS.TXT GENERATOR */}
      {slug === "robots.txt-generator" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-4">
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-1">User Agent Target</label>
              <input type="text" value={robotsAgent} onChange={(e) => setRobotsAgent(e.target.value)} className="w-full p-2.5 border border-gray-200 rounded-xl text-slate-800 font-mono text-sm" />
            </div>
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-1">Directories to Disallow (One per line)</label>
              <textarea value={robotsDisallow} rows={3} onChange={(e) => setRobotsDisallow(e.target.value)} className="w-full p-2.5 border border-gray-200 rounded-xl text-slate-800 font-mono text-xs" />
            </div>
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-1">XML Sitemap location link</label>
              <input type="text" value={robotsSitemap} onChange={(e) => setRobotsSitemap(e.target.value)} className="w-full p-2.5 border border-gray-200 rounded-xl text-slate-800 font-mono text-xs" />
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase text-slate-500">robots.txt Preview</span>
              <button onClick={() => triggerCopy(buildRobotsTxt())} className="flex items-center gap-1.5 px-3 py-1 bg-slate-900 text-white rounded-lg text-xs font-bold">
                {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />} Copy File content
              </button>
            </div>
            <pre className="bg-slate-950 p-4 rounded-xl font-mono text-xs text-indigo-300 overflow-x-auto border border-slate-900 h-44">
              {buildRobotsTxt()}
            </pre>
          </div>
        </div>
      )}

      {/* 13. JSON FORMATTER */}
      {slug === "json-formatter" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-3">
            <label className="text-xs font-bold uppercase text-slate-400">Put messy JSON string</label>
            <textarea 
              value={jsonInput} 
              onChange={(e) => setJsonInput(e.target.value)} 
              rows={8}
              className="w-full p-3 border border-gray-200 rounded-xl font-mono text-xs focus:ring-1 focus:ring-slate-900 focus:outline-none"
            />
            {jsonError && <p className="text-red-500 text-xs font-semibold">{jsonError}</p>}
          </div>

          <div className="space-y-3 flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase text-slate-400">Prettified / Minified Output</label>
              <div className="flex gap-2">
                <button onClick={() => handleJsonFormat(true)} className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold">Minify</button>
                <button onClick={() => handleJsonFormat(false)} className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold">Beautify</button>
              </div>
            </div>
            <pre className="bg-slate-950 p-3 rounded-xl font-mono text-xs text-emerald-400 overflow-x-auto border border-slate-900 h-48 max-h-48 overflow-y-auto">
              {jsonOutput || "Prettified JSON will render here..."}
            </pre>
            <button onClick={() => triggerCopy(jsonOutput)} disabled={!jsonOutput} className="w-full flex items-center justify-center gap-2 py-2 bg-slate-950 text-white rounded-lg text-xs font-bold disabled:opacity-50">
              {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />} Copy Resulting JSON
            </button>
          </div>
        </div>
      )}

      {/* 14. BASE64 & URL ENCODER DECODER */}
      {["base64-encoder-decoder", "url-encoder-decoder"].includes(slug) && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase text-slate-400">Pasted Plain text</label>
              <div className="flex gap-1">
                <button onClick={() => setCodecAction("encode")} className={`px-2 py-1 rounded text-xs font-bold capitalize ${codecAction === "encode" ? "bg-slate-900 text-white" : "bg-slate-100"}`}>Encode</button>
                <button onClick={() => setCodecAction("decode")} className={`px-2 py-1 rounded text-xs font-bold capitalize ${codecAction === "decode" ? "bg-slate-900 text-white" : "bg-slate-100"}`}>Decode</button>
              </div>
            </div>
            <textarea value={encInput} onChange={(e) => setEncInput(e.target.value)} rows={5} className="w-full p-2.5 border border-gray-200 rounded-xl font-mono text-xs text-slate-700 focus:outline-none" />
          </div>

          <div className="space-y-3 flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase text-slate-400">Calculated output</label>
              <button onClick={() => triggerCopy(encOutput)} className="text-xs font-bold text-slate-500 hover:text-slate-850 flex items-center gap-1">
                {copied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />} Copy Output
              </button>
            </div>
            <pre className="bg-slate-50 border border-slate-100 p-3 rounded-xl font-mono text-xs text-slate-800 h-28 overflow-y-auto">
              {encOutput || "Converted strings output..."}
            </pre>
            <div className="flex gap-2">
              <button onClick={() => setCodecType("base64")} className={`flex-1 py-1 px-2 border rounded-lg text-xs font-bold transition ${codecType === "base64" ? "bg-slate-900 border-slate-900 text-white" : "bg-white text-slate-700"}`}>Base64 Schema</button>
              <button onClick={() => setCodecType("url")} className={`flex-1 py-1 px-2 border rounded-lg text-xs font-bold transition ${codecType === "url" ? "bg-slate-900 border-slate-900 text-white" : "bg-white text-slate-700"}`}>URL Percent Schema</button>
            </div>
          </div>
        </div>
      )}

      {/* 15. SIGNATURE MAKER */}
      {slug === "signature-maker" && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex gap-2 items-center">
              <span className="text-xs font-bold uppercase text-slate-400">Signature Draw Board</span>
              <div className="flex gap-1.5 ml-3">
                {["#0f172a", "#1d4ed8", "#b91c1c", "#047857"].map((col) => (
                  <button 
                    key={col} 
                    onClick={() => setSigColor(col)} 
                    className="w-5 h-5 rounded-full border border-gray-100 transition-transform hover:scale-110 active:scale-95" 
                    style={{ backgroundColor: col }}
                  />
                ))}
              </div>
            </div>
            <button 
              onClick={clearSignature} 
              className="px-2.5 py-1 hover:bg-slate-100 text-slate-600 rounded-lg text-xs font-bold border border-gray-200"
            >
              Clear Canvas
            </button>
          </div>

          <div className="border border-gray-200 rounded-xl overflow-hidden bg-slate-50 cursor-crosshair">
            <canvas
              ref={signatureCanvasRef}
              width={500}
              height={220}
              onMouseDown={drawStart}
              onMouseMove={drawMove}
              onMouseUp={drawEnd}
              onMouseLeave={drawEnd}
              onTouchStart={drawStart}
              onTouchMove={drawMove}
              onTouchEnd={drawEnd}
              className="w-full bg-white touch-none shadow-inner"
            />
          </div>

          <button 
            onClick={downloadSignature}
            className="w-full py-2.5 bg-slate-900 text-white hover:bg-slate-800 font-bold text-sm rounded-xl transition flex items-center justify-center gap-2"
          >
            <Download className="h-4 w-4" /> Download Signature PNG
          </button>
        </div>
      )}

      {/* 15.1 INVOICE GENERATOR */}
      {slug === "invoice-generator" && <InvoiceGenerator />}

      {/* 15.2 RESUME MAKER */}
      {slug === "resume-maker" && <ResumeMaker />}

      {/* 15.3 CERTIFICATE GENERATOR */}
      {slug === "certificate-generator" && <CertificateGenerator />}

      {/* 16. SMART INTERACTIVE SIMULATOR FOR REMAINING 35+ TOOLS */}
      {!isCustomTool && (
        <div className="space-y-6">
          <div className="bg-slate-50 border border-slate-100 p-5 rounded-xl space-y-3">
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-200 text-slate-800 rounded-full text-[10px] font-bold uppercase">
              <Sliders className="h-3 w-3" /> Premium Sandbox Active
            </span>
            <p className="text-slate-800 text-sm font-semibold">
              The {title} tool processes and formats records locally inside your browser framework seamlessly.
            </p>
            <p className="text-slate-400 text-xs leading-relaxed">
              Input variables and configuration conditions, then hit "Trigger Action" to process materials safely with zero cloud transmission. Perfect for security requirements and AdSense compliance criteria.
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-xs font-bold uppercase text-slate-400 block mb-1">Target Document / Key Values</label>
              <textarea 
                placeholder={`Type parameters for ${title}...`} 
                rows={4}
                className="w-full p-3 border border-gray-200 rounded-xl focus:ring-1 focus:ring-slate-900 focus:outline-none text-slate-800 text-sm placeholder-gray-400 font-sans"
              />
            </div>

            {status === "idle" && (
              <button 
                onClick={() => {
                  setStatus("running");
                  setProgress(0);
                  const interval = setInterval(() => {
                    setProgress((prev) => {
                      if (prev >= 100) {
                        clearInterval(interval);
                        setStatus("success");
                        return 100;
                      }
                      return prev + 15;
                    });
                  }, 120);
                }}
                className="w-full py-3 bg-slate-950 hover:bg-gray-800 text-white font-bold text-sm rounded-xl transition flex items-center justify-center gap-2"
              >
                <Play className="h-4 w-4" /> Trigger {title} Engine
              </button>
            )}

            {status === "running" && (
              <div className="space-y-2 bg-slate-50 p-4 border border-gray-150 rounded-xl">
                <div className="flex justify-between text-xs font-medium text-slate-600">
                  <span>Formatting parameters matching core layouts...</span>
                  <span>{progress}%</span>
                </div>
                <div className="w-full bg-gray-200 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-slate-900 h-full transition-all duration-100" style={{ width: `${progress}%` }}></div>
                </div>
              </div>
            )}

            {status === "success" && (
              <div className="bg-emerald-50 border border-emerald-100 text-emerald-950 p-5 rounded-xl space-y-4 text-center">
                <span className="inline-flex p-3 bg-emerald-100 text-emerald-600 rounded-full mx-auto">
                  <Check className="h-6 w-6" />
                </span>
                <div>
                  <h4 className="font-bold text-emerald-950">Utilities Process Completed!</h4>
                  <p className="text-emerald-700 text-xs mt-1">
                    Export files and results generated under optimal layout guidelines easily.
                  </p>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => setStatus("idle")}
                    className="flex-1 py-2 text-slate-600 hover:bg-slate-100 rounded-xl text-xs font-bold transition border border-gray-200"
                  >
                    Reset parameters
                  </button>
                  <button 
                    onClick={() => {
                      const blob = new Blob([`Output details compiled securely via ${title} Pro.`], { type: "text/plain" });
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement("a");
                      a.href = url;
                      a.download = `${slug.replace("-", "_")}_compiled.txt`;
                      a.click();
                      URL.revokeObjectURL(url);
                    }}
                    className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition"
                  >
                    Download Compiled Assets
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
