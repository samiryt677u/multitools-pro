import React, { useState, useRef } from "react";
import { Plus, Trash2, Upload, Printer, Check, Palette, Briefcase, FileText } from "lucide-react";

interface InvoiceItem {
  id: string;
  desc: string;
  qty: number;
  rate: number;
}

export default function InvoiceGenerator() {
  const [logo, setLogo] = useState<string | null>(null);
  const [senderName, setSenderName] = useState("My Brand Inc.");
  const [senderDetails, setSenderDetails] = useState("123 Business Lane\nNew York, NY 10001\nbilling@mybrand.com");
  const [clientName, setClientName] = useState("Acme Corporation");
  const [clientDetails, setClientDetails] = useState("456 Corporate Blvd\nSuite 900\naccounts@acme.com");
  
  const [invoiceNum, setInvoiceNum] = useState("INV-2026-001");
  const [invoiceDate, setInvoiceDate] = useState("2026-05-28");
  const [invoiceDueDate, setInvoiceDueDate] = useState("2026-06-12");
  
  const [items, setItems] = useState<InvoiceItem[]>([
    { id: "1", desc: "Enterprise Web Consultation", qty: 2, rate: 125 },
    { id: "2", desc: "Cloud Architecture Migration Support", qty: 1, rate: 850 },
    { id: "3", desc: "Local Analytics Integration Setup", qty: 4, rate: 75 }
  ]);
  
  const [taxRate, setTaxRate] = useState(18); // default to 18% GST/VAT
  const [discount, setDiscount] = useState(50); // custom static discount
  const [currencySymbol, setCurrencySymbol] = useState("$");
  const [fontStyle, setFontStyle] = useState<"font-sans" | "font-serif" | "font-mono">("font-sans");
  const [brandColor, setBrandColor] = useState("#4f46e5"); // indigo
  const [templateStyle, setTemplateStyle] = useState<"modern" | "classic" | "corporate">("modern");

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const url = URL.createObjectURL(e.target.files[0]);
      setLogo(url);
    }
  };

  const removeLogo = () => {
    setLogo(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const updateItem = (id: string, field: keyof InvoiceItem, value: any) => {
    setItems(prev => prev.map(item => {
      if (item.id === id) {
        return { ...item, [field]: value };
      }
      return item;
    }));
  };

  const addItem = () => {
    setItems(prev => [
      ...prev,
      {
        id: Math.random().toString(36).substring(2, 9),
        desc: "New Item Service / Description",
        qty: 1,
        rate: 50
      }
    ]);
  };

  const deleteItem = (id: string) => {
    if (items.length <= 1) return;
    setItems(prev => prev.filter(item => item.id !== id));
  };

  // Math calculators
  const subtotal = items.reduce((acc, item) => acc + (item.qty * item.rate), 0);
  const taxAmount = Math.round(subtotal * (taxRate / 100));
  const finalTotal = subtotal + taxAmount - discount;

  const triggerPrint = () => {
    window.print();
  };

  // Pre-selected color options matching standard branding guidelines
  const colorSchemes = [
    { name: "Indigo", hex: "#4f46e5" },
    { name: "Emerald", hex: "#059669" },
    { name: "Royal", hex: "#1d4ed8" },
    { name: "Slate", hex: "#334155" },
    { name: "Crimson", hex: "#b91c1c" }
  ];

  return (
    <div className={`space-y-8 ${fontStyle}`}>
      {/* 1. Control Board and Form Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left configurations inputs */}
        <div className="lg:col-span-6 space-y-6 bg-slate-50 dark:bg-slate-900 border border-slate-150/80 dark:border-slate-800 p-5 rounded-2xl">
          <h3 className="text-xs font-black uppercase tracking-widest text-slate-450 dark:text-slate-500 flex items-center gap-1.5 border-b border-slate-200 dark:border-slate-800 pb-2">
            <Palette className="h-4 w-4 text-indigo-500" /> Invoice Branding & Metrics
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Brand Style Preset</label>
              <div className="flex gap-1">
                {(["modern", "classic", "corporate"] as const).map((style) => (
                  <button
                    key={style}
                    onClick={() => setTemplateStyle(style)}
                    className={`flex-1 py-1.5 text-xs font-bold rounded-lg border transition ${templateStyle === style ? "bg-slate-950 border-slate-950 text-white dark:bg-indigo-650" : "bg-white border-slate-200 text-slate-600 dark:bg-slate-950 dark:border-slate-800"}`}
                  >
                    {style.charAt(0).toUpperCase() + style.slice(1)}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Typography Font</label>
              <div className="flex gap-1">
                {[
                  { id: "font-sans", name: "Sans" },
                  { id: "font-serif", name: "Serif" },
                  { id: "font-mono", name: "Mono" }
                ].map((f) => (
                  <button
                    key={f.id}
                    onClick={() => setFontStyle(f.id as any)}
                    className={`flex-1 py-1.5 text-[10px] font-bold rounded-lg border transition ${fontStyle === f.id ? "bg-slate-950 border-slate-950 text-white dark:bg-indigo-650" : "bg-white border-slate-200 text-slate-600 dark:bg-slate-950 dark:border-slate-800"}`}
                  >
                    {f.name}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div>
            <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Accent Theme Color</label>
            <div className="flex items-center gap-2">
              <div className="flex gap-1.5">
                {colorSchemes.map((c) => (
                  <button
                    key={c.hex}
                    onClick={() => setBrandColor(c.hex)}
                    className="w-6 h-6 rounded-full border border-white/20 transition-transform active:scale-90 hover:scale-110 flex items-center justify-center"
                    style={{ backgroundColor: c.hex }}
                    title={c.name}
                  >
                    {brandColor === c.hex && <Check className="h-3 w-3 text-white" />}
                  </button>
                ))}
              </div>
              <span className="text-slate-300">|</span>
              <input
                type="color"
                value={brandColor}
                onChange={(e) => setBrandColor(e.target.value)}
                className="w-8 h-8 rounded cursor-pointer border border-slate-200 bg-transparent"
              />
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">Business & Client Logs</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-450 block mb-1">Sender Entity</label>
                  <input
                    type="text"
                    value={senderName}
                    onChange={(e) => setSenderName(e.target.value)}
                    className="w-full text-xs p-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-800 dark:text-slate-200"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-450 block mb-1">Sender Details</label>
                  <textarea
                    rows={2}
                    value={senderDetails}
                    onChange={(e) => setSenderDetails(e.target.value)}
                    className="w-full text-[11px] p-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-800 dark:text-slate-200 font-sans"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-450 block mb-1">Recipient Client</label>
                  <input
                    type="text"
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    className="w-full text-xs p-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-800 dark:text-slate-200"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-450 block mb-1">Recipient Details</label>
                  <textarea
                    rows={2}
                    value={clientDetails}
                    onChange={(e) => setClientDetails(e.target.value)}
                    className="w-full text-[11px] p-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-800 dark:text-slate-200 font-sans"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
            <div>
              <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Invoice ID</label>
              <input
                type="text"
                value={invoiceNum}
                onChange={(e) => setInvoiceNum(e.target.value)}
                className="w-full text-xs p-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-800 dark:text-slate-200"
              />
            </div>
            <div>
              <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Issue Date</label>
              <input
                type="date"
                value={invoiceDate}
                onChange={(e) => setInvoiceDate(e.target.value)}
                className="w-full text-xs p-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-800 dark:text-slate-200 font-sans"
              />
            </div>
            <div>
              <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Due Date</label>
              <input
                type="date"
                value={invoiceDueDate}
                onChange={(e) => setInvoiceDueDate(e.target.value)}
                className="w-full text-xs p-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-800 dark:text-slate-200 font-sans"
              />
            </div>
          </div>

          {/* Logo uploading tool */}
          <div>
            <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Interactive Logo Upload</label>
            <div className="flex gap-2 items-center">
              <div className="relative">
                <input
                  type="file"
                  ref={fileInputRef}
                  accept="image/*"
                  onChange={handleLogoUpload}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                <button className="px-3 py-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl font-bold text-xs flex items-center gap-1.5 text-slate-700 dark:text-slate-300">
                  <Upload className="h-3.5 w-3.5" /> Upload File logo
                </button>
              </div>
              {logo && (
                <button
                  onClick={removeLogo}
                  className="px-2.5 py-2 text-xs font-bold text-red-600 bg-red-50 hover:bg-red-100 rounded-xl"
                >
                  Delete logo
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Right side interactive item table creator */}
        <div className="lg:col-span-6 space-y-4">
          <div className="flex justify-between items-center bg-slate-100 dark:bg-slate-900 p-3.5 rounded-xl border border-slate-150/80 dark:border-slate-800">
            <span className="font-bold text-slate-800 dark:text-slate-200 text-xs">Aesthetic Products Registry</span>
            <button
              onClick={addItem}
              className="px-2.5 py-1 bg-slate-950 hover:bg-slate-800 text-white rounded-lg text-xs font-bold flex items-center gap-1 transition"
            >
              <Plus className="h-3 w-3" /> Add Item Line
            </button>
          </div>

          <div className="space-y-3.5 max-h-[360px] overflow-y-auto pr-1">
            {items.map((item) => (
              <div
                key={item.id}
                className="flex flex-col sm:flex-row gap-2 border border-slate-150 dark:border-slate-800 p-3.5 rounded-xl bg-white dark:bg-slate-950 relative"
              >
                <div className="flex-1 space-y-1">
                  <label className="text-[8px] font-black uppercase text-slate-400">Description</label>
                  <input
                    type="text"
                    value={item.desc}
                    onChange={(e) => updateItem(item.id, "desc", e.target.value)}
                    className="w-full text-xs p-1.5 focus:outline-none focus:ring-1 focus:ring-indigo-500 rounded border border-slate-200 dark:border-slate-800 dark:bg-slate-900 text-slate-800 dark:text-slate-200"
                  />
                </div>
                <div className="flex gap-2.5">
                  <div className="w-16 space-y-1">
                    <label className="text-[8px] font-black uppercase text-slate-400">Qty</label>
                    <input
                      type="number"
                      min={1}
                      value={item.qty}
                      onChange={(e) => updateItem(item.id, "qty", parseInt(e.target.value) || 1)}
                      className="w-full text-xs p-1.5 focus:outline-none focus:ring-1 focus:ring-indigo-500 rounded border border-slate-200 dark:border-slate-800 dark:bg-slate-900 text-slate-800 dark:text-slate-200 font-sans"
                    />
                  </div>
                  <div className="w-24 space-y-1">
                    <label className="text-[8px] font-black uppercase text-slate-400">Rate</label>
                    <input
                      type="number"
                      min={0}
                      value={item.rate}
                      onChange={(e) => updateItem(item.id, "rate", parseFloat(e.target.value) || 0)}
                      className="w-full text-xs p-1.5 focus:outline-none focus:ring-1 focus:ring-indigo-500 rounded border border-slate-200 dark:border-slate-800 dark:bg-slate-900 text-slate-800 dark:text-slate-200 font-sans"
                    />
                  </div>
                  <div className="w-20 space-y-1 font-mono text-xs flex flex-col justify-end text-right pr-2">
                    <span className="text-[8px] font-black uppercase text-slate-400 pb-1.5">Total</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">
                      {currencySymbol}{(item.qty * item.rate).toFixed(2)}
                    </span>
                  </div>
                  <div className="flex items-end">
                    <button
                      onClick={() => deleteItem(item.id)}
                      disabled={items.length <= 1}
                      className="p-1.5 text-red-500 hover:bg-red-50 disabled:opacity-30 rounded transition cursor-pointer"
                      title="Delete item"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Subtotal metrics controls */}
          <div className="bg-slate-50 dark:bg-slate-900 border border-slate-150 p-4 rounded-xl space-y-2.5">
            <div className="flex justify-between items-center">
              <span className="text-xs font-bold text-slate-500 dark:text-slate-400">Local Currency</span>
              <select
                value={currencySymbol}
                onChange={(e) => setCurrencySymbol(e.target.value)}
                className="p-1.5 bg-white dark:bg-slate-950 border text-xs font-bold border-slate-200 dark:border-slate-800 rounded text-slate-700 dark:text-slate-300"
              >
                <option value="$">US Dollar ($)</option>
                <option value="€">Euro (€)</option>
                <option value="£">Pound Sterling (£)</option>
                <option value="₹">Indian Rupee (₹)</option>
                <option value="¥">Yen (¥)</option>
              </select>
            </div>

            <div className="flex justify-between items-center gap-10">
              <span className="text-xs font-bold text-slate-500 dark:text-slate-400">SGST/CGST/VAT (%)</span>
              <input
                type="range"
                min={0}
                max={30}
                value={taxRate}
                onChange={(e) => setTaxRate(parseInt(e.target.value))}
                className="flex-1 mt-1 cursor-pointer"
              />
              <span className="text-xs font-bold font-mono bg-slate-200 dark:bg-slate-850 px-2 py-0.5 rounded text-slate-800 dark:text-slate-200">
                {taxRate}%
              </span>
            </div>

            <div className="flex justify-between items-center gap-10">
              <span className="text-xs font-bold text-slate-500 dark:text-slate-400">Discount ({currencySymbol})</span>
              <input
                type="range"
                min={0}
                max={Math.min(subtotal, 500)}
                value={discount}
                onChange={(e) => setDiscount(parseInt(e.target.value) || 0)}
                className="flex-1 mt-1 cursor-pointer"
              />
              <span className="text-xs font-bold font-mono bg-slate-200 dark:bg-slate-850 px-2 py-0.5 rounded text-slate-800 dark:text-slate-200">
                {currencySymbol}{discount}
              </span>
            </div>
          </div>
        </div>

      </div>

      {/* 2. Interactive Premium Live Preview Area with Print Styles */}
      <div className="space-y-4">
        <div className="flex justify-between items-center border-t border-slate-150 dark:border-slate-850 pt-6">
          <div className="space-y-1">
            <h4 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-1">
              <FileText className="h-4 w-4 text-indigo-500" /> Interactive Blueprint Layout Preview
            </h4>
            <p className="text-[10px] text-slate-400 dark:text-slate-450 font-bold leading-none">Use Custom colors and print options directly below.</p>
          </div>
          <button
            onClick={triggerPrint}
            className="px-4.5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs tracking-wide rounded-xl shadow-md cursor-pointer select-none flex items-center gap-1.5 transition"
          >
            <Printer className="h-4 w-4" /> Export High DPI PDF / Print
          </button>
        </div>

        {/* Invoice template visual chassis */}
        <div 
          id="invoice-print-area" 
          className={`print:p-12 p-6 md:p-10 bg-white border border-slate-200 text-slate-800 rounded-3xl min-h-[640px] shadow-sm flex flex-col justify-between relative overflow-hidden`}
          style={{ width: "100%", maxWidth: "800px", margin: "0 auto" }}
        >
          {/* Style 1: Modern Professional */}
          {templateStyle === "modern" && (
            <div className="space-y-10">
              <div className="flex justify-between items-start">
                <div className="space-y-4">
                  {logo ? (
                    <img src={logo} alt="Brand logo" className="max-h-12 max-w-[150px] object-contain rounded" />
                  ) : (
                    <div className="flex h-11 w-11 items-center justify-center rounded-lg text-white" style={{ backgroundColor: brandColor }}>
                      <Briefcase className="h-6 w-6" />
                    </div>
                  )}
                  <div className="space-y-1">
                    <h5 className="text-lg font-black tracking-tight" style={{ color: brandColor }}>{senderName}</h5>
                    <p className="text-[11px] text-slate-450 leading-relaxed whitespace-pre-line font-medium">{senderDetails}</p>
                  </div>
                </div>

                <div className="text-right space-y-1.5">
                  <span className="text-[10px] font-black tracking-widest uppercase text-slate-400">COMMERCIAL INVOICE</span>
                  <h3 className="text-2xl font-black font-mono tracking-tight text-slate-900">{invoiceNum}</h3>
                  <div className="text-[11px] text-slate-500 font-semibold space-y-0.5">
                    <div>Date: <span className="text-slate-800 font-bold font-mono">{invoiceDate}</span></div>
                    <div>Due: <span className="text-slate-800 font-bold font-mono">{invoiceDueDate}</span></div>
                  </div>
                </div>
              </div>

              <div className="border-t border-slate-100 pt-6 grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <span className="text-[9px] font-black uppercase tracking-widest text-slate-400 block mb-2">BILLED INVOICE TO</span>
                  <h4 className="text-sm font-black text-slate-850 mb-1">{clientName}</h4>
                  <p className="text-[11px] text-slate-450 leading-relaxed whitespace-pre-line font-medium">{clientDetails}</p>
                </div>
              </div>

              {/* Items list table */}
              <div className="space-y-3">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b-2 border-slate-150 text-[10px] font-extrabold uppercase text-slate-400 tracking-wider">
                      <th className="py-2.5">Project Description & Services</th>
                      <th className="py-2.5 text-center w-16">Qty</th>
                      <th className="py-2.5 text-right w-24">Rate</th>
                      <th className="py-2.5 text-right w-28">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-xs font-semibold text-slate-700">
                    {items.map((item) => (
                      <tr key={item.id}>
                        <td className="py-3.5 leading-snug">{item.desc}</td>
                        <td className="py-3.5 text-center font-mono">{item.qty}</td>
                        <td className="py-3.5 text-right font-mono">{currencySymbol}{item.rate.toFixed(2)}</td>
                        <td className="py-3.5 text-right font-mono font-bold text-slate-900">{currencySymbol}{(item.qty * item.rate).toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Aggregated sums */}
              <div className="flex flex-col items-end pt-6 border-t border-slate-100 space-y-2">
                <div className="w-64 space-y-1.5 text-xs font-semibold text-slate-500">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span className="font-mono font-bold text-slate-800">{currencySymbol}{subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Tax / GST ({taxRate}%)</span>
                    <span className="font-mono font-bold text-slate-800">{currencySymbol}{taxAmount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Savings / Discount</span>
                    <span className="font-mono font-bold text-emerald-600">-{currencySymbol}{discount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-base font-black border-t border-slate-100 pt-3 text-slate-900 mt-2">
                    <span style={{ color: brandColor }}>Total Due</span>
                    <span className="font-mono text-lg" style={{ color: brandColor }}>{currencySymbol}{finalTotal.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Style 2: Classic Executive */}
          {templateStyle === "classic" && (
            <div className="space-y-10 border-4 border-double p-6" style={{ borderColor: brandColor }}>
              <div className="text-center space-y-2">
                <h2 className="text-3xl font-black serif uppercase tracking-widest leading-none" style={{ color: brandColor }}>STATEMENT OF INVOICE</h2>
                <div className="h-0.5 w-32 bg-slate-300 mx-auto" />
                <p className="text-xs font-mono font-bold text-slate-450 uppercase">REF: {invoiceNum} | DATE: {invoiceDate}</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 text-xs pt-4 border-b pb-6">
                <div className="space-y-1.5">
                  <h4 className="font-bold text-indigo-950 uppercase border-b pb-1">FROM</h4>
                  <h5 className="font-black text-sm">{senderName}</h5>
                  <p className="text-slate-450 whitespace-pre-line leading-relaxed font-sans">{senderDetails}</p>
                </div>
                <div className="space-y-1.5">
                  <h4 className="font-bold text-indigo-950 uppercase border-b pb-1">INVOICED TO</h4>
                  <h5 className="font-black text-sm">{clientName}</h5>
                  <p className="text-slate-450 whitespace-pre-line leading-relaxed font-sans">{clientDetails}</p>
                </div>
              </div>

              <div className="space-y-4">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-50 text-[10px] font-black uppercase text-slate-600 border border-slate-200">
                      <th className="p-2 border border-slate-200">Description of Service</th>
                      <th className="p-2 border border-slate-200 text-center w-16">Hours</th>
                      <th className="p-2 border border-slate-200 text-right w-24">Rate</th>
                      <th className="p-2 border border-slate-200 text-right w-28">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="font-sans">
                    {items.map((item, idx) => (
                      <tr key={item.id} className={idx % 2 === 0 ? "bg-white" : "bg-slate-50/50"}>
                        <td className="p-2 border border-slate-200">{item.desc}</td>
                        <td className="p-2 border border-slate-200 text-center font-mono">{item.qty}</td>
                        <td className="p-2 border border-slate-200 text-right font-mono">{currencySymbol}{item.rate.toFixed(2)}</td>
                        <td className="p-2 border border-slate-200 text-right font-mono font-bold">{currencySymbol}{(item.qty * item.rate).toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="flex justify-between items-start pt-6 border-t">
                <div className="text-[10px] text-slate-400 font-bold max-w-xs leading-relaxed italic">
                  Thank you for your commercial partnership. Please settle invoice balances before <span className="font-sans font-black text-slate-600">{invoiceDueDate}</span> via bank or wire structures.
                </div>
                <div className="w-60 text-xs space-y-1 bg-slate-50 p-4 border rounded">
                  <div className="flex justify-between">
                    <span className="font-bold">Subtotal:</span>
                    <span className="font-mono">{currencySymbol}{subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-bold">Vat/Tax ({taxRate}%):</span>
                    <span className="font-mono">{currencySymbol}{taxAmount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-emerald-700">
                    <span className="font-bold">Discount:</span>
                    <span className="font-mono">-{currencySymbol}{discount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm font-black border-t pt-2 text-slate-900 mt-2">
                    <span>Grand Total:</span>
                    <span className="font-mono text-base" style={{ color: brandColor }}>{currencySymbol}{finalTotal.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Style 3: Minimal Corporate */}
          {templateStyle === "corporate" && (
            <div className="space-y-8 font-sans">
              <div className="h-2 w-full" style={{ backgroundColor: brandColor }} />
              <div className="flex justify-between items-start">
                <div className="space-y-1">
                  <h3 className="text-xl font-bold tracking-wider uppercase" style={{ color: brandColor }}>{senderName}</h3>
                  <p className="text-[11px] whitespace-pre-line text-slate-450 leading-relaxed font-semibold">{senderDetails}</p>
                </div>
                {logo && <img src={logo} alt="Corporate Brand Logo" className="max-h-10 max-w-[120px] object-contain" />}
              </div>

              <div className="bg-slate-50 p-4 rounded-xl flex justify-between items-center text-xs border border-slate-100">
                <div>
                  <span className="text-[9px] font-bold text-slate-400 block uppercase">Reference Number</span>
                  <span className="font-mono font-bold text-slate-700">{invoiceNum}</span>
                </div>
                <div>
                  <span className="text-[9px] font-bold text-slate-400 block uppercase">Issue Term</span>
                  <span className="font-bold text-slate-700">{invoiceDate}</span>
                </div>
                <div>
                  <span className="text-[9px] font-bold text-slate-400 block uppercase">Target Term</span>
                  <span className="font-bold text-slate-700">{invoiceDueDate}</span>
                </div>
                <div>
                  <span className="text-[9px] font-bold text-slate-400 block uppercase">Amount Payable</span>
                  <span className="font-bold font-mono text-sm text-slate-900">{currencySymbol}{finalTotal.toFixed(2)}</span>
                </div>
              </div>

              <div className="space-y-2">
                <span className="text-[9px] font-black uppercase text-slate-400 tracking-wider">RECIPIENT PARTY</span>
                <h5 className="font-black text-sm text-slate-800">{clientName}</h5>
                <p className="text-[11px] whitespace-pre-line text-slate-450 leading-relaxed font-semibold">{clientDetails}</p>
              </div>

              <div className="space-y-4 pt-4">
                <table className="w-full text-left">
                  <thead className="bg-slate-800 text-white text-[9px] tracking-wider uppercase font-extrabold">
                    <tr>
                      <th className="p-2.5 rounded-l">Service Lines</th>
                      <th className="p-2.5 text-center w-16">Units</th>
                      <th className="p-2.5 text-right w-24">Price</th>
                      <th className="p-2.5 text-right w-28 rounded-r">Lines total</th>
                    </tr>
                  </thead>
                  <tbody className="text-xs font-semibold text-slate-700 divide-y divide-slate-100">
                    {items.map((item) => (
                      <tr key={item.id}>
                        <td className="p-2.5 leading-snug">{item.desc}</td>
                        <td className="p-2.5 text-center font-mono text-slate-500">{item.qty}</td>
                        <td className="p-2.5 text-right font-mono text-slate-500">{currencySymbol}{item.rate.toFixed(2)}</td>
                        <td className="p-2.5 text-right font-mono font-bold text-slate-900">{currencySymbol}{(item.qty * item.rate).toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="flex justify-between items-end pt-6 border-t border-slate-100">
                <div className="text-[10px] text-slate-400 tracking-wide leading-relaxed font-medium">
                  Compliance and local sandbox security validation stamped. Generated via MTH Secure Invoice platform.
                </div>
                <div className="w-60 text-xs space-y-1">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Total subtotal:</span>
                    <span className="font-mono font-bold text-slate-750">{currencySymbol}{subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Tax rate GST/VAT:</span>
                    <span className="font-mono font-bold text-slate-750">{currencySymbol}{taxAmount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-emerald-600">
                    <span>Discount overlay:</span>
                    <span className="font-mono font-bold">-{currencySymbol}{discount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm font-black border-t border-slate-100 pt-2 text-slate-900 mt-2">
                    <span>Total Net Payment:</span>
                    <span className="font-mono text-base" style={{ color: brandColor }}>{currencySymbol}{finalTotal.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Secure MTH sandboxed watermark at are boundaries (doesn't render in prints) */}
          <div className="print:hidden text-[9px] font-black text-slate-350 tracking-wider text-center pt-8 border-t border-slate-50 select-none uppercase">
            🛡️ SECURED LOCALLY VIA MYTOOLSHUB BROWSER ENCLAVE
          </div>
        </div>
      </div>
    </div>
  );
}
