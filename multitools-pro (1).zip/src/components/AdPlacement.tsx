import React, { useState } from "react";
import { Sparkles, Megaphone } from "lucide-react";

interface AdPlacementProps {
  type: "header" | "sidebar" | "content" | "native";
  label?: string;
}

export default function AdPlacement({ type, label }: AdPlacementProps) {
  const [closed, setClosed] = useState(false);

  if (closed) return null;

  const styles = {
    header: "w-full min-h-[90px] py-4 bg-slate-50 dark:bg-slate-900/30 border border-dashed border-slate-200 dark:border-slate-800 rounded-2xl flex flex-col items-center justify-center text-center px-4",
    sidebar: "w-full min-h-[450px] bg-slate-50 dark:bg-slate-900/30 border border-dashed border-slate-200 dark:border-slate-800 rounded-2xl flex flex-col items-center justify-center text-center p-6",
    content: "w-full min-h-[250px] bg-slate-50 dark:bg-slate-900/30 border border-dashed border-slate-200 dark:border-slate-800/80 rounded-2xl flex flex-col items-center justify-center text-center p-8",
    native: "w-full py-6 px-6 bg-slate-50 dark:bg-slate-900/30 border border-slate-100 dark:border-slate-800 rounded-2xl flex flex-col sm:flex-row items-center gap-4 justify-between"
  };

  return (
    <div className={`${styles[type]} relative overflow-hidden transition-all duration-300 group`}>
      {/* Background soft pulse effect */}
      <div className="absolute inset-0 bg-slate-100/50 dark:bg-slate-800/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />

      <div className="relative flex flex-col items-center text-center space-y-2">
        <div className="flex items-center gap-1.5 px-2.5 py-0.5 bg-slate-200/80 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded text-[9px] font-bold uppercase tracking-wider select-none">
          <Megaphone className="h-2.5 w-2.5 text-indigo-505" /> Sponsor Space
        </div>
        
        <p className="text-slate-800 dark:text-slate-200 text-xs font-semibold">
          {label || (type === "header" ? "AdSense Banner Zone (728x90)" : type === "sidebar" ? "Vertical Tower (160x600)" : "Interactive Custom Content Bloc")}
        </p>
        
        <p className="text-[10px] text-slate-450 dark:text-slate-400 max-w-sm leading-relaxed">
          This container is optimized for high-yield programmatic Google AdSense slots. Placements remain static with defined frame ratios, preventing annoying layout shifts.
        </p>
      </div>

      <button 
        onClick={() => setClosed(true)} 
        className="absolute top-2.5 right-3 text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300 text-[10px] uppercase font-bold cursor-pointer transition-colors"
        title="Hide sponsored block"
      >
        Dismiss
      </button>
    </div>
  );
}
