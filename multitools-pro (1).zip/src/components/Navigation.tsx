import React, { useState, useEffect, useRef } from "react";
import { 
  Search, Compass, Sun, Moon, ArrowRight, BookOpen, ChevronDown, 
  Menu, X, Sparkles, Filter, ShieldCheck, Mail
} from "lucide-react";
import { TOOLS, CATEGORIES, ToolData } from "../data/tools";
import ToolIcon from "./ToolIcon";

interface NavigationProps {
  currentRoute: { page: string; slug?: string };
  navigateTo: (page: string, slug?: string) => void;
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  searchQuery: string;
  setSearchQuery: (val: string) => void;
}

export default function Navigation({ currentRoute, navigateTo, darkMode, setDarkMode, searchQuery, setSearchQuery }: NavigationProps) {
  const [searchResults, setSearchResults] = useState<ToolData[]>([]);
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [isCatDropdownOpen, setIsCatDropdownOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  const searchContainerRef = useRef<HTMLDivElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const searchLower = searchQuery.toLowerCase().trim();
    if (!searchLower) {
      setSearchResults([]);
      return;
    }
    const searchWords = searchLower.split(/\s+/);
    const filtered = TOOLS.filter((tool) =>
      searchWords.every(word =>
        tool.title.toLowerCase().includes(word) ||
        tool.description.toLowerCase().includes(word) ||
        tool.category.toLowerCase().includes(word) ||
        tool.slug.toLowerCase().includes(word) ||
        (tool.features && tool.features.some(f => f.toLowerCase().includes(word)))
      )
    ).slice(0, 8);
    setSearchResults(filtered);
  }, [searchQuery]);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchContainerRef.current && !searchContainerRef.current.contains(event.target as Node)) {
        setIsSearchFocused(false);
      }
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsCatDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Set premium light root class unconditionally
  useEffect(() => {
    document.documentElement.classList.remove("dark");
  }, []);

  return (
    <header className="sticky top-0 z-50 w-full border-b border-slate-100 bg-white/85 backdrop-blur-md transition-all duration-300 shadow-sm">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        
        {/* Brand Logo & Trust badge */}
        <div className="flex items-center gap-4">
          <div 
            onClick={() => {
              navigateTo("home");
              // Also reset dynamic filters on home page
              window.location.hash = "#/";
            }} 
            className="flex items-center gap-3 cursor-pointer select-none group"
          >
            <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-tr from-indigo-500 to-violet-600 text-white shadow-md group-hover:scale-105 transition-all">
              <Sparkles className="h-4 w-4 text-indigo-100 animate-pulse absolute -top-1 -right-1" />
              <span className="font-extrabold text-xl leading-none italic tracking-wider">M</span>
            </div>
            <div>
              <h1 className="text-base font-black tracking-tight text-slate-900 flex items-center gap-1 leading-none">
                MyTools<span className="text-[10px] bg-indigo-50 text-indigo-600 border border-indigo-100 px-1.5 py-0.5 rounded font-bold uppercase tracking-wider">Hub</span>
              </h1>
              <span className="text-[10px] text-slate-500 font-bold tracking-wide">Secure Browser MTH Platform</span>
            </div>
          </div>
 
          {/* Secure SSL Pill Tag */}
          <div className="hidden md:flex items-center gap-1 px-2.5 py-1 bg-emerald-50 border border-emerald-100 text-emerald-700 rounded-full text-[10px] font-extrabold select-none hover:bg-emerald-100 transition-all duration-300 cursor-default">
            <ShieldCheck className="h-3.5 w-3.5 text-emerald-600" />
            <span>SSL SECURED & PRIVACY GUARANTEED</span>
          </div>
        </div>

        {/* Categories Dropdown & Core Links Menu */}
        <nav className="hidden lg:flex items-center gap-6">
          {/* Categories Dropdown trigger */}
          <div ref={dropdownRef} className="relative">
            <button
              onClick={() => setIsCatDropdownOpen(!isCatDropdownOpen)}
              className="flex items-center gap-1.5 text-xs font-bold text-slate-600 hover:text-slate-900 transition cursor-pointer select-none"
            >
              <Filter className="h-3.5 w-3.5" />
              <span>Browse Categories</span>
              <ChevronDown className={`h-3 w-3 transition-transform duration-300 ${isCatDropdownOpen ? "rotate-180" : ""}`} />
            </button>
 
            {isCatDropdownOpen && (
              <div className="absolute top-full left-0 w-80 bg-white border border-slate-100 rounded-2xl shadow-xl mt-3 p-4 grid grid-cols-1 gap-2 z-50">
                <div className="text-[10px] uppercase tracking-widest font-extrabold text-slate-400 pb-2 border-b border-slate-100 mb-1">
                  Filter Tools by Category
                </div>
                {CATEGORIES.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => {
                      navigateTo("home");
                      // Dispatch hash change with custom query action
                      setTimeout(() => {
                        const hash = `#/category/${cat.id}`;
                        window.location.hash = hash;
                      }, 50);
                      setIsCatDropdownOpen(false);
                    }}
                    className="flex items-center gap-3 p-2.5 rounded-xl text-left hover:bg-slate-50 group transition cursor-pointer"
                  >
                    <div className={`p-1.5 rounded-lg ${cat.bg} text-indigo-600`}>
                      <ToolIcon name={cat.icon} className="h-4 w-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-705 group-hover:text-slate-950">
                        {cat.name}
                      </h4>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          <button 
            onClick={() => navigateTo("blog")}
            className="flex items-center gap-1.5 text-xs font-bold text-slate-600 dark:text-slate-300 hover:text-slate-950 dark:hover:text-white transition cursor-pointer"
          >
            <BookOpen className="h-3.5 w-3.5" />
            <span>Blog Editorial</span>
          </button>

          <button 
            onClick={() => navigateTo("about")}
            className="text-xs font-bold text-slate-600 dark:text-slate-300 hover:text-slate-950 dark:hover:text-white transition cursor-pointer"
          >
            <span>Our Security Architecture</span>
          </button>

          <button 
            onClick={() => navigateTo("admin")}
            className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:text-indigo-850 dark:hover:text-indigo-300 transition cursor-pointer"
          >
            <span>Admin CP</span>
          </button>
        </nav>

        {/* Smart Search Panel (Medium and Large Screens) */}
        <div ref={searchContainerRef} className="relative hidden md:block w-full max-w-sm mx-4">
          <div className="relative">
            <Search className="absolute top-2.5 left-3.5 h-3.5 w-3.5 text-slate-400" />
            <input
              type="text"
              placeholder="Instant search (e.g., PDF compressor)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onFocus={() => setIsSearchFocused(true)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  navigateTo("home");
                  setIsSearchFocused(false);
                  setTimeout(() => {
                    const el = document.getElementById("tools-anchor");
                    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
                  }, 100);
                }
              }}
              className="w-full pl-10 pr-4 py-2 bg-slate-50 hover:bg-slate-100/70 rounded-xl border border-slate-200 text-slate-800 focus:outline-none focus:ring-1.5 focus:ring-indigo-550 focus:bg-white placeholder-slate-400 text-xs transition-all font-medium"
            />
          </div>
 
          {/* Elegant Floating Suggestions Grid */}
          {isSearchFocused && searchQuery.trim() !== "" && (
            <div className="absolute top-full left-0 w-full bg-white border border-slate-100 rounded-2xl shadow-xl mt-2 overflow-hidden z-50">
              <div className="p-3 text-[10px] font-extrabold text-slate-400 bg-slate-50 uppercase tracking-widest flex justify-between items-center">
                <span>Matching Live Suggestions</span>
                <span className="text-[9px] bg-slate-200 text-slate-600 px-1.5 rounded-full">{searchResults.length} found</span>
              </div>
              <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto">
                {searchResults.map((tool) => (
                  <div
                    key={tool.slug}
                    onClick={() => {
                      navigateTo("tool", tool.slug);
                      setIsSearchFocused(false);
                      setSearchQuery("");
                    }}
                    className="p-3 hover:bg-slate-50 cursor-pointer transition flex items-start gap-3"
                  >
                    <div className="p-2 bg-slate-100 text-slate-700 rounded-lg shrink-0 mt-0.5">
                      <ToolIcon name={tool.icon} className="h-3.5 w-3.5" />
                    </div>
                    <div className="space-y-0.5 min-w-0">
                      <h4 className="text-xs font-bold text-slate-800 truncate">{tool.title}</h4>
                      <p className="text-[10px] text-slate-500 truncate">{tool.description}</p>
                    </div>
                  </div>
                ))}
                {searchResults.length === 0 && (
                  <div className="p-4 text-center text-xs text-slate-400 font-semibold">No fast tools matched.</div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Theme Settings & CTA Toggle Switches */}
        <div className="flex items-center gap-3">
          {/* Quick Contact Button */}
          <button 
            onClick={() => navigateTo("contact")}
            className="hidden sm:flex items-center gap-1.5 px-4 h-9 bg-indigo-650 hover:bg-[#524bf2] text-white rounded-xl text-xs font-bold transition select-none shadow-md shadow-indigo-100 cursor-pointer"
          >
            <span>Contact Admin</span>
            <Mail className="h-3.5 w-3.5" />
          </button>

          {/* Mobile hamburger menu toggle */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="p-2 text-slate-500 hover:text-slate-900 rounded-xl hover:bg-slate-100 lg:hidden cursor-pointer"
          >
            {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>

      </div>

      {/* Mobile Menu Panel Drawer Drawer */}
      {isMobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-100 bg-white p-4 space-y-4 shadow-xl select-none">
          <div className="space-y-1">
            <h3 className="text-[10px] uppercase font-black text-slate-400 px-3 pb-2">Primary Pages</h3>
            <button 
              onClick={() => { navigateTo("home"); setIsMobileMenuOpen(false); }}
              className="w-full text-left px-3 py-2 text-xs font-bold text-slate-705 hover:bg-slate-50 rounded-lg block"
            >
              Home Utilities Index
            </button>
            <button 
              onClick={() => { navigateTo("blog"); setIsMobileMenuOpen(false); }}
              className="w-full text-left px-3 py-2 text-xs font-bold text-slate-705 hover:bg-slate-50 rounded-lg block"
            >
              Blog & Guidelines
            </button>
            <button 
              onClick={() => { navigateTo("about"); setIsMobileMenuOpen(false); }}
              className="w-full text-left px-3 py-2 text-xs font-bold text-slate-705 hover:bg-slate-50 rounded-lg block"
            >
              Security Blueprint
            </button>
            <button 
              onClick={() => { navigateTo("contact"); setIsMobileMenuOpen(false); }}
              className="w-full text-left px-3 py-2 text-xs font-bold text-slate-705 hover:bg-slate-50 rounded-lg block"
            >
              Contact Support Desk
            </button>
            <button 
              onClick={() => { navigateTo("admin"); setIsMobileMenuOpen(false); }}
              className="w-full text-left px-3 py-2 text-xs font-bold text-indigo-600 hover:bg-indigo-50 rounded-lg block"
            >
              Admin Control Panel
            </button>
          </div>

          <div className="border-t border-slate-100 pt-3 space-y-2">
            <h3 className="text-[10px] uppercase font-black text-slate-400 px-3">Top Category Channels</h3>
            <div className="grid grid-cols-2 gap-1.5 px-1.5">
              {CATEGORIES.slice(0, 4).map((c) => (
                <button
                  key={c.id}
                  onClick={() => {
                    navigateTo("home");
                    setTimeout(() => {
                      window.location.hash = `#/category/${c.id}`;
                    }, 50);
                    setIsMobileMenuOpen(false);
                  }}
                  className="p-2 border border-slate-150 hover:border-indigo-500 rounded-lg text-[11px] font-semibold text-slate-700 flex items-center gap-1 bg-slate-50 text-left cursor-pointer"
                >
                  <ToolIcon name={c.icon} className="h-3.5 w-3.5 text-indigo-650" />
                  <span className="truncate">{c.name}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
