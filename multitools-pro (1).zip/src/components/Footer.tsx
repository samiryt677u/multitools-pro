import React from "react";
import { 
  ArrowUpRight, Scale, ShieldCheck, FileSpreadsheet, Contact2, HelpCircle, 
  Twitter, Github, Linkedin, Slack, Compass, Mail, Phone, BookOpen, Database
} from "lucide-react";
import { CATEGORIES } from "../data/tools";

interface FooterProps {
  navigateTo: (page: string, slug?: string) => void;
}

export default function Footer({ navigateTo }: FooterProps) {
  return (
    <footer className="bg-slate-950 text-slate-300 border-t border-slate-900 font-sans transition-colors duration-300">
      
      {/* 1. Main Footer Grid Grid */}
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 space-y-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          
          {/* Brand/Product Col - 2 spans wide on lg */}
          <div className="space-y-4 lg:col-span-2">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-600 text-white font-extrabold text-xl shadow-md ring-1 ring-white/10 italic">
                M
              </div>
              <div>
                <h2 className="text-sm font-black tracking-tight text-white flex items-center gap-1.5 leading-none">
                  MyTools<span className="text-[10px] bg-indigo-500/20 text-indigo-400 px-1.5 py-0.5 rounded font-bold uppercase tracking-wider">Hub</span>
                </h2>
                <span className="text-[10px] text-slate-500 font-bold tracking-wide">Secure Browser Sandbox Suite</span>
              </div>
            </div>
            
            <p className="text-slate-400 text-xs sm:text-xs leading-relaxed max-w-sm">
              MyToolsHub represents a monumental shift in web utilities. By processing complex mathematical loans, image conversion blocks, and PDF optimizations directly on the browser client, user assets remain isolated from foreign cloud databases. 100% free, confidential, and compliant.
            </p>

            {/* Social channels metrics */}
            <div className="flex items-center gap-3 pt-2">
              <a 
                href="#/about" 
                onClick={(e) => { e.preventDefault(); navigateTo("about"); }}
                className="p-2 bg-slate-900 hover:bg-slate-850 hover:text-white rounded-lg text-slate-450 transition" 
                title="Follow Twitter Updates"
              >
                <Twitter className="h-4 w-4" />
              </a>
              <a 
                href="#/about" 
                onClick={(e) => { e.preventDefault(); navigateTo("about"); }}
                className="p-2 bg-slate-900 hover:bg-slate-850 hover:text-white rounded-lg text-slate-450 transition" 
                title="Check code on GitHub"
              >
                <Github className="h-4 w-4" />
              </a>
              <a 
                href="#/about" 
                onClick={(e) => { e.preventDefault(); navigateTo("about"); }}
                className="p-2 bg-slate-900 hover:bg-slate-850 hover:text-white rounded-lg text-slate-450 transition" 
                title="Connect with Enterprise team"
              >
                <Linkedin className="h-4 w-4" />
              </a>
              <a 
                href="#/about" 
                onClick={(e) => { e.preventDefault(); navigateTo("about"); }}
                className="p-2 bg-slate-900 hover:bg-slate-850 hover:text-white rounded-lg text-slate-450 transition" 
                title="Join Community Slack Channel"
              >
                <Slack className="h-4 w-4" />
              </a>
            </div>
          </div>

          {/* Quick Category Modules */}
          <div className="space-y-4 col-span-1">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">Tools Directory</h3>
            <ul className="space-y-2.5 text-xs text-slate-400 font-medium">
              {CATEGORIES.slice(0, 5).map((cat) => (
                <li key={`footer-cat-${cat.id}`}>
                  <button 
                    onClick={() => {
                      navigateTo("home");
                      setTimeout(() => {
                        window.location.hash = `#/category/${cat.id}`;
                      }, 100);
                    }} 
                    className="hover:text-white transition flex items-center gap-1.5 cursor-pointer text-left"
                  >
                    <span>{cat.name}</span>
                    <ArrowUpRight className="h-3 w-3 text-slate-500" />
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Featured Tools Selection */}
          <div className="space-y-4 col-span-1">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">Core Utilities</h3>
            <ul className="space-y-2.5 text-xs text-slate-400 font-medium">
              <li>
                <button onClick={() => navigateTo("tool", "pdf-compressor")} className="hover:text-white transition flex items-center gap-1.5 cursor-pointer text-left">
                  PDF Compressor
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo("tool", "merge-pdf")} className="hover:text-white transition flex items-center gap-1.5 cursor-pointer text-left">
                  Merge PDF Documents
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo("tool", "gst-calculator")} className="hover:text-white transition flex items-center gap-1.5 cursor-pointer text-left">
                  GST Invoice Calcs
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo("tool", "sip-calculator")} className="hover:text-white transition flex items-center gap-1.5 cursor-pointer text-left">
                  SIP Compound Planner
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo("tool", "password-generator")} className="hover:text-white transition flex items-center gap-1.5 cursor-pointer text-left">
                  Secure Password Gen
                </button>
              </li>
            </ul>
          </div>

          {/* AdSense Compliance Pages & Corporate */}
          <div className="space-y-4 col-span-1">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">Compliance & Trust</h3>
            <div className="flex flex-col gap-2 text-xs text-slate-400 font-medium">
              <button onClick={() => navigateTo("about")} className="hover:text-white transition text-left flex items-center gap-1.5 cursor-pointer">
                <HelpCircle className="h-3.5 w-3.5 text-slate-500" /> About Platform
              </button>
              <button onClick={() => navigateTo("contact")} className="hover:text-white transition text-left flex items-center gap-1.5 cursor-pointer">
                <Contact2 className="h-3.5 w-3.5 text-slate-500" /> Contact Support Desk
              </button>
              <button onClick={() => navigateTo("privacy")} className="hover:text-white transition text-left flex items-center gap-1.5 cursor-pointer">
                <ShieldCheck className="h-3.5 w-3.5 text-slate-500" /> Privacy Guidelines
              </button>
              <button onClick={() => navigateTo("terms")} className="hover:text-white transition text-left flex items-center gap-1.5 cursor-pointer">
                <Scale className="h-3.5 w-3.5 text-slate-500" /> Terms and Conditions
              </button>
              <button onClick={() => navigateTo("disclaimer")} className="hover:text-white transition text-left flex items-center gap-1.5 cursor-pointer">
                <FileSpreadsheet className="h-3.5 w-3.5 text-slate-500" /> Regulatory Disclaimer
              </button>
              <button onClick={() => navigateTo("admin")} className="hover:text-white transition text-left flex items-center gap-1.5 cursor-pointer">
                <Database className="h-3.5 w-3.5 text-slate-500" /> Administrative Dashboard
              </button>
            </div>
          </div>

        </div>

        {/* 2. SEO Content Paragraph (Extremely useful for organic search crawlers crawling) */}
        <div className="mt-12 border-t border-slate-900 pt-8 text-center text-slate-500 text-[11px] leading-relaxed max-w-5xl mx-auto space-y-4 shrink-0 selection:bg-indigo-650 select-text">
          <p>
            <strong>Standard Guidelines & Regulatory Compliance Notice:</strong> MyToolsHub provides non-proprietary browser utilities. All PDF compactions, image scalers, financial amortization calculations, and metadata markup code transformations happen 100% on the client. We never catalog or cache uploaded payloads. Use of this utility platform is governed under our standard Terms and Conditions. Contact our security administrators for questions.
          </p>
          <p className="text-slate-600 font-semibold tracking-wider uppercase text-[9px]">
            &copy; 2026 MyToolsHub Inc. Built for superior Core Web Vitals, ultra low latency rendering, and organic Google visibility. All rights reserved.
          </p>
        </div>

        {/* Dynamic structured Organization & Search Schema for crawlers */}
        <script 
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Organization",
              "name": "MyToolsHub",
              "url": typeof window !== "undefined" ? window.location.origin : "https://mytoolshub.com",
              "logo": typeof window !== "undefined" ? `${window.location.origin}/favicon.png` : "https://mytoolshub.com/favicon.png",
              "description": "Pristine offline web utilities processing directly in-browser. Fast, private, and secure.",
              "sameAs": [
                "https://twitter.com",
                "https://github.com"
              ],
              "potentialAction": {
                "@type": "SearchAction",
                "target": typeof window !== "undefined" ? `${window.location.origin}/#/?q={search_term_string}` : "https://mytoolshub.com/#/?q={search_term_string}",
                "query-input": "required name=search_term_string"
              }
            })
          }}
        />

      </div>
    </footer>
  );
}
