import React, { useState, useEffect } from "react";
import { ShieldAlert, ArrowRight, ShieldCheck } from "lucide-react";

export default function CookieNotice() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem("cookieConsentAccepted");
    if (!consent) {
      setTimeout(() => setVisible(true), 1500); // Wait 1.5s for polished feel
    }
  }, []);

  const acceptConsent = () => {
    localStorage.setItem("cookieConsentAccepted", "true");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="fixed bottom-6 right-6 left-6 md:left-auto md:max-w-md z-50 bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 text-white transition-all duration-300 animate-slide-in">
      <div className="space-y-4">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 bg-slate-850 text-slate-200 rounded-lg">
            <ShieldCheck className="h-5 w-5" />
          </div>
          <h4 className="font-bold text-sm tracking-tight">Privacy & Consent Guidelines</h4>
        </div>

        <p className="text-xs text-slate-400 leading-relaxed">
          MyToolsHub uses cookies, session caches, and standard web technologies to optimize Core Web Vitale responsive speeds and measure AdSense analytics performance. No database records are kept.
        </p>

        <div className="flex gap-3 justify-end pt-2">
          <button 
            onClick={() => setVisible(false)} 
            className="px-3.5 py-1.5 hover:bg-slate-800 text-slate-300 text-xs font-bold rounded-xl transition"
          >
            Manage Setup
          </button>
          <button 
            onClick={acceptConsent} 
            className="px-4 py-1.5 bg-white text-slate-900 hover:bg-slate-100 text-xs font-bold rounded-xl transition flex items-center gap-1.5 cursor-pointer"
          >
            <span>Accept All</span>
            <ArrowRight className="h-3.5 w-3.5 font-bold" />
          </button>
        </div>
      </div>
    </div>
  );
}
