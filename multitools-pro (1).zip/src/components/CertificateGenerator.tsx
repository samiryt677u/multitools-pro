import React, { useState, useRef } from "react";
import { Award, Printer, Check, Palette, Upload, Trash2, ShieldCheck, Heart } from "lucide-react";

export default function CertificateGenerator() {
  const [recipientName, setRecipientName] = useState("Jennifer Lawrence");
  const [certTitle, setCertTitle] = useState("Certificate of Excellence");
  const [customCitation, setCustomCitation] = useState("For exemplary leadership and outstanding engineering contributions inside the browser-side sandboxed local workspace during the 2026 Systems Migration Initiative.");
  const [awardingBody, setAwardingBody] = useState("MyToolsHub Global Board of Standards");
  const [signName, setSignName] = useState("Lord Richard Stark");
  const [signTitle, setSignTitle] = useState("Managing Trustee & Director");
  const [issueDate, setIssueDate] = useState("2026-05-28");
  const [certificateId, setCertificateId] = useState("MTH-EXCEL-98321B");
  
  const [sealImage, setSealImage] = useState<string | null>(null);
  
  const [layoutStyle, setLayoutStyle] = useState<"royal" | "corporate" | "academic">("royal");
  const [fontStyle, setFontStyle] = useState<"font-serif" | "font-sans" | "font-mono">("font-serif");
  const [accentColor, setAccentColor] = useState("#b45309"); // gold-ish amber-700

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSealUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const url = URL.createObjectURL(e.target.files[0]);
      setSealImage(url);
    }
  };

  const removeSeal = () => {
    setSealImage(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handlePrint = () => {
    window.print();
  };

  const accentSchemes = [
    { name: "Royal Gold", hex: "#b45309" },
    { name: "Deep Navy", hex: "#1e3a8a" },
    { name: "Jade Teal", hex: "#0f766e" },
    { name: "Burgundy", hex: "#881337" },
    { name: "Slate", hex: "#334155" }
  ];

  return (
    <div className="space-y-8 text-sm">
      {/* 1. Control Parameters Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Parameter Inputs */}
        <div className="lg:col-span-6 space-y-5 bg-slate-50 dark:bg-slate-900 border border-slate-150 p-5 rounded-2xl">
          <h3 className="text-xs font-black uppercase tracking-widest text-slate-450 dark:text-slate-500 flex items-center gap-1.5 border-b border-slate-200 dark:border-slate-800 pb-2">
            <Palette className="h-4 w-4 text-amber-600" /> Certificate Credentials & Style
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Frame Border Style</label>
              <div className="flex gap-1.5">
                {[
                  { id: "royal", name: "Royal Gold" },
                  { id: "corporate", name: "Corporate" },
                  { id: "academic", name: "Academic" }
                ].map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setLayoutStyle(t.id as any)}
                    className={`flex-1 py-1.5 text-xs font-bold rounded-lg border transition ${layoutStyle === t.id ? "bg-slate-950 border-slate-950 text-white dark:bg-indigo-650" : "bg-white border-slate-200 text-slate-600 dark:bg-slate-950 dark:border-slate-800"}`}
                  >
                    {t.name}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Typography Font</label>
              <div className="flex gap-1.5">
                {[
                  { id: "font-serif", name: "Classic Serif" },
                  { id: "font-sans", name: "Modern Sans" },
                  { id: "font-mono", name: "Technical Mono" }
                ].map((f) => (
                  <button
                    key={f.id}
                    onClick={() => setFontStyle(f.id as any)}
                    className={`flex-1 py-1.5 text-[10px] font-bold rounded-lg border transition ${fontStyle === f.id ? "bg-slate-950 border-slate-950 text-white dark:bg-indigo-650" : "bg-white border-slate-200 text-slate-600 dark:bg-slate-950 dark:border-slate-800"}`}
                  >
                    {f.name.split(" ")[0]}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div>
            <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Accent Theme Hue</label>
            <div className="flex items-center gap-2">
              <div className="flex gap-1.5">
                {accentSchemes.map((c) => (
                  <button
                    key={c.hex}
                    onClick={() => setAccentColor(c.hex)}
                    className="w-5.5 h-5.5 rounded-full border border-white/20 transition-transform hover:scale-110 flex items-center justify-center"
                    style={{ backgroundColor: c.hex }}
                    title={c.name}
                  >
                    {accentColor === c.hex && <Check className="h-3 w-3 text-white" />}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-3 pt-1">
            <h4 className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">Recipient & Credential Fields</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-[9px] font-black uppercase text-slate-450 block mb-1">Recipient Full Name</label>
                <input type="text" value={recipientName} onChange={(e) => setRecipientName(e.target.value)} className="w-full text-xs p-1.5 border border-slate-200 dark:border-slate-850 dark:bg-slate-950 rounded font-sans" />
              </div>
              <div>
                <label className="text-[9px] font-black uppercase text-slate-450 block mb-1">Certificate Caption Title</label>
                <input type="text" value={certTitle} onChange={(e) => setCertTitle(e.target.value)} className="w-full text-xs p-1.5 border border-slate-200 dark:border-slate-850 dark:bg-slate-950 rounded font-sans" />
              </div>
            </div>

            <div>
              <label className="text-[9px] font-black uppercase text-slate-450 block mb-1 font-sans">Certificate Citation / Body text</label>
              <textarea rows={3} value={customCitation} onChange={(e) => setCustomCitation(e.target.value)} className="w-full text-xs p-2 border border-slate-200 dark:border-slate-850 dark:bg-slate-950 rounded font-sans leading-relaxed text-slate-700 dark:text-slate-350" />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-[9px] font-black uppercase text-slate-450 block mb-1">Awarding Authority Corporation</label>
                <input type="text" value={awardingBody} onChange={(e) => setAwardingBody(e.target.value)} className="w-full text-xs p-1.5 border border-slate-200 dark:border-slate-850 dark:bg-slate-950 rounded font-sans" />
              </div>
              <div>
                <label className="text-[9px] font-black uppercase text-slate-450 block mb-1">Certificate UUID ID</label>
                <input type="text" value={certificateId} onChange={(e) => setCertificateId(e.target.value)} className="w-full text-xs p-1.5 border border-slate-200 dark:border-slate-850 dark:bg-slate-950 rounded font-sans" />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="col-span-2 grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[9px] font-black uppercase text-slate-450 block mb-1">Signee Name</label>
                  <input type="text" value={signName} onChange={(e) => setSignName(e.target.value)} className="w-full text-xs p-1.5 border border-slate-200 dark:border-slate-850 dark:bg-slate-950 rounded font-sans" />
                </div>
                <div>
                  <label className="text-[9px] font-black uppercase text-slate-450 block mb-1">Signee Title</label>
                  <input type="text" value={signTitle} onChange={(e) => setSignTitle(e.target.value)} className="w-full text-xs p-1.5 border border-slate-200 dark:border-slate-850 dark:bg-slate-950 rounded font-sans" />
                </div>
              </div>
              <div>
                <label className="text-[9px] font-black uppercase text-slate-450 block mb-1">Date Stamp</label>
                <input type="date" value={issueDate} onChange={(e) => setIssueDate(e.target.value)} className="w-full text-xs p-1.5 border border-slate-200 dark:border-slate-850 dark:bg-slate-950 rounded font-mono" />
              </div>
            </div>
          </div>
        </div>

        {/* Right Seal & Additional Configurations */}
        <div className="lg:col-span-6 space-y-5 flex flex-col justify-between">
          <div className="bg-slate-50 dark:bg-slate-900 border border-slate-150 p-5 rounded-2xl space-y-4">
            <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1"><Award className="h-4 w-4 text-amber-500" /> Interactive Seal Stamping</h4>
            
            <p className="text-xs text-slate-450 leading-relaxed font-semibold">
              Stamp high-contrast company logos, academic verification crests, or transparent PNG approval seals onto the center base of your credentials layout to secure optimal official vibes.
            </p>

            <div className="flex gap-2.5 items-center bg-white dark:bg-slate-950 p-3 border border-slate-150 rounded-xl">
              <div className="relative">
                <input type="file" ref={fileInputRef} accept="image/*" onChange={handleSealUpload} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
                <button className="px-3 py-1.5 bg-slate-950 hover:bg-slate-800 text-white rounded font-bold text-xs flex items-center gap-1">
                  <Upload className="h-3.5 w-3.5" /> Upload Brand Seal
                </button>
              </div>
              {sealImage && (
                <button onClick={removeSeal} className="px-2.5 py-1.5 text-xs font-bold text-red-650 bg-red-50 hover:bg-red-100 rounded">
                  Delete Seal
                </button>
              )}
            </div>

            <div className="p-3 bg-amber-50/40 border border-amber-200/50 rounded-xl text-[11px] text-amber-850 font-medium leading-relaxed">
              <strong>Local Notice:</strong> Certificate generations process local calculations safely under verified sandboxed browser platforms. Feel free to print immediately.
            </div>
          </div>

          <div className="p-6 bg-slate-50 dark:bg-slate-900 border border-slate-150 rounded-2xl text-center space-y-3">
            <h4 className="text-xs font-black uppercase text-slate-450 tracking-wider">Quality Assurance Stamping</h4>
            <div className="flex justify-center gap-6 text-slate-350 select-none">
              <div className="flex flex-col items-center"><ShieldCheck className="h-8 w-8 text-emerald-500/60" /><span className="text-[8px] font-bold text-slate-400 mt-1 uppercase">LOCAL SANDBOXED</span></div>
              <div className="flex flex-col items-center"><Award className="h-8 w-8 text-indigo-505/60" /><span className="text-[8px] font-bold text-slate-400 mt-1 uppercase">VERIFIED SECURE</span></div>
              <div className="flex flex-col items-center"><Heart className="h-8 w-8 text-red-500/60" /><span className="text-[8px] font-bold text-slate-400 mt-1 uppercase">CRAFTED ACCURACY</span></div>
            </div>
          </div>
        </div>

      </div>

      {/* 2. CHASSIS DOCK & COMPACT COMPILING PREVIEW AREA */}
      <div className="space-y-4">
        <div className="flex justify-between items-center border-t border-slate-150 dark:border-slate-850 pt-6">
          <div className="space-y-1">
            <h4 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-1">
              <Award className="h-4 w-4 text-amber-600" /> Interactive Certificate Plate Preview
            </h4>
            <p className="text-[10px] text-slate-400 dark:text-slate-450 font-bold leading-none">Review borders and content alignments carefully, then hit Print-to-PDF.</p>
          </div>
          <button
            onClick={handlePrint}
            className="px-4.5 py-2.5 bg-amber-700 hover:bg-amber-850 text-white font-extrabold text-xs tracking-wide rounded-xl shadow-md cursor-pointer flex items-center gap-1.5 transition"
          >
            <Printer className="h-4 w-4" /> Export/Print-to-PDF Stamped Certificate
          </button>
        </div>

        {/* Certificate Display sheet */}
        <div 
          id="certificate-print-area"
          className={`p-6 sm:p-12 md:p-14 bg-white text-slate-800 border border-slate-200 rounded-3xl aspect-[1.414/1] relative overflow-hidden flex flex-col justify-between select-text selection:bg-indigo-300 ${fontStyle}`}
          style={{ width: "100%", maxWidth: "850px", margin: "0 auto" }}
        >
          {/* Borders mapping according to selected style */}

          {/* Border 1: Royal gold ornate corners */}
          {layoutStyle === "royal" && (
            <>
              {/* Outer classic border line */}
              <div className="absolute inset-4 border-2 border-amber-750 pointer-events-none" style={{ borderColor: accentColor }} />
              {/* Inner thin double gold border frame */}
              <div className="absolute inset-6 border border-amber-650/45 border-double border-4 pointer-events-none" style={{ borderColor: `${accentColor}80` }} />
              {/* Ornate vector-like corners */}
              <div className="absolute top-7 left-7 text-2xl h-6 w-6 border-t-2 border-l-2 pointer-events-none rounded-tl-lg" style={{ borderColor: accentColor }} />
              <div className="absolute top-7 right-7 text-2xl h-6 w-6 border-t-2 border-r-2 pointer-events-none rounded-tr-lg" style={{ borderColor: accentColor }} />
              <div className="absolute bottom-7 left-7 text-2xl h-6 w-6 border-b-2 border-l-2 pointer-events-none rounded-bl-lg" style={{ borderColor: accentColor }} />
              <div className="absolute bottom-7 right-7 text-2xl h-6 w-6 border-b-2 border-r-2 pointer-events-none rounded-br-lg" style={{ borderColor: accentColor }} />
            </>
          )}

          {/* Border 2: Corporate minimalist color blocks */}
          {layoutStyle === "corporate" && (
            <>
              <div className="absolute inset-0 w-4 h-full pointer-events-none" style={{ backgroundColor: accentColor }} />
              <div className="absolute top-0 right-0 w-32 h-32 bg-slate-100 rounded-bl-full pointer-events-none opacity-50" />
              <div className="absolute bottom-4 right-4 text-[10px] uppercase font-black tracking-widest text-slate-300 pointer-events-none select-none">
                VERIFIED SECURITY COMPLIANCE RECORD
              </div>
            </>
          )}

          {/* Border 3: Academic conservative frames */}
          {layoutStyle === "academic" && (
            <>
              <div className="absolute inset-3 border-2 border-slate-705 pointer-events-none" style={{ borderColor: accentColor }} />
              <div className="absolute inset-8 border border-slate-205 pointer-events-none opacity-40" />
            </>
          )}

          {/* Header block with badges and authority name */}
          <div className="text-center space-y-3.5 z-10 pt-4">
            <div className="flex justify-center">
              <div className="p-2.5 rounded-full bg-slate-50/80 border border-double border-slate-150" style={{ color: accentColor }}>
                <Award className="h-8 w-8 animate-pulse" />
              </div>
            </div>
            <div className="space-y-1">
              <h5 className="text-[10px] font-black uppercase tracking-[0.25em] text-slate-400">{awardingBody}</h5>
              <div className="h-0.5 w-16 bg-slate-200 mx-auto" />
            </div>
          </div>

          {/* Central Certificate Body Content */}
          <div className="text-center space-y-6 z-10 py-6">
            <div className="space-y-1 flex flex-col items-center">
              <h1 className="text-2xl sm:text-4xl font-extrabold uppercase tracking-widest text-slate-900" style={{ color: accentColor }}>
                {certTitle}
              </h1>
              <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest italic pt-1">With High Scholastic Distinction & Merit</p>
            </div>

            <div className="space-y-2">
              <p className="text-slate-450 text-[11px] font-sans font-bold uppercase tracking-wider">THIS CREDENTIAL DOCUMENT IS PROUDLY GRANTED TO</p>
              <h2 className="text-xl sm:text-3xl font-black text-slate-950 font-serif border-b-2 border-slate-150 pb-2.5 max-w-lg mx-auto leading-none">
                {recipientName}
              </h2>
            </div>

            <p className="text-slate-600 text-xs sm:text-sm max-w-2xl mx-auto leading-relaxed text-justify px-4">
              {customCitation}
            </p>
          </div>

          {/* Footer block with dates, seals, and signatures */}
          <div className="grid grid-cols-3 gap-4 items-end z-10 text-center px-4 pb-2.5">
            
            {/* Date stamps */}
            <div className="space-y-1">
              <p className="text-[11px] font-black text-slate-800 border-b pb-1 font-mono">{issueDate}</p>
              <p className="text-[8px] font-extrabold uppercase text-slate-400 tracking-wider">DATE OF CONFER</p>
            </div>

            {/* Seal or Crest */}
            <div className="flex justify-center">
              {sealImage ? (
                <img src={sealImage} alt="Authorization official seal" className="h-[72px] w-[72px] object-contain rounded-full shadow-inner border bg-white" />
              ) : (
                <div className="h-[72px] w-[72px] rounded-full border border-double border-slate-200 bg-slate-50/50 flex flex-col items-center justify-center text-slate-300">
                  <span className="text-[7px] font-black tracking-widest select-none uppercase">OFFICIAL SEAL</span>
                </div>
              )}
            </div>

            {/* Signatory line */}
            <div className="space-y-1">
              <p className="text-[11px] font-black text-slate-800 border-b pb-1 font-serif italic text-slate-900">{signName}</p>
              <p className="text-[8px] font-extrabold uppercase text-slate-400 tracking-wider">{signTitle}</p>
            </div>

          </div>

          {/* UUID ID code footprint */}
          <div className="text-[9px] font-mono text-slate-400 select-all z-10 text-center uppercase flex items-center justify-center gap-1.5 pt-6 pb-2">
            <span>Security ID:</span>
            <span className="font-bold text-slate-600">{certificateId}</span>
            <span>|</span>
            <span className="text-[8px] font-black text-emerald-600 font-sans tracking-wide">🛡️ SANDBOXED BROWSER VERIFICATION</span>
          </div>

        </div>
      </div>
    </div>
  );
}
