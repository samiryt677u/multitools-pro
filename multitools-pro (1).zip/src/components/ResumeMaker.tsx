import React, { useState, useRef } from "react";
import { Plus, Trash2, Upload, Printer, Check, Palette, User, GraduationCap, Briefcase, Sparkles, Star } from "lucide-react";

interface WorkExperience {
  id: string;
  company: string;
  role: string;
  duration: string;
  bullets: string;
}

interface Education {
  id: string;
  school: string;
  degree: string;
  duration: string;
  grade: string;
}

export default function ResumeMaker() {
  const [photo, setPhoto] = useState<string | null>(null);
  const [fullName, setFullName] = useState("Alex Mercer");
  const [targetTitle, setTargetTitle] = useState("Lead Platform Engineer & Architect");
  const [emailStr, setEmailStr] = useState("alex.mercer@gmail.com");
  const [phoneStr, setPhoneStr] = useState("+1 (555) 019-2831");
  const [locationStr, setLocationStr] = useState("San Francisco, CA");
  const [siteStr, setSiteStr] = useState("http://mercerengineering.io");
  const [githubStr, setGithubStr] = useState("github.com/alex-mercer");
  const [linkedinStr, setLinkedinStr] = useState("linkedin.com/in/alexmercer");
  
  const [executiveSummary, setExecutiveSummary] = useState(
    "Senior Cloud & Systems Infrastructure Architect with 8+ years of experience engineering secure browser enclaves, real-time data visualizers, and node sandboxes. Scaled developer application systems to over 5M+ clients with flawless Lighthouse and Core Web Vitals performance parameters."
  );

  const [experience, setExperience] = useState<WorkExperience[]>([
    {
      id: "exp-1",
      company: "MyToolsHub Tech Labs Inc.",
      role: "Lead Systems Architect",
      duration: "2024 - Present",
      bullets: "Spearheaded local browser-side sandbox development using WebAssembly and canvas vectors, shrinking file latency metrics by 65%.\nFormulated AdSense and GDPR compliant layout schemas, sustaining 100 on Google PageSpeed tests.\nAutomated sitemap crawling algorithms, scaling platform reach globally without core hardware cost multipliers."
    },
    {
      id: "exp-2",
      company: "NextGen Software Cloud",
      role: "Senior Full Stack Dev",
      duration: "2021 - 2024",
      bullets: "Orchestrated React & Vite compilation pipelines, serving 1M+ active monthly visitors.\nEngineered local drawing signature canvases and metadata HTML parsing tools."
    }
  ]);

  const [education, setEducation] = useState<Education[]>([
    {
      id: "edu-1",
      school: "Stanford University",
      degree: "B.S. in Computer Science & Systems Engineering",
      duration: "2017 - 2021",
      grade: "GPA: 3.92 / 4.0"
    }
  ]);

  const [skillsCsv, setSkillsCsv] = useState("React, TypeScript, WebAssembly, Go, Rust, Tailwind CSS, Docker, Kubernetes, Google Cloud, SEO Optimization");
  const [certificationsCsv, setCertificationsCsv] = useState("Google Professional Cloud Architect, Certified Kubernetes Administrator (CKA)");

  const [templateStyle, setTemplateStyle] = useState<"twocol" | "imperial" | "tech">("twocol");
  const [fontFamily, setFontFamily] = useState<"sans" | "serif" | "mono">("sans");
  const [accentColor, setAccentColor] = useState("#0d9488"); // teal
  const [fontSize, setFontSize] = useState<"text-xs" | "text-sm">("text-sm");

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const url = URL.createObjectURL(e.target.files[0]);
      setPhoto(url);
    }
  };

  const removePhoto = () => {
    setPhoto(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  // Dynamic Array Actions
  const addExp = () => {
    setExperience(prev => [
      ...prev,
      {
        id: Math.random().toString(36).substring(2, 9),
        company: "Global Corporate / Startup Inc.",
        role: "Software Engineer / Product Executive",
        duration: "2025 - 2026",
        bullets: "Describe core milestones and engineering triumphs...\nMention quantitative gains and performance metrics..."
      }
    ]);
  };

  const deleteExp = (id: string) => {
    setExperience(prev => prev.filter(e => e.id !== id));
  };

  const updateExp = (id: string, field: keyof WorkExperience, val: string) => {
    setExperience(prev => prev.map(e => e.id === id ? { ...e, [field]: val } : e));
  };

  const addEdu = () => {
    setEducation(prev => [
      ...prev,
      {
        id: Math.random().toString(36).substring(2, 9),
        school: "Major State University",
        degree: "M.S. / B.S. in Software Systems",
        duration: "2021 - 2023",
        grade: "First Class Distinction"
      }
    ]);
  };

  const deleteEdu = (id: string) => {
    setEducation(prev => prev.filter(e => e.id !== id));
  };

  const updateEdu = (id: string, field: keyof Education, val: string) => {
    setEducation(prev => prev.map(e => e.id === id ? { ...e, [field]: val } : e));
  };

  const handlePrint = () => {
    window.print();
  };

  // Color schemes for custom selectors
  const accentSchemes = [
    { name: "Teal", hex: "#0d9488" },
    { name: "Slate", hex: "#334155" },
    { name: "Royal Blue", hex: "#1d4ed8" },
    { name: "Violet", hex: "#6d28d9" },
    { name: "Forest", hex: "#15803d" }
  ];

  const fontFamilies = [
    { id: "sans", css: "font-sans", name: "Inter Sans" },
    { id: "serif", css: "font-serif", name: "Imperial Serif" },
    { id: "mono", css: "font-mono", name: "Tech Mono" }
  ];

  return (
    <div className="space-y-8 text-sm">
      {/* 1. Interactive Form Editor Board */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Configurations input box */}
        <div className="lg:col-span-6 space-y-6 bg-slate-50 dark:bg-slate-900 border border-slate-150/80 dark:border-slate-800 p-5 rounded-2xl">
          <h3 className="text-xs font-black uppercase tracking-widest text-slate-450 dark:text-slate-500 flex items-center gap-1.5 border-b border-slate-200 dark:border-slate-800 pb-2">
            <Palette className="h-4 w-4 text-teal-600" /> Resume Format & Controls
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Select Template Layout</label>
              <div className="flex gap-1.5">
                {[
                  { id: "twocol", name: "Two Column" },
                  { id: "imperial", name: "Imperial" },
                  { id: "tech", name: "Technical" }
                ].map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setTemplateStyle(t.id as any)}
                    className={`flex-1 py-1.5 text-xs font-bold rounded-lg border transition ${templateStyle === t.id ? "bg-slate-950 border-slate-950 text-white dark:bg-indigo-650" : "bg-white border-slate-200 text-slate-600 dark:bg-slate-950 dark:border-slate-800"}`}
                  >
                    {t.name}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Size & Density</label>
              <div className="flex gap-1.5">
                {[
                  { id: "text-xs", name: "Compact" },
                  { id: "text-sm", name: "Standard" }
                ].map((s) => (
                  <button
                    key={s.id}
                    onClick={() => setFontSize(s.id as any)}
                    className={`flex-1 py-1.5 text-xs font-bold rounded-lg border transition ${fontSize === s.id ? "bg-slate-950 border-slate-950 text-white dark:bg-indigo-650" : "bg-white border-slate-200 text-slate-600 dark:bg-slate-950 dark:border-slate-800"}`}
                  >
                    {s.name}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Typography Font</label>
              <div className="flex gap-1">
                {fontFamilies.map((f) => (
                  <button
                    key={f.id}
                    onClick={() => setFontFamily(f.id as any)}
                    className={`flex-1 py-1.5 text-[10px] font-bold rounded-lg border transition ${fontFamily === f.id ? "bg-slate-950 border-slate-950 text-white dark:bg-indigo-650" : "bg-white border-slate-200 text-slate-600 dark:bg-slate-950 dark:border-slate-800"}`}
                  >
                    {f.name.split(" ")[0]}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Accent Accent Color</label>
              <div className="flex gap-1.5 items-center">
                {accentSchemes.map((c) => (
                  <button
                    key={c.hex}
                    onClick={() => setAccentColor(c.hex)}
                    className="w-5 h-5 rounded-full border border-white/20 transition-transform active:scale-95 hover:scale-110 flex items-center justify-center"
                    style={{ backgroundColor: c.hex }}
                    title={c.name}
                  >
                    {accentColor === c.hex && <Check className="h-3 w-3 text-white" />}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Identity Parameters Block */}
          <div className="space-y-3.5 pt-2">
            <h4 className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">Primary Identity logs</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-[9px] font-black uppercase text-slate-450 block mb-1">Full Name</label>
                <input type="text" value={fullName} onChange={(e) => setFullName(e.target.value)} className="w-full text-xs p-1.5 border border-slate-200 dark:border-slate-850 dark:bg-slate-950 rounded" />
              </div>
              <div>
                <label className="text-[9px] font-black uppercase text-slate-450 block mb-1">Target Role Title</label>
                <input type="text" value={targetTitle} onChange={(e) => setTargetTitle(e.target.value)} className="w-full text-xs p-1.5 border border-slate-200 dark:border-slate-850 dark:bg-slate-950 rounded" />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="text-[9px] font-black uppercase text-slate-450 block mb-1">Email</label>
                <input type="text" value={emailStr} onChange={(e) => setEmailStr(e.target.value)} className="w-full text-xs p-1.5 border border-slate-200 dark:border-slate-850 dark:bg-slate-950 rounded" />
              </div>
              <div>
                <label className="text-[9px] font-black uppercase text-slate-450 block mb-1">Phone</label>
                <input type="text" value={phoneStr} onChange={(e) => setPhoneStr(e.target.value)} className="w-full text-xs p-1.5 border border-slate-200 dark:border-slate-850 dark:bg-slate-950 rounded" />
              </div>
              <div>
                <label className="text-[9px] font-black uppercase text-slate-450 block mb-1">Location</label>
                <input type="text" value={locationStr} onChange={(e) => setLocationStr(e.target.value)} className="w-full text-xs p-1.5 border border-slate-200 dark:border-slate-850 dark:bg-slate-950 rounded" />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="text-[9px] font-black uppercase text-slate-450 block mb-1">Personal Website</label>
                <input type="text" value={siteStr} onChange={(e) => setSiteStr(e.target.value)} className="w-full text-[11px] p-1.5 border border-slate-200 dark:border-slate-850 dark:bg-slate-950 rounded" />
              </div>
              <div>
                <label className="text-[9px] font-black uppercase text-slate-450 block mb-1">GitHub Path</label>
                <input type="text" value={githubStr} onChange={(e) => setGithubStr(e.target.value)} className="w-full text-[11px] p-1.5 border border-slate-200 dark:border-slate-850 dark:bg-slate-950 rounded" />
              </div>
              <div>
                <label className="text-[9px] font-black uppercase text-slate-450 block mb-1">LinkedIn Path</label>
                <input type="text" value={linkedinStr} onChange={(e) => setLinkedinStr(e.target.value)} className="w-full text-[11px] p-1.5 border border-slate-200 dark:border-slate-850 dark:bg-slate-950 rounded" />
              </div>
            </div>

            <div>
              <label className="text-[9px] font-black uppercase text-slate-450 block mb-1">Professional Executive Summary</label>
              <textarea rows={3} value={executiveSummary} onChange={(e) => setExecutiveSummary(e.target.value)} className="w-full text-xs p-2 border border-slate-200 dark:border-slate-850 dark:bg-slate-950 rounded font-sans leading-relaxed text-slate-700 dark:text-slate-350" />
            </div>

            <div>
              <label className="text-[9px] font-black uppercase text-slate-450 block mb-1">Profile Photo Upload</label>
              <div className="flex gap-2 items-center">
                <div className="relative">
                  <input type="file" ref={fileInputRef} accept="image/*" onChange={handlePhotoUpload} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
                  <button className="px-3 py-1.5 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded font-bold text-xs flex items-center gap-1 text-slate-700 dark:text-slate-300">
                    <Upload className="h-3.5 w-3.5" /> Upload Photo
                  </button>
                </div>
                {photo && (
                  <button onClick={removePhoto} className="px-2.5 py-1.5 text-xs font-bold text-red-650 bg-red-50 hover:bg-red-100 rounded">
                    Remove Photo
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Right Section Experience + Education Details Arrays */}
        <div className="lg:col-span-6 space-y-6">
          
          {/* Experience list */}
          <div className="space-y-3">
            <div className="flex justify-between items-center bg-slate-100 dark:bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-150 dark:border-slate-800">
              <span className="font-bold text-slate-800 dark:text-slate-200 text-xs flex items-center gap-1"><Briefcase className="h-3.5 w-3.5 text-indigo-500" /> Work Chronicles</span>
              <button onClick={addExp} className="px-2 py-0.5 bg-slate-900 text-white rounded text-[10px] font-bold">+ Experience</button>
            </div>

            <div className="space-y-3 overflow-y-auto max-h-[220px] pr-1">
              {experience.map((e) => (
                <div key={e.id} className="border border-slate-200 dark:border-slate-850 p-3 rounded-lg space-y-2.5 bg-white dark:bg-slate-950 relatve">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                    <div className="col-span-2">
                      <input type="text" placeholder="Company Name" value={e.company} onChange={(val) => updateExp(e.id, "company", val.target.value)} className="w-full font-bold p-1 border rounded border-slate-150 dark:border-slate-850 dark:bg-slate-900" />
                    </div>
                    <div>
                      <input type="text" placeholder="Role Title" value={e.role} onChange={(val) => updateExp(e.id, "role", val.target.value)} className="w-full text-slate-650 p-1 border rounded border-slate-150 dark:border-slate-850 dark:bg-slate-900" />
                    </div>
                    <div>
                      <input type="text" placeholder="Duration" value={e.duration} onChange={(val) => updateExp(e.id, "duration", val.target.value)} className="w-full text-slate-450 p-1 border rounded border-slate-150 dark:border-slate-850 dark:bg-slate-900 font-sans" />
                    </div>
                  </div>
                  <div>
                    <textarea rows={2} placeholder="Scribble down key highlights (use new lines).." value={e.bullets} onChange={(val) => updateExp(e.id, "bullets", val.target.value)} className="w-full text-[11px] p-2 border border-slate-150 dark:border-slate-850 dark:bg-slate-900 rounded font-sans leading-relaxed text-slate-600" />
                  </div>
                  <div className="flex justify-end pt-1">
                    <button onClick={() => deleteExp(e.id)} className="p-1 text-red-500 hover:bg-red-50 rounded" title="Delete Experience row">
                      <Trash2 className="h-4.5 w-4.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Education blocks */}
          <div className="space-y-3">
            <div className="flex justify-between items-center bg-slate-100 dark:bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-150 dark:border-slate-800">
              <span className="font-bold text-slate-800 dark:text-slate-200 text-xs flex items-center gap-1"><GraduationCap className="h-3.5 w-3.5 text-indigo-500" /> Academic credentials</span>
              <button onClick={addEdu} className="px-2 py-0.5 bg-slate-900 text-white rounded text-[10px] font-bold">+ Education</button>
            </div>

            <div className="space-y-3 overflow-y-auto max-h-[140px] pr-1">
              {education.map((edu) => (
                <div key={edu.id} className="border border-slate-200 dark:border-slate-850 p-2.5 rounded-lg bg-white dark:bg-slate-950 flex flex-col gap-2 relative">
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-2 text-xs">
                    <div className="col-span-2">
                      <input type="text" placeholder="College Name" value={edu.school} onChange={(val) => updateEdu(edu.id, "school", val.target.value)} className="w-full font-bold p-1 border rounded border-slate-150 dark:border-slate-850 dark:bg-slate-900" />
                    </div>
                    <div className="col-span-2">
                      <input type="text" placeholder="Degree / Specialization" value={edu.degree} onChange={(val) => updateEdu(edu.id, "degree", val.target.value)} className="w-full text-slate-650 p-1 border rounded border-slate-150 dark:border-slate-850 dark:bg-slate-900" />
                    </div>
                    <div>
                      <input type="text" placeholder="GPA / Grade" value={edu.grade} onChange={(val) => updateEdu(edu.id, "grade", val.target.value)} className="w-full p-1 border rounded border-slate-150- dark:border-slate-850 dark:bg-slate-900" />
                    </div>
                  </div>
                  <div className="flex justify-between items-center bg-slate-50/50 p-1 rounded">
                    <input type="text" placeholder="Date duration" value={edu.duration} onChange={(val) => updateEdu(edu.id, "duration", val.target.value)} className="text-[11px] p-1 border border-slate-150 rounded dark:bg-slate-900 text-slate-450 w-36 font-sans" />
                    <button onClick={() => deleteEdu(edu.id)} className="p-1 text-red-500 hover:bg-red-50 rounded" title="Delete Education row">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Skills CSV Inputs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Key Technical Core Skills</label>
              <textarea rows={2} value={skillsCsv} onChange={(e) => setSkillsCsv(e.target.value)} className="w-full text-xs p-1.5 border border-slate-200 dark:border-slate-850 dark:bg-slate-950 rounded font-sans" placeholder="React, Node.js, Cloud enclaves, etc." />
            </div>
            <div>
              <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Certificates / Achievements</label>
              <textarea rows={2} value={certificationsCsv} onChange={(e) => setCertificationsCsv(e.target.value)} className="w-full text-xs p-1.5 border border-slate-200 dark:border-slate-850 dark:bg-slate-950 rounded font-sans" placeholder="AWS Solution Architect, PMP, Scrum Master..." />
            </div>
          </div>

        </div>

      </div>

      {/* 2. LIVE DOCUMENT PREVIEW EXPORT CHASSIS */}
      <div className="space-y-4">
        <div className="flex justify-between items-center border-t border-slate-150 dark:border-slate-850 pt-6">
          <div className="space-y-1">
            <h4 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-1">
              <User className="h-4 w-4 text-teal-600" /> Live Resume Sheet Blueprint
            </h4>
            <p className="text-[10px] text-slate-400 dark:text-slate-450 font-bold leading-none">Press the Print button on the right for clean export results.</p>
          </div>
          <button
            onClick={handlePrint}
            className="px-4.5 py-2.5 bg-teal-600 hover:bg-teal-700 text-white font-extrabold text-xs tracking-wide rounded-xl shadow-md cursor-pointer flex items-center gap-1.5 transition"
          >
            <Printer className="h-4 w-4" /> Print-to-PDF / PDF Export
          </button>
        </div>

        {/* Visual PDF container */}
        <div 
          id="resume-print-area"
          className={`p-8 md:p-12 bg-white text-slate-800 border border-slate-200 rounded-3xl min-h-[850px] shadow-sm relative leading-relaxed overflow-hidden ${
            fontFamily === "sans" ? "font-sans" : fontFamily === "serif" ? "font-serif" : "font-mono"
          }`}
          style={{ width: "100%", maxWidth: "800px", margin: "0 auto" }}
        >
          {/* layout 1: Two Column Layout */}
          {templateStyle === "twocol" && (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-8 text-slate-755 text-justify">
              
              {/* Left Column Sidebar */}
              <div className="md:col-span-4 space-y-6 md:border-r border-slate-100 pr-5">
                <div className="space-y-4 text-center md:text-left">
                  {photo ? (
                    <img src={photo} alt={fullName} className="h-24 w-24 rounded-full mx-auto md:mx-0 object-cover border-2 shadow-sm" style={{ borderColor: accentColor }} />
                  ) : (
                    <div className="h-20 w-20 rounded-full mx-auto md:mx-0 text-white flex items-center justify-center font-black text-3xl" style={{ backgroundColor: accentColor }}>
                      {fullName.charAt(0)}
                    </div>
                  )}

                  <div className="space-y-1">
                    <h2 className="text-lg font-black tracking-tight text-slate-900 leading-none">{fullName}</h2>
                    <p className="text-[10px] font-extrabold uppercase tracking-wide leading-tight" style={{ color: accentColor }}>{targetTitle}</p>
                  </div>
                </div>

                {/* Contact items */}
                <div className="space-y-2.5 text-[11px] font-semibold text-slate-500">
                  <h4 className="text-[9px] font-black tracking-wider uppercase border-b pb-1 text-slate-400">CONNECT SECURE</h4>
                  <div className="truncate">{emailStr}</div>
                  <div>{phoneStr}</div>
                  <div>{locationStr}</div>
                  {siteStr && <div className="truncate">{siteStr}</div>}
                  {githubStr && <div className="truncate text-slate-500 font-mono text-[10px]">{githubStr}</div>}
                  {linkedinStr && <div className="truncate text-slate-500 font-mono text-[10px]">{linkedinStr}</div>}
                </div>

                {/* Skills tags list */}
                <div className="space-y-2.5">
                  <h4 className="text-[9px] font-black tracking-wider uppercase border-b pb-1 text-slate-400">CORE SKILLSETS</h4>
                  <div className="flex flex-wrap gap-1">
                    {skillsCsv.split(",").map((sk) => (
                      <span key={sk} className="text-[9px] px-2 py-0.5 bg-slate-50 border border-slate-150 rounded text-slate-650 font-bold">
                        {sk.trim()}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Certifications list */}
                {certificationsCsv && (
                  <div className="space-y-2.5">
                    <h4 className="text-[9px] font-black tracking-wider uppercase border-b pb-1 text-slate-400">CREDENTIALS</h4>
                    <ul className="space-y-1.5 text-[11px] text-slate-500 font-semibold leading-relaxed list-disc pl-4">
                      {certificationsCsv.split(",").map((cr, idx) => (
                        <li key={idx} className="marker:text-slate-300">{cr.trim()}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {/* Right Column Core Details */}
              <div className="md:col-span-8 space-y-6">
                
                {/* Profile summary */}
                <div className="space-y-2">
                  <h3 className="text-xs font-black uppercase tracking-widest text-slate-400 pb-1 border-b" style={{ borderColor: `${accentColor}1c` }}>Professional Profile</h3>
                  <p className="text-[11px] md:text-xs text-slate-600 leading-relaxed font-semibold">{executiveSummary}</p>
                </div>

                {/* Experiences */}
                <div className="space-y-4">
                  <h3 className="text-xs font-black uppercase tracking-widest text-slate-400 pb-1 border-b">Professional Chronicles</h3>
                  
                  <div className="space-y-4">
                    {experience.map((e) => (
                      <div key={e.id} className="space-y-1.5">
                        <div className="flex justify-between text-xs font-black text-slate-900 border-l-2 pl-2.5" style={{ borderColor: accentColor }}>
                          <div>
                            <span>{e.company}</span>
                            <span className="text-slate-400 text-[10px] font-normal mx-2">|</span>
                            <span className="text-[10px] font-extrabold uppercase tracking-wide" style={{ color: accentColor }}>{e.role}</span>
                          </div>
                          <span className="text-[9px] text-slate-400 font-normal font-sans">{e.duration}</span>
                        </div>
                        <ul className="list-disc pl-7 text-[11px] text-slate-550 leading-relaxed space-y-1.5 font-medium">
                          {e.bullets.split("\n").map((b, i) => (
                            <li key={i} className="marker:text-slate-200">{b.trim()}</li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Educations */}
                <div className="space-y-3">
                  <h3 className="text-xs font-black uppercase tracking-widest text-slate-400 pb-1 border-b">Academic parameters</h3>
                  
                  <div className="space-y-2.5">
                    {education.map((edu) => (
                      <div key={edu.id} className="flex justify-between items-start text-xs font-semibold text-slate-700">
                        <div className="space-y-0.5">
                          <h4 className="font-extrabold text-slate-900 text-[11px]">{edu.school}</h4>
                          <p className="text-[10px] text-slate-500">{edu.degree}</p>
                        </div>
                        <div className="text-right text-[10px] font-normal text-slate-400 font-sans">
                          <div>{edu.grade}</div>
                          <div className="mt-1">{edu.duration}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

              </div>

            </div>
          )}

          {/* layout 2: Centered Imperial Layout */}
          {templateStyle === "imperial" && (
            <div className="space-y-8 text-center text-slate-750">
              
              {/* Header card centered */}
              <div className="space-y-3 text-center border-b pb-6">
                <h1 className="text-3xl font-black uppercase tracking-wider text-slate-900">{fullName}</h1>
                <h4 className="text-[11px] font-black uppercase tracking-widest" style={{ color: accentColor }}>{targetTitle}</h4>
                
                <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-1.5 text-[11px] text-slate-450 font-bold">
                  <span>{emailStr}</span>
                  <span>•</span>
                  <span>{phoneStr}</span>
                  <span>•</span>
                  <span>{locationStr}</span>
                  {siteStr && (
                    <>
                      <span>•</span>
                      <span>{siteStr}</span>
                    </>
                  )}
                </div>
              </div>

              {/* Profile summary */}
              <div className="space-y-2 text-left">
                <h3 className="text-xs font-bold uppercase tracking-widest text-center" style={{ color: accentColor }}>I. Executive Summary Portfolio</h3>
                <p className="text-[11px] md:text-xs text-slate-650 leading-relaxed text-center max-w-2xl mx-auto italic font-semibold">{executiveSummary}</p>
              </div>

              {/* Work histories */}
              <div className="space-y-4 text-left">
                <h3 className="text-xs font-bold uppercase tracking-widest text-center" style={{ color: accentColor }}>II. Professional Chronology</h3>
                <div className="space-y-4 leading-relaxed">
                  {experience.map((e) => (
                    <div key={e.id} className="space-y-1">
                      <div className="flex justify-between items-end border-b border-dashed pb-0.5 text-xs font-bold">
                        <span className="text-slate-900">{e.company} — <span className="italic font-normal" style={{ color: accentColor }}>{e.role}</span></span>
                        <span className="text-[10px] text-slate-400 font-normal font-sans">{e.duration}</span>
                      </div>
                      <ul className="list-disc pl-6 text-[11px] text-slate-600 space-y-1">
                        {e.bullets.split("\n").map((b, i) => (
                          <li key={i}>{b.trim()}</li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </div>

              {/* Skill mapping matrices */}
              <div className="space-y-2.5 text-center">
                <h3 className="text-xs font-bold uppercase tracking-widest" style={{ color: accentColor }}>III. Strategic Skillsets</h3>
                <p className="text-[11px] text-slate-600 leading-relaxed max-w-xl mx-auto font-bold tracking-wide leading-relaxed">
                  {skillsCsv}
                </p>
              </div>

              {/* Education row */}
              <div className="space-y-3 text-left">
                <h3 className="text-xs font-bold uppercase tracking-widest text-center" style={{ color: accentColor }}>IV. Academic Credentials</h3>
                <div className="divide-y divide-slate-100 border rounded-xl overflow-hidden bg-slate-50/20 p-4 space-y-3.5">
                  {education.map((edu) => (
                    <div key={edu.id} className="flex justify-between text-xs font-semibold text-slate-700">
                      <div>
                        <span className="font-extrabold text-slate-900">{edu.school}</span>
                        <span className="mx-2 text-slate-300">|</span>
                        <span>{edu.degree}</span>
                      </div>
                      <div className="text-right font-sans text-[10px] text-slate-400">
                        <span className="font-bold text-slate-700">{edu.grade}</span> ({edu.duration})
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}

          {/* layout 3: Minimalist Tech Layout */}
          {templateStyle === "tech" && (
            <div className="space-y-6 text-xs text-left text-slate-800 font-mono">
              <div className="flex justify-between border-b pb-4 border-slate-900">
                <div className="space-y-1">
                  <h1 className="text-xl font-black text-slate-950 uppercase">{fullName}</h1>
                  <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">{targetTitle}</p>
                </div>
                <div className="text-right text-[10px] space-y-0.5 text-slate-500">
                  <div>EMAIL: {emailStr}</div>
                  <div>PHONE: {phoneStr}</div>
                  <div>ADDRS: {locationStr}</div>
                </div>
              </div>

              <div className="space-y-1">
                <h4 className="font-black text-slate-950 border-b pb-0.5 uppercase tracking-wide">01_EXECUTIVE_SUMMARY</h4>
                <p className="text-slate-600 leading-relaxed pt-1">{executiveSummary}</p>
              </div>

              <div className="space-y-4">
                <h4 className="font-black text-slate-950 border-b pb-0.5 uppercase tracking-wide">02_EXPERIENCE_LOGS</h4>
                <div className="space-y-4">
                  {experience.map((e) => (
                    <div key={e.id} className="space-y-1">
                      <div className="flex justify-between text-[11px] font-extrabold">
                        <span>&gt; {e.company} ({e.role})</span>
                        <span className="text-slate-400">{e.duration}</span>
                      </div>
                      <div className="pl-4 text-slate-550 leading-relaxed space-y-1 font-sans text-[11px]">
                        {e.bullets.split("\n").map((b, i) => (
                          <div key={i} className="flex gap-2.5">
                            <span className="text-slate-400 select-none font-mono font-bold">-</span>
                            <span>{b.trim()}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="font-black text-slate-950 border-b pb-0.5 uppercase tracking-wide">03_ACADEMIC_CREDENTIALS</h4>
                {education.map((edu) => (
                  <div key={edu.id} className="flex justify-between leading-normal pr-2">
                    <span>{edu.school} -- {edu.degree}</span>
                    <span className="text-slate-500">{edu.duration} [{edu.grade}]</span>
                  </div>
                ))}
              </div>

              <div className="space-y-1.5">
                <h4 className="font-black text-slate-950 border-b pb-0.5 uppercase tracking-wide">04_SKILLS_VECTOR</h4>
                <p className="text-slate-600 leading-relaxed font-sans text-[11px] font-semibold">{skillsCsv}</p>
              </div>
            </div>
          )}

          {/* Secure watermark bottom bar */}
          <div className="print:hidden text-[9px] font-extrabold text-slate-350 tracking-wider text-center pt-8 border-t border-slate-50 select-none uppercase">
            🛡️ VERIFIED CLIENT-SIDE SANDBOX GENERATION BY MYTOOLSHUB CO.
          </div>
        </div>
      </div>
    </div>
  );
}
