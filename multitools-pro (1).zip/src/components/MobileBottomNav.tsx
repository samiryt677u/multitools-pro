import React, { useState } from "react";
import { Home, Filter, BookOpen, Mail, HelpCircle, ShieldCheck } from "lucide-react";
import { CATEGORIES } from "../data/tools";

interface MobileBottomNavProps {
  currentRoute: { page: string; slug?: string };
  navigateTo: (page: string, slug?: string) => void;
}

export default function MobileBottomNav({ currentRoute, navigateTo }: MobileBottomNavProps) {
  const [showCategorySheet, setShowCategorySheet] = useState(false);

  return (
    <>
      {/* Category Selection Drawer for Mobile */}
      {showCategorySheet && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-sm flex items-end justify-center md:hidden">
          {/* Overlay click closer */}
          <div className="absolute inset-0" onClick={() => setShowCategorySheet(false)} />
          
          <div className="bg-white dark:bg-slate-950 rounded-t-3xl p-6 w-full max-w-md max-h-[80vh] overflow-y-auto space-y-4 relative z-10 animate-in slide-in-from-bottom border-t border-slate-150 dark:border-slate-800">
            <div className="flex justify-between items-center pb-2 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-sm font-black text-slate-950 dark:text-slate-50 uppercase tracking-widest flex items-center gap-1.5">
                <Filter className="h-4 w-4 text-indigo-500" /> Choose Category
              </h3>
              <button 
                onClick={() => setShowCategorySheet(false)}
                className="text-xs font-bold text-slate-400 hover:text-slate-900 dark:hover:text-white"
              >
                Close
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                onClick={() => {
                  navigateTo("home");
                  setTimeout(() => {
                    const el = document.getElementById("tools-anchor");
                    if (el) el.scrollIntoView({ behavior: "smooth" });
                  }, 100);
                  setShowCategorySheet(false);
                }}
                className="p-3 border border-slate-100 dark:border-slate-855 hover:border-slate-300 rounded-xl text-left bg-slate-50/50 dark:bg-slate-900/50 cursor-pointer flex flex-col gap-2 group"
              >
                <div className="p-1 bg-white dark:bg-slate-950 text-indigo-500 rounded-lg w-fit">
                  <Home className="h-4 w-4" />
                </div>
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200">All Suites</span>
              </button>

              {CATEGORIES.map((cat) => (
                <button
                  key={`btm-cat-${cat.id}`}
                  onClick={() => {
                    navigateTo("home");
                    setTimeout(() => {
                      window.location.hash = `#/category/${cat.id}`;
                    }, 50);
                    setShowCategorySheet(false);
                  }}
                  className="p-3 border border-slate-100 dark:border-slate-855 hover:border-slate-300 rounded-xl text-left bg-slate-50/50 dark:bg-slate-900/50 cursor-pointer flex flex-col gap-2 group"
                >
                  <div className={`p-1 rounded-lg w-fit ${cat.bg} dark:bg-slate-950 dark:text-indigo-400`}>
                    <Filter className="h-4 w-4" />
                  </div>
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200 truncate">{cat.name}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Primary Floating Mobile Bottom Navigation Bar bar */}
      <div className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 border-t border-slate-150/80 dark:border-slate-800 md:hidden flex items-center justify-around h-16 px-2 shadow-[0_-4px_12px_rgba(0,0,0,0.03)] backdrop-blur-md pb-safe">
        
        {/* Home Item */}
        <button
          onClick={() => {
            navigateTo("home");
            setShowCategorySheet(false);
          }}
          className={`flex flex-col items-center justify-center w-14 h-12 rounded-xl transition ${
            currentRoute.page === "home" ? "text-indigo-600 dark:text-indigo-400" : "text-slate-400 hover:text-slate-650"
          }`}
        >
          <Home className="h-5 w-5 shrink-0" />
          <span className="text-[10px] font-bold mt-1">Home</span>
        </button>

        {/* Categories Drawer Trigger Item */}
        <button
          onClick={() => setShowCategorySheet(!showCategorySheet)}
          className={`flex flex-col items-center justify-center w-14 h-12 rounded-xl transition ${
            showCategorySheet ? "text-indigo-600 dark:text-indigo-400" : "text-slate-400 hover:text-slate-650"
          }`}
        >
          <Filter className="h-5 w-5 shrink-0" />
          <span className="text-[10px] font-bold mt-1">Categories</span>
        </button>

        {/* Blogs page link */}
        <button
          onClick={() => {
            navigateTo("blog");
            setShowCategorySheet(false);
          }}
          className={`flex flex-col items-center justify-center w-14 h-12 rounded-xl transition ${
            currentRoute.page === "blog" ? "text-indigo-600 dark:text-indigo-400" : "text-slate-400 hover:text-slate-650"
          }`}
        >
          <BookOpen className="h-5 w-5 shrink-0 animate-pulse" />
          <span className="text-[10px] font-bold mt-1">Blog</span>
        </button>

        {/* Contact page link */}
        <button
          onClick={() => {
            navigateTo("contact");
            setShowCategorySheet(false);
          }}
          className={`flex flex-col items-center justify-center w-14 h-12 rounded-xl transition ${
            currentRoute.page === "contact" ? "text-indigo-600 dark:text-indigo-400" : "text-slate-400 hover:text-slate-650"
          }`}
        >
          <Mail className="h-5 w-5 shrink-0" />
          <span className="text-[10px] font-bold mt-1">Contact</span>
        </button>

      </div>
    </>
  );
}
