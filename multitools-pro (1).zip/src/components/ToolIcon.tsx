import React from "react";
import * as Icons from "lucide-react";

interface ToolIconProps {
  name: string;
  className?: string;
}

export default function ToolIcon({ name, className = "h-5 w-5" }: ToolIconProps) {
  // Gracefully map a string icon name to its Lucide React element
  const LucideIcon = (Icons as any)[name];
  if (LucideIcon) {
    return <LucideIcon className={className} />;
  }
  // Fallback to a default generic clean toolkit icon
  const DefaultIcon = Icons.Compass;
  return <DefaultIcon className={className} />;
}
