export interface ToolFAQ {
  q: string;
  a: string;
}

export interface ToolData {
  title: string;
  slug: string;
  description: string;
  category: string;
  seoTitle: string;
  metaDescription: string;
  faq: ToolFAQ[];
  features: string[];
  featured?: boolean;
  trending?: boolean;
  mostUsed?: boolean;
  recentlyAdded?: boolean;
  icon: string; // lucide icon name
}

export const CATEGORIES = [
  { id: "pdf", name: "PDF Tools", icon: "FileText", color: "text-red-500", bg: "bg-red-50" },
  { id: "image", name: "Image Tools", icon: "Image", color: "text-blue-500", bg: "bg-blue-50" },
  { id: "calculators", name: "Calculators", icon: "Calculator", color: "text-green-500", bg: "bg-green-50" },
  { id: "student", name: "Student Tools", icon: "GraduationCap", color: "text-purple-500", bg: "bg-purple-50" },
  { id: "office", name: "Resume & Office", icon: "Briefcase", color: "text-amber-500", bg: "bg-amber-50" },
  { id: "seo", name: "SEO & Web Tools", icon: "SearchCode", color: "text-indigo-500", bg: "bg-indigo-50" }
];

export const TOOLS: ToolData[] = [
  // --- PDF TOOLS ---
  {
    title: "PDF Compressor",
    slug: "pdf-compressor",
    description: "Compress and reduce the file size of your PDF documents online while maintaining optimum layout quality.",
    category: "pdf",
    seoTitle: "Free PDF Compressor Online - Reduce PDF File Size",
    metaDescription: "Easily compress and shrink PDF document sizes online for free. Maintain high text and image quality with our advanced lightweight compression engine.",
    featured: true,
    trending: true,
    mostUsed: true,
    icon: "FileDown",
    features: [
      "No download or registration required",
      "Saves device storage and allows faster email attachments",
      "Secure server-free browser processing",
      "Lossless quality tuning"
    ],
    faq: [
      { q: "How does the PDF Compressor work?", a: "Our web-based tool optimizes embedded images and compresses fonts within the PDF structure, stripping redundant metadata to reduce file sizes safely." },
      { q: "Is my private data secure with this tool?", a: "Yes, all standard compressions are computed local to your browser environment, meaning your documents are never uploaded to any remote server." }
    ]
  },
  {
    title: "Merge PDF",
    slug: "merge-pdf",
    description: "Combine multiple PDF files into a single, organized document in your desired page order.",
    category: "pdf",
    seoTitle: "Merge PDF Online - Combine Multiple PDF Files for Free",
    metaDescription: "Combine multiple PDFs in seconds. Drag and drop to reorder files, then download the merged PDF instantly without watermark.",
    trending: true,
    mostUsed: true,
    icon: "Layers",
    features: ["Drag and drop ordering", "Merge unlimited files", "Lightweight compression while merging", "Keeps PDF hyperlinks intact"],
    faq: [
      { q: "Can I choose the page order of merged PDFs?", a: "Yes. Drag and drop file cards inside our preview selector to sort them before merging." }
    ]
  },
  {
    title: "Split PDF",
    slug: "split-pdf",
    description: "Extract specific pages from your PDF file or split each page into a separate individual PDF document.",
    category: "pdf",
    seoTitle: "Split PDF Online - Extract Pages from PDF Document",
    metaDescription: "Extract single pages or split range lists from any PDF immediately. No registration or installation required.",
    icon: "Scissors",
    features: ["Extract custom page ranges", "Split every page into single files", "Real-time thumbnail pages", "High-speed extraction"],
    faq: [{ q: "How many page ranges can I extract?", a: "You can specify any number of custom split markers to download clean sliced increments." }]
  },
  {
    title: "JPG to PDF",
    slug: "jpg-to-pdf",
    description: "Convert JPG and other image formats to clean PDF files with customizable page margins and orientation.",
    category: "pdf",
    seoTitle: "Convert JPG to PDF Online - Free Image to PDF Converter",
    metaDescription: "Convert your JPG, JPEG, and PNG images to professional PDF documents easily. Custom margin, padding, and layout orientation controls.",
    icon: "FileImage",
    features: ["Batch convert multiple images", "Adjust margins and fit types", "Supports portrait or landscape formats", "Instant high fidelity compile"],
    faq: [{ q: "Does page sequence correspond to upload queue?", a: "Yes, images will stack sequentially in the same order you choose them." }]
  },
  {
    title: "PDF to JPG",
    slug: "pdf-to-jpg",
    description: "Extract high-resolution images from any PDF file or convert document pages into individual JPG files.",
    category: "pdf",
    seoTitle: "Convert PDF to JPG Online - Extract Images from PDF",
    metaDescription: "Convert single PDF pages to separate high DPI JPG/PNG formats instantly. High-quality client-side rendering.",
    icon: "Image",
    features: ["Convert whole pages into JPG image files", "Download individual files or zip bundles", "Render high definition visual graphics", "Extremely secure browser-side parsing"],
    faq: [{ q: "Is the resolution sufficient for print applications?", a: "Yes, our converter matches the embedded high-resolution visual DPI." }]
  },
  {
    title: "Rotate PDF",
    slug: "rotate-pdf",
    description: "Rotate vertical or horizontal pages in your PDF document and save them globally or individually.",
    category: "pdf",
    seoTitle: "Rotate PDF Pages Online - Fast Free Rotator",
    metaDescription: "Rotate specific pages or entire PDF files. Simple visual click interface with immediate export.",
    icon: "RotateCw",
    features: ["90, 180, or 270-degree rotation", "Visual sandbox dashboard", "Apply to range, odd, or even pages", "Ultra lightweight process"],
    faq: [{ q: "Can I rotate a single slide instead of all slides?", a: "Yes, click on specific page items in the display module to rotate individually." }]
  },
  {
    title: "Watermark PDF",
    slug: "watermark-pdf",
    description: "Add customized text or image watermarks to your PDF documents. Set opacity, position, and font size.",
    category: "pdf",
    seoTitle: "Add Watermark to PDF Online - Free PDF Security Protection",
    metaDescription: "Stamp custom watermark labels onto any PDF document easily. Configure margins, angle orientation, scaling, and opacity overlays.",
    icon: "Stamp",
    features: ["Multi-angle rotational overlays", "Real-time overlay previews", "Complete transparency alpha-slider", "Add text or vector graphics"],
    faq: [{ q: "Will the watermark stay locked behind editing blocks?", a: "Yes, standard watermarking embeds layer tags directly into the PDF source structure." }]
  },
  {
    title: "Lock PDF",
    slug: "lock-pdf",
    description: "Encrypt and secure your PDF document with strong password protection to prevent unauthorized access.",
    category: "pdf",
    seoTitle: "Protect PDF with Password Online - Free Secure Lock Tool",
    metaDescription: "Add industry-standard strong file protection passwords to encrypt and seal your PDF documents safely from viewers.",
    icon: "Lock",
    features: ["Strong 128-bit file level encryption", "Passwords keep layouts sealed", "Completely browser processed protection", "No data logs archived"],
    faq: [{ q: "Is there a default limit to password length?", a: "We support standard ASCII security characters of any custom length." }]
  },
  {
    title: "Unlock PDF",
    slug: "unlock-pdf",
    description: "Remove password security protection layers from your PDF documents if you own the authorization credentials.",
    category: "pdf",
    seoTitle: "Unlock Secured PDFs Online - Decrypt Protected Documents",
    metaDescription: "Remove restrictive locks and password barriers from verified files to unlock permanent print, edit, and viewer rights.",
    icon: "Unlock",
    features: ["Removes print blocks, copy blocks, and edit restrictions", "Instantly decrypts validated items", "Supports standard PDF encryption models", "No installation necessary"],
    faq: [{ q: "Will I need to enter the passwords once to unlock?", a: "Yes, to decrypt standard secure documents, inputting the correct security credentials once is mandatory." }]
  },
  {
    title: "PDF Page Number",
    slug: "pdf-page-number",
    description: "Insert sequential page numbers to document headers or footers with automated custom alignment.",
    category: "pdf",
    seoTitle: "Add Page Numbers to PDF Online - Fast Pagination Tool",
    metaDescription: "Paginate your PDF documents. Select starting index, placement corners, custom font styles, and header tags.",
    icon: "Hash",
    features: ["Choose from dozens of pagination numbering formats", "Set margins and alignment vectors", "Ignore index cover pages", "Quick automated rendering"],
    faq: [{ q: "Can I place page numbers in the top header?", a: "Yes, standard alignments like top-left, top-right, bottom-center, etc., are selectable." }]
  },

  // --- IMAGE TOOLS ---
  {
    title: "Image Compressor",
    slug: "image-compressor",
    description: "Compress or resize PNG, JPG, and WebP files online. Select output parameters for minimal file sizes with pristine clarity.",
    category: "image",
    seoTitle: "Free Image Compressor - Compress PNG, JPG & WebP Online",
    metaDescription: "Reduce the file size of your images in seconds. Optimize file parameters while keeping image dimensions intact.",
    featured: true,
    trending: true,
    mostUsed: true,
    icon: "FileDown",
    features: ["Supports JPEG, PNG, and WebP formats", "Adjust quality slides manually", "Compare source vs compressed file sizes live", "Zero privacy risk with local compilation"],
    faq: [
      { q: "Is the resolution changed during image compression?", a: "No, unless you choose to downscale dimensions. The compressor focuses solely on file size optimizations." }
    ]
  },
  {
    title: "Resize Image",
    slug: "resize-image",
    description: "Resize any image file to custom dimensions or specific ratios with standard crop configurations.",
    category: "image",
    seoTitle: "Resize Image Online - Fast Custom Dimension Adjuster",
    metaDescription: "Instantly adjust width and height in pixels or scale percentages. Keep aspect ratios locked or override constraints easily.",
    icon: "Maximize",
    features: ["Keep aspect ratio locked", "Define custom width and height variables", "Scale by percent, pixels, or ratio blocks", "Instant preview comparison"],
    faq: [{ q: "Will stretching occurred without aspect lock?", a: "Stretching will only occur if aspect lock is unchecked and custom skewed variables are entered." }]
  },
  {
    title: "Crop Image",
    slug: "crop-image",
    description: "Crop and adjust visual focus regions on your images with ease. Select ratio presets like 16:9, 1:1, or 4:3.",
    category: "image",
    seoTitle: "Crop Image Online - Free Crop Tool & Preset Trimmer",
    metaDescription: "Cut and orient image coordinates perfectly. Select pre-loaded visual scale presets or click and drag custom box sizes.",
    icon: "Crop",
    features: ["Dozens of golden ratio aspect pre-selections", "Visual grid guidelines", "Rotate and slice components instantly", "Lossless export outputs"],
    faq: [{ q: "What formats can I save cropped frames as?", a: "We support PNG, JPEG, and WebP formats on export download." }]
  },
  {
    title: "PNG to JPG",
    slug: "png-to-jpg",
    description: "Convert transparent PNG files into high resolution optimized JPG formats instantly.",
    category: "image",
    seoTitle: "Convert PNG to JPG Online - High Fidelity Free Converter",
    metaDescription: "Easily convert PNG files into standard JPG file types. Custom color pickers can fill transparent png spaces.",
    icon: "RefreshCw",
    features: ["Speedy batch image migrations", "Set background filler profiles", "Keeps image quality optimized", "Immediate file compile downloads"],
    faq: [{ q: "Are transparent background regions preserved?", a: "The JPEG format does not support transparency; our editor overlays a clean selectable color block." }]
  },
  {
    title: "JPG to PNG",
    slug: "jpg-to-png",
    description: "Convert JPEG and JPG assets to PNG files with lossless structure compilation.",
    category: "image",
    seoTitle: "Convert JPG to PNG Online - Free Lossless Format Conversion",
    metaDescription: "Transform JPG files into pristine PNG files. Ensure lossless details are completely preserved.",
    icon: "FileImage",
    features: ["Lossless data format conversion", "Drag and drop interface", "Quick batch capabilities", "Secure local browser rendering"],
    faq: [{ q: "Is file size altered during conversion to PNG?", a: "Yes, PNG uses compression formulas that prioritize lossless storage and file structures, which may slightly alter sizes." }]
  },
  {
    title: "Image to WebP",
    slug: "image-to-webp",
    description: "Make websites load significantly faster by converting JPG and PNG images into modern web-optimized WebP files.",
    category: "image",
    seoTitle: "Convert Image to WebP Online - Boost Core Web Vitals to 100",
    metaDescription: "Adopt modern web design structures. Migrate files to efficient Google WebP compression systems instantly.",
    icon: "Zap",
    features: ["Huge web file footprint reductions", "Preserves alpha channels", "Perfect for SEO core vitals load speed", "No quality loss visible"],
    faq: [{ q: "Are browser systems fully compatible with WebP?", a: "Yes, all modern mobile and desktop browsers render WebP optimally." }]
  },
  {
    title: "Blur Image",
    slug: "blur-image",
    description: "Add soft focal or radial blurs to any image. Ideal for cover art and privacy screens.",
    category: "image",
    seoTitle: "Blur Image Online - Free Image Gaussian Blurring Tool",
    metaDescription: "Apply soft blurring parameters to your layouts. Select blur radius size dynamically with a live visual card tracker.",
    icon: "EyeOff",
    features: ["Precision CSS Gaussian filter templates", "Adjustable sliders", "Download styled files directly", "No file quality loss"],
    faq: [{ q: "Can I invert the blur layout?", a: "No, this standard image filter blurs the entire visual element smoothly." }]
  },
  {
    title: "Sharpen Image",
    slug: "sharpen-image",
    description: "Enhance details, texture patterns, and crisp margins inside blurry photograph structures.",
    category: "image",
    seoTitle: "Sharpen Image Online - Enhance Details and Edge Definition",
    metaDescription: "Improve edge contrast and clarify flat images online. Increase resolution fidelity with advanced matrix convolution filters.",
    icon: "Sparkles",
    features: ["Convolution edge sharpening algorithms", "Clear fine texture elements", "Contrast optimizer matrices", "Pragmatic simple controls"],
    faq: [{ q: "Can severe lens defocus be restored?", a: "Sharpening increases edge definition but will not rebuild extreme heavily Out-of-Focus photographs." }]
  },
  {
    title: "Meme Generator",
    slug: "meme-generator",
    description: "Create funny meme cards using popular preset layouts or upload your custom background photo.",
    category: "image",
    seoTitle: "Meme Generator Online - Free Meme Maker & Text Editor",
    metaDescription: "Build internet meme cards easily. Customizable top and bottom texts, font sizes, text stroke widths, and export formats.",
    icon: "Smile",
    features: ["Top and bottom text layers", "Adjust font sizes and outline parameters", "Upload custom images instantly", "Drag and drop text layout boxes"],
    faq: [{ q: "Do you add watermark stamps?", a: "Absolutely not! All meme graphics are generated cleanly with zero branded watermarks." }]
  },
  {
    title: "Background Remover",
    slug: "background-remover",
    description: "Isolate subjects and cleanly remove photo backgrounds using threshold masking overlays.",
    category: "image",
    seoTitle: "Free Background Remover - Transparency Subject Isolator",
    metaDescription: "Isolate subjects from backgrounds. Fine-tune chroma key matching configurations to generate clean transparent alpha PNG files.",
    icon: "Eraser",
    features: ["Smart alpha channel maskings", "RGB threshold color ranges", "Smooth boundary anti-aliasing edges", "Fast localized parsing"],
    faq: [{ q: "Does this require complex manual brush tracing?", a: "No, adjust our simple key threshold sliders to automatically delete background blocks instantly." }]
  },

  // --- CALCULATORS ---
  {
    title: "EMI Calculator",
    slug: "emi-calculator",
    description: "Calculate your monthly Equated Monthly Installment (EMI) outlays for house, car, or personal financial loans.",
    category: "calculators",
    seoTitle: "EMI Calculator - Calculate Home, Car & Personal Loan EMIs",
    metaDescription: "Check loan outlays. Calculate monthly payments, total interest payables, and detailed annual amortization tables using interactive loan sliders.",
    featured: true,
    trending: true,
    mostUsed: true,
    icon: "Percent",
    features: ["Dynamic loan value sliders", "Clear breakdowns of interest vs principal payments", "Comprehensive monthly amortization charts", "Printable payment schedules"],
    faq: [
      { q: "What does the monthly amortization table show?", a: "It breaks down how much of each payment goes toward the principal amount versus accumulating interest fees over time." }
    ]
  },
  {
    title: "GST Calculator",
    slug: "gst-calculator",
    description: "Accurately compute Goods and Services Tax (GST) values with quick percentage presets.",
    category: "calculators",
    seoTitle: "Online GST Calculator - Add or Remove GST Instantly",
    metaDescription: "Accurately compute net prices, tax totals, gross payables, plus detailed CGST, SGST, and IGST breakdowns over simple clicks.",
    trending: true,
    icon: "Percent",
    features: ["Add or subtract GST percentages easily", "India and global GST rates ready (5%, 12%, 18%, 28%)", "Dynamic CGST and SGST balance divisions", "Copy calculation summary with one click"],
    faq: [{ q: "What is the difference between CGST and SGST?", a: "CGST stands for Central Goods and Services Tax, collected by Union authorities; SGST is State-level, collected locally." }]
  },
  {
    title: "SIP Calculator",
    slug: "sip-calculator",
    description: "Estimate your future investment compounding wealth from monthly Systematic Investment Plans (SIP).",
    category: "calculators",
    seoTitle: "SIP Calculator - Estimate Mutual Fund Growing Wealth",
    metaDescription: "Plan your retirement. Input monthly outlays, estimated percentage yields, and time intervals to project total compounding returns easily.",
    mostUsed: true,
    icon: "LineChart",
    features: ["Visual compounding charts", "Adjustable expected return percentages", "Breaks down invested capital versus estimated interest growth", "Supports custom inflation toggles"],
    faq: [{ q: "How are SIP rewards compiled?", a: "SIP calculations utilize standard compounding interest formulas based on monthly reinvestment cycles." }]
  },
  {
    title: "BMI Calculator",
    slug: "bmi-calculator",
    description: "Calculate your Body Mass Index (BMI). Monitor your height and weight variables according to WHO classifications.",
    category: "calculators",
    seoTitle: "Free BMI Calculator - Estimate Health and Body Mass Index",
    metaDescription: "Input height and weight to estimate BMI levels. Receive clear category feedback ranging from underweight to obese instantly.",
    icon: "Eye",
    features: ["Supports Metric (kg/cm) and Imperial (lbs/inches) systems", "Real-time slider adjustments", "WHO classification meters", "Daily caloric guidance indicators"],
    faq: [{ q: "Is BMI an accurate measure of overall health?", a: "BMI is a simple reference parameter. High muscle mass or specific body shapes might skew standard indicators." }]
  },
  {
    title: "Age Calculator",
    slug: "age-calculator",
    description: "Find your precise age in years, months, days, minutes, and seconds. View next birthday countdown timer.",
    category: "calculators",
    seoTitle: "Precise Age Calculator - Calculate exact age to target days",
    metaDescription: "Find your exact age to the target minutes. Learn leap years passed, weekday of birth day, plus upcoming birthday schedules.",
    icon: "Clock",
    features: ["Calculate exact years, months, days, and hours lived", "Dynamic next birthday countdown ticker", "Learn historical astronomical milestones", "Weekday analyzer of birth"],
    faq: [{ q: "Does the age calculations automatically adjust for leap years?", a: "Yes, our datetime engine automatically factors in exact calendar structures and leap days." }]
  },
  {
    title: "Loan Calculator",
    slug: "loan-calculator",
    description: "Calculate interest fees, payoff periods, and maximum borrow allocations with ease.",
    category: "calculators",
    seoTitle: "Loan Interest Calculator - Payoff & Debt Schedule Tracker",
    metaDescription: "Review alternative payment routes. Compare lump sum versus recurring schedules to avoid high debt accumulations.",
    icon: "Coins",
    features: ["Custom frequency schedules (weekly, monthly, quarterly)", "Estimate maximum borrow potential safely", "Interactive visualizations", "Easy field clearing inputs"],
    faq: [{ q: "What parameters determine loan capabilities?", a: "Your annual household income, debt outlays, and expected loan rate terms outline max limits." }]
  },
  {
    title: "Discount Calculator",
    slug: "discount-calculator",
    description: "Quickly determine savings and net prices on seasonal discounts and sales.",
    category: "calculators",
    seoTitle: "Discount Calculator - Compute Savings and Final Sale Pricing",
    metaDescription: "Plan shopping runs. Calculate sales tax additions, final pricing levels, and capital savings instantly over custom sliders.",
    icon: "Tag",
    features: ["Percentage off selectors", "Double stack discount layers (e.g. 20% + extra 10% off)", "Tax rate customization", "Live summary boxes"],
    faq: [{ q: "How is a double discount calculated?", a: "The second layer is calculated relative to the remaining balance after the first percentage savings are decremented." }]
  },
  {
    title: "Percentage Calculator",
    slug: "percentage-calculator",
    description: "Perform quick mathematical percentage calculations. Solve percentage increase, decrease, or baseline change equations.",
    category: "calculators",
    seoTitle: "Percentage Calculator - Solve Sales Increases and Decreases",
    metaDescription: "Solve standard percentages instantly. Calculate what percentage values are of other numbers, or differences between assets.",
    icon: "Percent",
    features: ["Three common percentage mathematical structures", "Calculates percentage changes", "Automated result triggers", "Copy summaries with one click"],
    faq: [{ q: "Can I input decimal parameters?", a: "Yes, all inputs support high-precision decimal variables." }]
  },
  {
    title: "Currency Converter",
    slug: "currency-converter",
    description: "Convert capital between standard international currencies with mock or live-ready rates.",
    category: "calculators",
    seoTitle: "Currency Converter Online - Real-Time Exchange Calculator",
    metaDescription: "Check standard global exchange parameters. Convert dollars, euros, yen, rupees, and pounds instantly.",
    icon: "DollarSign",
    features: ["Dozens of high liquidity currencies supported", "Clean real-time conversion visualizers", "Revert target mappings instantly", "Secure calculation metrics"],
    faq: [{ q: "How frequently are exchange rates updated?", a: "Standard mock configurations maintain daily update parameters." }]
  },
  {
    title: "Scientific Calculator",
    slug: "scientific-calculator",
    description: "Fully featured scientific calculator with trigonometric, logarithmic, and logical operations.",
    category: "calculators",
    seoTitle: "Scientific Calculator Online - Complete Advanced Utility",
    metaDescription: "Complete algebra homework. Solve trigonometry functions, logarithmic exponents, powers, and roots inside a clean interface.",
    icon: "Grid",
    features: ["Trigonometry functions (sin, cos, tan, plus counterparts)", "Logarithms and exponential scaling", "Parentheses order memory", "Clean responsive dark mode keyboard"],
    faq: [{ q: "Are trigonometric ratios evaluated in degrees or radians?", a: "We support quick DEG and RAD toggle buttons to match standard expectations." }]
  },

  // --- STUDENT TOOLS ---
  {
    title: "Word Counter",
    slug: "word-counter",
    description: "Analyze character lengths, reading schedules, sentences, and paragraphs inside a rich text area.",
    category: "student",
    seoTitle: "Free Word Counter Online - Analyze Characters & Reading Times",
    metaDescription: "Count words, letters, phrases, and punctuation marks. Analyze read latency, sentence averages, and density factors instantly.",
    featured: true,
    trending: true,
    mostUsed: true,
    icon: "Type",
    features: ["Real-time statistics updating", "Flesch Reader ease scores", "Counts characters with or without whitespaces", "Keyword density matrices"],
    faq: [
      { q: "Is there a limit to the length of text I can paste?", a: "No, our lightning-fast state model processes long dissertation projects cleanly." }
    ]
  },
  {
    title: "Character Counter",
    slug: "character-counter",
    description: "Count character and word quantities with exact visual limit meters. Perfect for social media posts.",
    category: "student",
    seoTitle: "Character Counter Online - Social Media Length Tracker",
    metaDescription: "Track letter margins. Check precise length limits for Twitter (280), SMS (160), and Google meta titles (60).",
    icon: "Hash",
    features: ["Sleek progress circles for social networks", "Live copy button", "Count letter structures, numbers, and symbols", "Compact mobile optimized design"],
    faq: [{ q: "Do emoji symbols count as individual characters?", a: "Yes, standard UTF emojis evaluate as single or double indexing lengths." }]
  },
  {
    title: "GPA Calculator",
    slug: "gpa-calculator",
    description: "Calculate your semester GPA based on custom letter grades and credit hours.",
    category: "student",
    seoTitle: "GPA Calculator Online - Semester Credit Point Tool",
    metaDescription: "Manage college metrics. Input grades and course weighting elements to calculate your semester performance easily.",
    mostUsed: true,
    icon: "GraduationCap",
    features: ["Add unlimited course modules", "Supports custom grade scale values (4.0, 5.0, etc.)", "Weighted credit calculations", "Clean printable results layout"],
    faq: [{ q: "How is a standard GPA compiled?", a: "We multiply course credit hours by grade numeric weights, summing targets and dividing by total credit values." }]
  },
  {
    title: "CGPA Calculator",
    slug: "cgpa-calculator",
    description: "Estimate your cumulative GPA (CGPA) using average semester credit statistics.",
    category: "student",
    seoTitle: "CGPA Calculator Online - Cumulative Grade Point Average",
    metaDescription: "Estimate academic standards. Input standard historical semester grade structures to calculate active CGPA metrics.",
    icon: "BookOpen",
    features: ["Input up to ten semesters", "Weight items by relative credit load", "Convert CGPA to percentages automatically", "Automated entry buffers"],
    faq: [{ q: "What is the formula to convert CGPA to percentages?", a: "For CBSE guidelines, CGPA is typically multiplied by 9.5 to project equivalent scores." }]
  },
  {
    title: "Essay Counter",
    slug: "essay-counter",
    description: "Target specific sentence sizes, average structural word lengths, and page structures.",
    category: "student",
    seoTitle: "Essay Counter Online - Target Pages & Vocabulary Checker",
    metaDescription: "Evaluate active academic essay progress. Project printed page requirements, vocabulary frequencies, and spacing limits.",
    icon: "FileSignature",
    features: ["Page quantity projector metrics", "Active keyword density arrays", "Structural paragraph breakdowns", "Automatic content cache buffers"],
    faq: [{ q: "How are printed pages projected?", a: "Standard double-spaced essay pages evaluate to approximately 250 words per layout sheet." }]
  },
  {
    title: "Notes Formatter",
    slug: "notes-formatter",
    description: "Convert messy study scribble inputs into organized checklist outlines or bold bulletin layouts.",
    category: "student",
    seoTitle: "Study Notes Formatter - Format Study Notes Online",
    metaDescription: "Clean up lecture logs. Reorganize messy transcript files into beautifully bulleted outline formats easily.",
    icon: "LayoutList",
    features: ["One-click cleaning filters", "Transform bullet symbols into structured list trees", "Clean whitespace fragments", "Capitalize heading phrases automatically"],
    faq: [{ q: "Will pasting mess from chat programs format properly?", a: "Yes, our algorithm is engineered to strip annoying chat stamps and alignment spacing bugs." }]
  },
  {
    title: "Text Case Converter",
    slug: "text-case-converter",
    description: "Convert text paragraphs into sentence case, uppercase, lowercase, title case, or proper casing.",
    category: "student",
    seoTitle: "Text Case Converter - UPPERCASE, lowercase, Title Case Online",
    metaDescription: "Change text caps instantly. Swap word case models, invert lettering orders, and space elements safely.",
    icon: "ALargeSmall",
    features: ["Sentence case, UPPERCASE, lowercase, Title Case, and alternating modes", "Copy to clipboard button", "Clear layout instantly", "Live word counts"],
    faq: [{ q: "How does Title Case evaluate small prepositions?", a: "Our advanced algorithm ignores prepositions like 'and', 'the', or 'of' automatically inside sentences." }]
  },
  {
    title: "Plagiarism Checker",
    slug: "plagiarism-checker",
    description: "Compare structural similarity scores between paragraphs or search for duplicate patterns.",
    category: "student",
    seoTitle: "Plagiarism Similarity Checker - Free Copy Compare Tool",
    metaDescription: "Verify copywriting uniqueness. Cross-examine block texts or files side-by-side to review matching percentages.",
    icon: "FileCheck",
    features: ["Levensthein similarity matches", "Side-by-side highlighted text disparities", "Deduce exact matching percentage rates", "Extremely fast local calculations"],
    faq: [{ q: "Is my text checked against the index of internet articles?", a: "This offline, secure comparator evaluates the direct documents or paragraphs you submit alongside each other." }]
  },

  // --- RESUME & OFFICE ---
  {
    title: "Resume Maker",
    slug: "resume-maker",
    description: "Create a professional PDF resume using custom resume layout templates and easy profile form fields.",
    category: "office",
    seoTitle: "Free Resume Maker - Build PDF Resume Online",
    metaDescription: "Build optimized PDF resumes. Input professional records, education histories, and contact variables to generate minimal templates.",
    featured: true,
    trending: true,
    icon: "UserSquare2",
    features: ["Clean minimalistic professional templates", "Interactive, reactive form sections", "Fully exportable as polished standard PDF structures", "Zero tracking profile registries"],
    faq: [
      { q: "Is the resume file formatted correctly for automated applicant parsers (ATS)?", a: "Yes, we generate structured text layers that automated applicant screening algorithms interpret cleanly." }
    ]
  },
  {
    title: "Invoice Generator",
    slug: "invoice-generator",
    description: "Create and export clean commercial invoices. Configure billing summaries, rate structures, and global tax variables.",
    category: "office",
    seoTitle: "Free Invoice Generator - Create Branded PDF Invoices",
    metaDescription: "Create invoices quickly. Add professional item lines, price structures, company logos, and tax parameters.",
    trending: true,
    icon: "Receipt",
    features: ["Add company logo files dynamically", "Tax, discount, and currency custom select matrices", "Item line multiplier arithmetic", "Print-ready layout formats"],
    faq: [{ q: "Can I choose different currency symbols?", a: "Yes, standard currency vectors like $, €, £, ¥, and ₹ are available." }]
  },
  {
    title: "Signature Maker",
    slug: "signature-maker",
    description: "Draw custom digital signatures with a smooth canvas board or auto-generate cursive scripts from your name inputs.",
    category: "office",
    seoTitle: "Signature Maker - Draw Digital Autograph Signatures",
    metaDescription: "Draw professional signatures online. Customize pen widths, stroke colors, and export background levels to download transparent PNG signatures.",
    icon: "PenTool",
    features: ["Responsive canvas drawing engine", "Beautiful cursive type generation templates", "Transparency PNG overlays", "Easy clear buttons"],
    faq: [{ q: "Are drawn canvas layouts high fidelity?", a: "Yes, we capture vectors accurately to prevent fuzzy rasterized results on digital PDF embeds." }]
  },
  {
    title: "QR Code Generator",
    slug: "qr-code-generator",
    description: "Generate high definition QR code symbols from links, text strings, contact cards, or WiFi details.",
    category: "office",
    seoTitle: "QR Code Generator - Generate QR Codes for Free",
    metaDescription: "Generate free QR codes instantly. Fast customizable outputs with margin controllers and safe URL linkages.",
    mostUsed: true,
    icon: "QrCode",
    features: ["Convert URLs, phone lines, plain texts, and contact details", "Adjust size dimensions and margin parameters", "Interactive live preview layout", "High fidelity SVG or PNG download configurations"],
    faq: [{ q: "Can the generated QR codes expire?", a: "Never. Static QR codes encode the data directly, meaning they remain active indefinitely with zero external dependencies." }]
  },
  {
    title: "Barcode Generator",
    slug: "barcode-generator",
    description: "Encode custom UPC, EAN, or Code 128 variables into standard compliance barcodes.",
    category: "office",
    seoTitle: "Barcode Generator Online - Free UPC & EAN Barcode Maker",
    metaDescription: "Render standard serial barcodes. Generate Code 128, EAN-13, and UPC layouts cleanly to download or print.",
    icon: "Barcode",
    features: ["Multiple international format standards supported", "Include optional helper text captions", "Adjust bar width elements", "Instant high-resolution SVG outputs"],
    faq: [{ q: "What barcode formats operate in US retail systems?", a: "The UPC-A standard is widely utilized in retail ecosystems throughout North America." }]
  },
  {
    title: "Business Card Maker",
    slug: "business-card-maker",
    description: "Create premium, minimalist corporate business card mockups and download printable PDF structures.",
    category: "office",
    seoTitle: "Business Card Maker - Design Free Corporate Cards",
    metaDescription: "Select clean minimal layout coordinates. Add company logos, employee positions, phone numbers, and color patterns.",
    icon: "Contact",
    features: ["Front and back visual card boards", "Interactive alignment tools", "Export standard resolution cards", "Easy custom grid guidelines"],
    faq: [{ q: "What is the standard sizing dimensions for cards?", a: "Standard cards measure 3.5 inches by 2 inches in traditional landscape formats." }]
  },
  {
    title: "Certificate Generator",
    slug: "certificate-generator",
    description: "Create elegant school, course, or achievement certificates with customizable content fields.",
    category: "office",
    seoTitle: "Certificate Generator - Free Course Achievement Layouts",
    metaDescription: "Acknowledge team accomplishments. Fill in names, courses, dates, and signee fields to render elegant certificates.",
    icon: "Award",
    features: ["Dozens of premium classical border profiles", "Dynamic vector signature overlays", "Editable layout lines", "Download high fidelity print-ready PDF files"],
    faq: [{ q: "Can I stamp custom company seals?", a: "Yes, you can easily load high-contrast transparent corporate seal graphics." }]
  },

  // --- SEO & WEB TOOLS ---
  {
    title: "Meta Tag Generator",
    slug: "meta-tag-generator",
    description: "Generate SEO metadata tag HTML blocks with real-time viewport, social media, and search card previews.",
    category: "seo",
    seoTitle: "SEO Meta Tag Generator - Boost Search Click Ratios",
    metaDescription: "Build optimal layout titles, descriptions, viewport tags, Open Graph profiles, and Twitter cards instantly.",
    featured: true,
    trending: true,
    mostUsed: true,
    icon: "SearchCode",
    features: ["Real-time Google search snippet preview", "Facebook Open Graph and Twitter Card mockups", "Clean, copyable HTML meta blocks", "Includes robots indexing toggles"],
    faq: [
      { q: "Where do I insert the compiled meta tags?", a: "Copy and paste the output block inside the `<head>` section of your website HTML template." }
    ]
  },
  {
    title: "Sitemap Generator",
    slug: "sitemap-generator",
    description: "Generate standards-compliant XML sitemaps easily. Set crawl priority, paths, and change frequencies.",
    category: "seo",
    seoTitle: "XML Sitemap Generator - Free Indexing Accelerators",
    metaDescription: "Compile compliant indices. Input domains, edit change intervals, and configure priority scales to retrieve clean XML sitemaps.",
    icon: "Network",
    features: ["Outputs fully compliant XML markup", "Configure dynamic crawl levels", "Set custom dates", "Fast local builder structure"],
    faq: [{ q: "How many pages can Google index via standard sitemaps?", a: "A single XML sitemap can list up to 50,000 URLs or 50MB before splitting indexes." }]
  },
  {
    title: "Robots.txt Generator",
    slug: "robots.txt-generator",
    description: "Optimize web spider crawl behaviors. Generate custom robots.txt files with simple rule builders.",
    category: "seo",
    seoTitle: "Robots.txt Generator - Optimize Web Crawl Budgets",
    metaDescription: "Instruct web search spiders. Build block rules for user agents, ignore slow directories, and include sitemap routes.",
    icon: "Bot",
    features: ["Block common spam bot agents instantly", "Define custom user-agent rules", "Embed sitemap paths dynamically", "Clean copyable outputs"],
    faq: [{ q: "Where does the robots.txt file sit?", a: "Place the file directly at the root directory of your website hostname (e.g., example.com/robots.txt)." }]
  },
  {
    title: "JSON Formatter",
    slug: "json-formatter",
    description: "Validate, beautify, minify, and restructure JSON strings with simple custom tab spacing.",
    category: "seo",
    seoTitle: "JSON Formatter - Validate and Beautify JSON Markup",
    metaDescription: "Clean up developer structures. Scan syntactic errors, reformat messy strings, or compact files instantly.",
    mostUsed: true,
    icon: "Braces",
    features: ["Validates active structures in real time", "Formats with 2, 3, or 4 tab spacing options", "Minify JSON structures seamlessly", "Click to copy or download files"],
    faq: [{ q: "Does the utility log pasted JSON payloads?", a: "Our utility parses data local to your computer. Nothing gets archived on the internet." }]
  },
  {
    title: "HTML Minifier",
    slug: "html-minifier",
    description: "Compress HTML markup structures. Remove comment blocks, excessive whitespaces, and spacing characters.",
    category: "seo",
    seoTitle: "HTML Minifier - Compress and Optimize Web Code",
    metaDescription: "Compress website layouts. Compress markup weight indexes to speed up server response metrics.",
    icon: "FileCode2",
    features: ["Strips redundant spacing configurations", "Deletes comment blocks", "Optimizes nested spaces", "Real-time savings tracker"],
    faq: [{ q: "Will minification break active client script files?", a: "Standard formatting keeps functional characters safe; avoid using line-terminating syntax bugs inside your code." }]
  },
  {
    title: "CSS Minifier",
    slug: "css-minifier",
    description: "Minify stylesheet contents to speed up website rendering. Strips spaces and comment blocks.",
    category: "seo",
    seoTitle: "CSS Minifier - Minify and Compress CSS Files",
    metaDescription: "Compress custom design grids. Strip spaces, margins, and redundant blocks to speed up user loads.",
    icon: "Palette",
    features: ["Consolidates style identifiers", "Deletes redundant stylesheet tags", "Showcases exact percentage weight drops", "Download stylesheet files"],
    faq: [{ q: "What percentage savings can be achieved?", a: "Standard bloated stylesheets commonly compress up to 30-50% in storage weight." }]
  },
  {
    title: "JavaScript Minifier",
    slug: "javascript-minifier",
    description: "Minify client-side scripts to speed up download and browser execution speeds.",
    category: "seo",
    seoTitle: "JavaScript Minifier - Strip Whitespace and Compress JS",
    metaDescription: "Optimize developer modules. Remove comment blocks, strip variable name sizes, and aggregate layouts.",
    icon: "FileCode",
    features: ["Strips logic spaces and developer lines", "Combines standard commands safely", "Live comparison statistics", "Instant safe compilation"],
    faq: [{ q: "Are script functions altered during minifying?", a: "We compress spacing structures and format elements without altering core functional architectures." }]
  },
  {
    title: "Base64 Encoder Decoder",
    slug: "base64-encoder-decoder",
    description: "Encode text fields into standard Base64 format or decode active structures back to plain text strings.",
    category: "seo",
    seoTitle: "Base64 Encoder & Decoder - High Speed UTF Conversions",
    metaDescription: "Transform text blocks of any weight. Encode or decode UTF variables safely through high-fidelity visual cards.",
    icon: "Binary",
    features: ["High fidelity real-time calculations", "Clean separate input/output boxes", "Handles complex special character systems", "Copy results cleanly"],
    faq: [{ q: "Is Base64 considered a strong encryption method?", a: "No, Base64 is a translation system for binary data encoding, not a lock pattern." }]
  },
  {
    title: "URL Encoder Decoder",
    slug: "url-encoder-decoder",
    description: "Convert special characters into URL-compliant percent-encoded formats or decode them back.",
    category: "seo",
    seoTitle: "URL Encoder Decoder - Percent Encoding Tool",
    metaDescription: "Format clean web queries. Convert spaces into compliance codes (`%20`) or decode deep website query links easily.",
    icon: "Link2",
    features: ["Standard percent encoding conversion tables", "Converts query structures cleanly", "Single click swap functionalities", "Fast local calculation"],
    faq: [{ q: "Why are parameters encoded?", a: "Internet hosts require strict characters within request queries to prevent transport ambiguities." }]
  },
  {
    title: "Password Generator",
    slug: "password-generator",
    description: "Generate highly secure, unpredictable passwords. Configure character variations, lengths, and custom exclusions.",
    category: "seo",
    seoTitle: "Secure Password Generator - Create Strong Non-hackable Passwords",
    metaDescription: "Avert web breaches. Build strong credentials containing letters, numbers, and symbols to maximize security protections.",
    icon: "KeySquare",
    features: ["Configurable length structures (8 to 64 letters)", "Include uppercase, numbers, and symbols", "Visual strength classification progress grids", "One-click copy and regenerate functions"],
    faq: [{ q: "Are there records of my custom credentials stored on your servers?", a: "Never. All strings are generated directly in your system. We do not transmit or log any outputs." }]
  }
];
