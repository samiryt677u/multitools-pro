import React, { useState, useEffect } from "react";
import Navigation from "./components/Navigation";
import Footer from "./components/Footer";
import CookieNotice from "./components/CookieNotice";
import HomeView from "./views/HomeView";
import ToolView from "./views/ToolView";
import BlogView from "./views/BlogView";
import StaticView from "./views/StaticView";
import AdminView from "./views/AdminView";
import MobileBottomNav from "./components/MobileBottomNav";
import { getStoredTools } from "./utils/storage";

interface RouteState {
  page: string;      // "home" | "tool" | "blog" | "about" | "contact" | "privacy" | "terms" | "disclaimer" | "admin"
  slug?: string;     // tool or blog slug
}

export default function App() {
  const [route, setRoute] = useState<RouteState>({ page: "home" });
  const [darkMode] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  // 1. Synchronize React state with window.location.hash on load and on hash change!
  useEffect(() => {
    const parseHashRoute = () => {
      const hash = window.location.hash;
      
      if (!hash || hash === "#" || hash === "#/") {
        setRoute({ page: "home" });
        return;
      }

      if (hash.startsWith("#/tool/")) {
        const slug = hash.replace("#/tool/", "");
        setRoute({ page: "tool", slug });
        return;
      }

      if (hash.startsWith("#/blog/")) {
        const slug = hash.replace("#/blog/", "");
        setRoute({ page: "blog", slug });
        return;
      }

      if (hash === "#/blog") {
        setRoute({ page: "blog" });
        return;
      }

      if (hash === "#/about") {
        setRoute({ page: "about" });
        return;
      }

      if (hash === "#/contact") {
        setRoute({ page: "contact" });
        return;
      }

      if (hash === "#/privacy") {
        setRoute({ page: "privacy" });
        return;
      }

      if (hash === "#/terms") {
        setRoute({ page: "terms" });
        return;
      }

      if (hash === "#/disclaimer") {
        setRoute({ page: "disclaimer" });
        return;
      }

      if (hash === "#/admin") {
        setRoute({ page: "admin" });
        return;
      }

      // Default fallback
      setRoute({ page: "home" });
    };

    // Parse immediately on load
    parseHashRoute();

    // Listen for hash exchanges
    window.addEventListener("hashchange", parseHashRoute);
    return () => window.removeEventListener("hashchange", parseHashRoute);
  }, []);

  // 2. Custom state transition trigger to modify hash and automatically update route
  const navigateTo = (page: string, slug?: string) => {
    let newHash = "#/";
    if (page === "home") {
      newHash = "#/";
    } else if (page === "tool" && slug) {
      newHash = `#/tool/${slug}`;
    } else if (page === "blog") {
      newHash = slug ? `#/blog/${slug}` : `#/blog`;
    } else {
      newHash = `#/${page}`;
    }

    window.location.hash = newHash;
    // Scroll to top of preview viewport on transition
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Render correct view block
  const renderContent = () => {
    switch (route.page) {
      case "home":
        return <HomeView navigateTo={navigateTo} searchQuery={searchQuery} setSearchQuery={setSearchQuery} />;
      
      case "tool": {
        const activeTool = getStoredTools().find((t) => t.slug === route.slug);
        if (activeTool) {
          return <ToolView tool={activeTool} navigateTo={navigateTo} />;
        }
        return <HomeView navigateTo={navigateTo} searchQuery={searchQuery} setSearchQuery={setSearchQuery} />;
      }

      case "blog":
        return <BlogView slug={route.slug} navigateTo={navigateTo} />;
      
      case "about":
      case "contact":
      case "privacy":
      case "terms":
      case "disclaimer":
        return <StaticView pageType={route.page} />;

      case "admin":
        return <AdminView />;

      default:
        return <HomeView navigateTo={navigateTo} searchQuery={searchQuery} setSearchQuery={setSearchQuery} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col font-sans transition-colors duration-300 relative overflow-hidden bg-[#f8fafc] text-slate-800">
      
      {/* Background Graphic Engine */}
      <div className="absolute inset-0 pointer-events-none select-none z-0">
        {/* Soft Linear Gradient Foundation - Cozy Light Grey & Slate */}
        <div className="absolute inset-0 bg-gradient-to-tr from-[#f8fafc] via-[#f1f5f9] to-[#f8fafc]" />

        {/* Dynamic mesh spot 1 - Soft Pastel Indigo */}
        <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] rounded-full blur-[140px] opacity-40 bg-indigo-200/50 animate-float-slow" />
        
        {/* Dynamic mesh spot 2 - Soft Pastel Violet */}
        <div className="absolute bottom-[-10%] right-[-5%] w-[450px] h-[450px] rounded-full blur-[140px] opacity-35 bg-purple-200/40 animate-float-alt" />

        {/* Dynamic mesh spot 3 - Soft Teal Glow */}
        <div className="absolute top-[35%] right-[20%] w-[380px] h-[380px] rounded-full blur-[130px] opacity-30 bg-teal-100/40 animate-float-slow" />

        {/* Intersecting line grids & dots overlays in light theme format */}
        <div className="absolute inset-0 opacity-80 bg-grid-pattern bg-lines-pattern" />
        
        {/* Vignette ambient overlay */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_40%,rgba(0,0,0,0.01))]" />
      </div>

      {/* Dynamic Header */}
      <div className="relative z-10">
        <Navigation 
          currentRoute={route} 
          navigateTo={navigateTo} 
          darkMode={darkMode} 
          setDarkMode={() => {}} 
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
        />
      </div>

      {/* Primary Page Canvas */}
      <main className="flex-grow pb-16 md:pb-0 relative z-10">
        {renderContent()}
      </main>

      {/* GDPR / Legal Cookie banner */}
      <div className="relative z-30">
        <CookieNotice />
      </div>

      {/* Mobile Bottom Float Bar */}
      <div className="relative z-20">
        <MobileBottomNav currentRoute={route} navigateTo={navigateTo} />
      </div>

      {/* Central Footer */}
      <div className="relative z-10">
        <Footer navigateTo={navigateTo} />
      </div>
    </div>
  );
}
