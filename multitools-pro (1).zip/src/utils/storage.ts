import { BlogPost, BLOG_POSTS } from "../data/blogs";
import { ToolData, TOOLS } from "../data/tools";

const BLOGS_KEY = "mt_pro_blogs";
const TOOLS_KEY = "mt_pro_tools";
const SEO_RULES_KEY = "mt_pro_seo_rules";

export interface SEORule {
  id: string;
  keyword: string;
  densityTarget: number; // percentage
  status: "active" | "deprecated";
  categoryTarget: string;
}

const DEFAULT_SEO_RULES: SEORule[] = [
  { id: "1", keyword: "pdf compressor", densityTarget: 2.5, status: "active", categoryTarget: "pdf" },
  { id: "2", keyword: "secure calculator", densityTarget: 1.8, status: "active", categoryTarget: "calculators" },
  { id: "3", keyword: "meta tags analyzer", densityTarget: 3.0, status: "active", categoryTarget: "seo" },
  { id: "4", keyword: "convert jpg to pdf", densityTarget: 2.2, status: "active", categoryTarget: "pdf" }
];

export function getStoredBlogs(): BlogPost[] {
  if (typeof window === "undefined") return BLOG_POSTS;
  const stored = localStorage.getItem(BLOGS_KEY);
  if (!stored) {
    localStorage.setItem(BLOGS_KEY, JSON.stringify(BLOG_POSTS));
    return BLOG_POSTS;
  }
  try {
    return JSON.parse(stored);
  } catch (e) {
    return BLOG_POSTS;
  }
}

export function saveStoredBlogs(blogs: BlogPost[]): void {
  if (typeof window === "undefined") return;
  localStorage.setItem(BLOGS_KEY, JSON.stringify(blogs));
}

export function getStoredTools(): ToolData[] {
  if (typeof window === "undefined") return TOOLS;
  const stored = localStorage.getItem(TOOLS_KEY);
  if (!stored) {
    localStorage.setItem(TOOLS_KEY, JSON.stringify(TOOLS));
    return TOOLS;
  }
  try {
    return JSON.parse(stored);
  } catch (e) {
    return TOOLS;
  }
}

export function saveStoredTools(tools: ToolData[]): void {
  if (typeof window === "undefined") return;
  localStorage.setItem(TOOLS_KEY, JSON.stringify(tools));
}

export function getStoredSeoRules(): SEORule[] {
  if (typeof window === "undefined") return DEFAULT_SEO_RULES;
  const stored = localStorage.getItem(SEO_RULES_KEY);
  if (!stored) {
    localStorage.setItem(SEO_RULES_KEY, JSON.stringify(DEFAULT_SEO_RULES));
    return DEFAULT_SEO_RULES;
  }
  try {
    return JSON.parse(stored);
  } catch (e) {
    return DEFAULT_SEO_RULES;
  }
}

export function saveStoredSeoRules(rules: SEORule[]): void {
  if (typeof window === "undefined") return;
  localStorage.setItem(SEO_RULES_KEY, JSON.stringify(rules));
}
