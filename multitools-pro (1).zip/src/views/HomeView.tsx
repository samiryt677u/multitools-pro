import React, { useState, useEffect, useRef } from "react";
import { 
  Search, Rocket, Star, TrendingUp, Trophy, Compass, Plus, ArrowUpRight, BookOpen, 
  ChevronRight, Sparkles, Sliders, Check, ShieldCheck, Zap, Laptop, FileText, Image, 
  Calculator, GraduationCap, Briefcase, SearchCode, Clock, RefreshCw, Eye, ShieldAlert,
  Flame, Calendar, Sparkle
} from "lucide-react";
import { CATEGORIES, ToolData } from "../data/tools";
import { getStoredTools, getStoredBlogs } from "../utils/storage";
import AdPlacement from "../components/AdPlacement";
import ToolIcon from "../components/ToolIcon";

interface HomeViewProps {
  navigateTo: (page: string, slug?: string) => void;
  searchQuery: string;
  setSearchQuery: (val: string) => void;
}

export default function HomeView({ navigateTo, searchQuery, setSearchQuery }: HomeViewProps) {
  const [activeCategory, setActiveCategory] = useState<string>("all");
  const homeSearch = searchQuery;
  const setHomeSearch = setSearchQuery;
  const [activeTab, setActiveTab] = useState<"trending" | "recent" | "mostUsed">("trending");
  const [isSearchSticky, setIsSearchSticky] = useState(false);
  const [isFiltering, setIsFiltering] = useState(false);

  const [toolsList, setToolsList] = useState<ToolData[]>(getStoredTools());
  const [blogsList, setBlogsList] = useState<any[]>(getStoredBlogs());

  useEffect(() => {
    setToolsList(getStoredTools());
    setBlogsList(getStoredBlogs());
  }, []);
  
  // States for live search suggestions & recent searches
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem("recent_searches_suite") || "[]");
    } catch {
      return [];
    }
  });

  const searchSectionRef = useRef<HTMLDivElement>(null);
  const homeSearchRef = useRef<HTMLDivElement>(null);

  const addRecentSearch = (term: string) => {
    const clean = term.trim();
    if (!clean) return;
    setRecentSearches(prev => {
      const filtered = prev.filter(t => t.toLowerCase() !== clean.toLowerCase());
      const updated = [clean, ...filtered].slice(0, 5);
      localStorage.setItem("recent_searches_suite", JSON.stringify(updated));
      return updated;
    });
  };

  const removeRecentSearch = (term: string) => {
    setRecentSearches(prev => {
      const updated = prev.filter(t => t !== term);
      localStorage.setItem("recent_searches_suite", JSON.stringify(updated));
      return updated;
    });
  };

  const clearRecentSearches = () => {
    setRecentSearches([]);
    localStorage.removeItem("recent_searches_suite");
  };

  // Add click-outside listener to dismiss search suggestion popover
  useEffect(() => {
    function handleOutsideClick(e: MouseEvent) {
      if (homeSearchRef.current && !homeSearchRef.current.contains(e.target as Node)) {
        setIsSearchFocused(false);
      }
    }
    document.addEventListener("mousedown", handleOutsideClick);
    return () => document.removeEventListener("mousedown", handleOutsideClick);
  }, []);

  // Trigger simulation of loading states when filtering/searching to showcase skeleton layouts
  useEffect(() => {
    setIsFiltering(true);
    const timer = setTimeout(() => {
      setIsFiltering(false);
    }, 280); // snappy 280ms transition simulation
    return () => clearTimeout(timer);
  }, [activeCategory, homeSearch]);

  // Sync category filter with hash changes (e.g. from navigation bar categories dropdown)
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash;
      if (hash.startsWith("#/category/")) {
        const catId = hash.replace("#/category/", "");
        const matchedCat = CATEGORIES.find(c => c.id === catId);
        if (matchedCat) {
          setActiveCategory(catId);
          // Scroll smoothly to tools section
          const el = document.getElementById("tools-anchor");
          if (el) {
            el.scrollIntoView({ behavior: "smooth", block: "start" });
          }
        }
      } else if (hash === "#" || hash === "#/" || !hash) {
        setActiveCategory("all");
      }
    };

    handleHashChange();
    window.addEventListener("hashchange", handleHashChange);
    return () => window.removeEventListener("hashchange", handleHashChange);
  }, []);

  // Monitor scroll for sticky search container
  useEffect(() => {
    const handleScroll = () => {
      if (searchSectionRef.current) {
        const top = searchSectionRef.current.getBoundingClientRect().top;
        setIsSearchSticky(top < 64); // Header height is 16 = 64px
      }
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Filter tools cleanly with smart multi-word keyword matching
  const filteredTools = toolsList.filter((tool) => {
    const matchesCategory = activeCategory === "all" || tool.category === activeCategory;
    const searchLower = homeSearch.toLowerCase().trim();
    if (!searchLower) return matchesCategory;
    
    // Split search query by spaces to allow multi-word keyword matching
    const searchWords = searchLower.split(/\s+/);
    const matchesSearch = searchWords.every(word => 
      tool.title.toLowerCase().includes(word) ||
      tool.description.toLowerCase().includes(word) ||
      tool.category.toLowerCase().includes(word) ||
      tool.slug.toLowerCase().includes(word) ||
      (tool.features && tool.features.some(f => f.toLowerCase().includes(word)))
    );
    return matchesCategory && matchesSearch;
  });

  // Dynamic lists backfilling if fields aren't fully set
  const trendingTools = toolsList.filter(t => t.trending || t.slug.includes("compressor") || t.slug.includes("merge") || t.slug.includes("gst")).slice(0, 8);
  const recentlyAddedTools = toolsList.filter(t => t.recentlyAdded || t.slug.includes("qr") || t.slug.includes("password") || t.slug.includes("meta") || t.slug.includes("barcode")).slice(0, 8);
  const mostUsedTools = toolsList.filter(t => t.mostUsed || t.slug.includes("word-counter") || t.slug.includes("sip-calculator") || t.slug.includes("png-to-jpg") || t.slug.includes("pdf")).slice(0, 8);

  const activeTabTools = activeTab === "trending" 
    ? trendingTools 
    : activeTab === "recent" 
      ? recentlyAddedTools 
      : mostUsedTools;

  return (
    <div className="space-y-12 pb-20 font-sans">
      
      {/* 1. Compact Premium Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-[#e0e7ff]/30 via-transparent to-transparent pt-8 pb-5 px-4 border-b border-slate-100">
        
        {/* Soft atmospheric gradient blur circles */}
        <div className="absolute top-8 left-1/4 w-80 h-80 bg-indigo-200/40 rounded-full filter blur-[100px] pointer-events-none" />
        <div className="absolute top-16 right-1/4 w-72 h-72 bg-purple-100/35 rounded-full filter blur-[90px] pointer-events-none" />

        {/* Ambient Grid Background Style with calibrated low opacity */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#e2e8f0_1px,transparent_1px),linear-gradient(to_bottom,#e2e8f0_1px,transparent_1px)] bg-[size:3.5rem_3.5rem] [mask-image:radial-gradient(ellipse_60%_60%_at_50%_0%,#000_80%,transparent_100%)] opacity-25 pointer-events-none" />

        <div className="text-center max-w-4xl mx-auto space-y-4 relative z-10">
          
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-white/80 backdrop-blur-md border border-slate-200 rounded-full text-[10px] font-extrabold select-none shadow-sm">
            <div className="flex items-center gap-1 text-emerald-600">
              <ShieldCheck className="h-4 w-4 fill-emerald-500/10" />
              <span>Verified MTH Privacy Sandbox</span>
            </div>
            <span className="h-3 w-[1px] bg-slate-300" />
            <span className="text-slate-550 uppercase tracking-wider">Trusted All-In-One MTH</span>
          </div>
          
          <h2 className="text-3xl sm:text-6xl font-display font-black text-slate-900 tracking-tight leading-[1.05] max-w-3xl mx-auto">
            Pristine Web Utilities.<br />
            <span className="bg-gradient-to-r from-indigo-600 via-indigo-500 to-violet-600 bg-clip-text text-transparent">No File Uploads Required.</span>
          </h2>
          
          <p className="text-xs sm:text-sm text-slate-500 max-w-2xl mx-auto leading-relaxed font-semibold">
            Over 50+ single-page high-fidelity tools built specifically to process your critical assets locally inside the active browser frame. No tracking, zero cloud leaks, and premium response times.
          </p>

          {/* Core Trust Badges Section - Premium Glass Effect */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 max-w-3xl mx-auto pt-3 text-left">
            <div className="p-3 bg-white border border-slate-100 rounded-2xl shadow-sm hover:shadow-md hover:border-indigo-300 transition-all duration-300 flex items-center gap-3 group cursor-default">
              <div className="h-9 w-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0 group-hover:scale-105 duration-200">
                <Sliders className="h-4.5 w-4.5" />
              </div>
              <div className="space-y-0.5">
                <h4 className="text-xs font-black text-slate-800">50+ Tools</h4>
                <p className="text-[10px] text-slate-400 font-bold leading-none">Fully Interactive</p>
              </div>
            </div>
            
            <div className="p-3 bg-white border border-slate-100 rounded-2xl shadow-sm hover:shadow-md hover:border-emerald-300 transition-all duration-300 flex items-center gap-3 group cursor-default">
              <div className="h-9 w-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0 group-hover:scale-105 duration-200">
                <ShieldCheck className="h-4.5 w-4.5 animate-pulse" />
              </div>
              <div className="space-y-0.5">
                <h4 className="text-xs font-black text-slate-800">100% Secure</h4>
                <p className="text-[10px] text-slate-400 font-bold leading-none">No Remote Storage</p>
              </div>
            </div>

            <div className="p-3 bg-white border border-slate-100 rounded-2xl shadow-sm hover:shadow-md hover:border-amber-300 transition-all duration-300 flex items-center gap-3 group cursor-default">
              <div className="h-9 w-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center shrink-0 group-hover:scale-105 duration-200">
                <Zap className="h-4.5 w-4.5" />
              </div>
              <div className="space-y-0.5">
                <h4 className="text-xs font-black text-slate-800">Instant Compiles</h4>
                <p className="text-[10px] text-slate-400 font-bold leading-none">Client Optimized</p>
              </div>
            </div>

            <div className="p-3 bg-white border border-slate-100 rounded-2xl shadow-sm hover:shadow-md hover:border-purple-300 transition-all duration-300 flex items-center gap-3 group cursor-default">
              <div className="h-9 w-9 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center shrink-0 group-hover:scale-105 duration-200">
                <RefreshCw className="h-4.5 w-4.5 animate-spin-slow" />
              </div>
              <div className="space-y-0.5">
                <h4 className="text-xs font-black text-slate-800">Free Suite</h4>
                <p className="text-[10px] text-slate-400 font-bold leading-none">Google Ad Funded</p>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* AdSpace placement */}
      <div className="px-4 max-w-7xl mx-auto">
        <AdPlacement type="header" />
      </div>

      {/* Anchor identifier for tools view */}
      <div id="tools-anchor" />

      {/* 2. Modern Icon-based Directory Categories cards */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-6">
        <div className="space-y-1.5 text-center sm:text-left">
          <h3 className="text-xl font-display font-bold text-slate-900 tracking-tight flex items-center justify-center sm:justify-start gap-2">
            <Trophy className="h-5 w-5 text-indigo-500" /> Explore Structured Galleries
          </h3>
          <p className="text-xs text-slate-500 font-semibold">Choose a structural workflow gallery to narrow down active tools list.</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-7 gap-3.5">
          {/* General Trigger Card */}
          <button
            onClick={() => { window.location.hash = "#/"; }}
            className={`p-4 sm:p-5 rounded-2xl border text-left transition-all duration-300 flex flex-col justify-between cursor-pointer group h-[104px] transform hover:-translate-y-1 ${
              activeCategory === "all"
                ? "bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-100"
                : "bg-white border-slate-200 text-slate-705 hover:border-indigo-400 hover:shadow-md"
            }`}
          >
            <div className={`p-2 rounded-xl w-fit transition-all duration-300 ${
              activeCategory === "all" 
                ? "bg-white/10 text-white" 
                : "bg-indigo-50 text-indigo-600"
            } group-hover:scale-110 group-hover:rotate-3`}>
              <Compass className="h-4.5 w-4.5" />
            </div>
            <div className="space-y-0.5">
              <h4 className="text-xs font-black tracking-tight leading-none transition animate-fade-in">All Suites</h4>
              <p className={`text-[9px] font-bold leading-none ${activeCategory === "all" ? "text-indigo-100" : "text-slate-400"}`}>
                {toolsList.length} available
              </p>
            </div>
          </button>

          {CATEGORIES.map((cat) => {
            const isSelected = activeCategory === cat.id;
            const catCount = toolsList.filter(t => t.category === cat.id).length;
            return (
              <button
                key={cat.id}
                onClick={() => { window.location.hash = `#/category/${cat.id}`; }}
                className={`p-4 sm:p-5 rounded-2xl border text-left transition-all duration-300 flex flex-col justify-between cursor-pointer group h-[104px] transform hover:-translate-y-1 ${
                  isSelected
                    ? "bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-100"
                    : "bg-white border-slate-200 text-slate-705 hover:border-indigo-400 hover:shadow-md"
                }`}
              >
                <div className={`p-2 rounded-xl w-fit transition-all duration-300 ${
                  isSelected 
                    ? "bg-white/15 text-white" 
                    : `${cat.bg} ${cat.color}`
                } group-hover:scale-110`}>
                  <ToolIcon name={cat.icon} className="h-4.5 w-4.5" />
                </div>
                <div className="space-y-0.5">
                  <h4 className="text-xs font-black tracking-tight leading-none transition">{cat.name}</h4>
                  <p className={`text-[9px] font-bold leading-none ${isSelected ? "text-indigo-100" : "text-slate-400"}`}>
                    {catCount} features
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* 3. Sticky Smart Search Control Box */}
      <section ref={searchSectionRef} className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className={`p-4 bg-white border border-slate-200 rounded-2xl shadow-[0_8px_30px_rgb(0,0,0,0.02)] transition-all duration-300 ${
          isSearchSticky 
            ? "sticky top-16 z-40 bg-white border-b border-indigo-100 px-6 py-3.5 shadow-md" 
            : ""
        }`}>
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="relative w-full max-w-xl" ref={homeSearchRef}>
              <Search className="absolute top-3 left-4 h-4.5 w-4.5 text-gray-400" />
              <input
                type="text"
                value={homeSearch}
                onChange={(e) => setHomeSearch(e.target.value)}
                onFocus={() => setIsSearchFocused(true)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && homeSearch.trim()) {
                    addRecentSearch(homeSearch);
                    setIsSearchFocused(false);
                  }
                }}
                placeholder="Ex. 'compress pdf' or 'SIP loan'... Live query results update instantly"
                className="w-full pl-11 pr-12 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1.5 focus:ring-indigo-505 placeholder-slate-400 text-xs font-semibold text-slate-800 focus:bg-white transition"
              />
              {homeSearch && (
                <button 
                  onClick={() => {
                    setHomeSearch("");
                    setIsSearchFocused(true);
                  }}
                  className="absolute top-2.5 right-3 px-2 py-0.5 text-[10px] font-bold text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded"
                >
                  Clear
                </button>
              )}

              {/* Home search live suggestions portal */}
              {isSearchFocused && (
                <div className="absolute top-full left-0 w-full bg-white border border-slate-200 rounded-2xl shadow-xl mt-2 overflow-hidden z-50">
                  {homeSearch.trim() === "" ? (
                    <div className="p-4 space-y-4">
                      {recentSearches.length > 0 && (
                        <div className="space-y-2">
                          <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-wider text-slate-400">
                            <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> Recent Searches</span>
                            <button 
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                clearRecentSearches();
                              }}
                              className="text-[9px] text-red-500 hover:underline cursor-pointer"
                            >
                              Clear All
                            </button>
                          </div>
                          <div className="flex flex-wrap gap-1.5">
                            {recentSearches.map((term, i) => (
                              <div 
                                key={`recent-search-${i}`}
                                onClick={() => {
                                  setHomeSearch(term);
                                  addRecentSearch(term);
                                }}
                                className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-full text-xs font-bold text-slate-700 cursor-pointer transition select-none"
                              >
                                <span>{term}</span>
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    removeRecentSearch(term);
                                  }}
                                  className="text-slate-400 hover:text-slate-600 font-bold ml-1 text-xs"
                                >
                                  &times;
                                </button>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      <div className="space-y-2">
                        <div className="text-[10px] font-bold uppercase tracking-wider text-slate-405 flex items-center gap-1.5 select-none">
                          <Rocket className="h-3.5 w-3.5 text-indigo-500" /> Suggested Quick Access
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {[
                            { title: "PDF Compressor", slug: "pdf-compressor", desc: "Reduce file size", icon: "FileDown" },
                            { title: "GST Calculator", slug: "gst-calculator", desc: "Goods & services taxes", icon: "Calculator" },
                            { title: "SIP Calculator", slug: "sip-calculator", desc: "Compound wealth planning", icon: "Sliders" },
                            { title: "Password Generator", slug: "password-generator", desc: "Build secure credentials", icon: "Check" }
                          ].map((item) => (
                            <button
                              type="button"
                              key={`suggested-quick-${item.slug}`}
                              onClick={() => {
                                addRecentSearch(item.title);
                                navigateTo("tool", item.slug);
                                setIsSearchFocused(false);
                              }}
                              className="flex items-start gap-2.5 p-2 bg-slate-50 hover:bg-indigo-50/40 rounded-xl border border-slate-150 text-left transition duration-200 hover:border-indigo-300 w-full cursor-pointer group"
                            >
                              <div className="p-1.5 bg-white text-indigo-500 rounded-lg shadow-sm">
                                <ToolIcon name={item.icon} className="h-3.5 w-3.5" />
                              </div>
                              <div className="min-w-0">
                                <h4 className="text-xs font-bold text-slate-800 leading-tight truncate group-hover:text-indigo-650 transition">{item.title}</h4>
                                <p className="text-[9px] text-slate-400 leading-none truncate mt-0.5">{item.desc}</p>
                              </div>
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <div className="p-2 px-3 text-[10px] font-bold uppercase tracking-wider text-slate-400 bg-slate-50 border-b border-slate-100 flex justify-between select-none">
                        <span>Matching Utilities</span>
                        <span className="text-[9px] font-black text-indigo-600">{filteredTools.length} found</span>
                      </div>
                      <div className="divide-y divide-slate-100 max-h-60 overflow-y-auto">
                        {filteredTools.slice(0, 5).map((tool) => (
                           <div
                            key={`suggest-item-${tool.slug}`}
                            onClick={() => {
                              addRecentSearch(tool.title);
                              navigateTo("tool", tool.slug);
                              setIsSearchFocused(false);
                            }}
                            className="p-3 hover:bg-slate-50 transition flex items-start gap-3 cursor-pointer"
                          >
                            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg mt-0.5">
                              <ToolIcon name={tool.icon} className="h-3.5 w-3.5" />
                            </div>
                            <div className="space-y-0.5 min-w-0">
                              <h4 className="text-xs font-bold text-slate-800 truncate">{tool.title}</h4>
                              <p className="text-[10px] text-slate-400 truncate leading-tight">{tool.description}</p>
                            </div>
                          </div>
                        ))}
                        {filteredTools.length === 0 && (
                          <div className="p-4 text-center text-xs font-bold text-slate-400 select-none">No exact matches found.</div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            <div className="flex items-center gap-2.5 shrink-0 select-none">
              <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest hidden lg:block">Active Category:</span>
              <div className="flex flex-wrap gap-1 bg-slate-50 p-1 rounded-lg border border-slate-200">
                <button 
                  onClick={() => { window.location.hash = "#/"; }}
                  className={`px-3 py-1 text-[10px] font-bold rounded-md cursor-pointer transition ${activeCategory === "all" ? "bg-indigo-600 text-white shadow-sm" : "text-slate-500 hover:text-slate-800"}`}
                >
                  All
                </button>
                {CATEGORIES.map(c => (
                  <button 
                    key={c.id}
                    onClick={() => { window.location.hash = `#/category/${c.id}`; }}
                    className={`px-3 py-1 text-[10px] font-bold rounded-md cursor-pointer transition ${activeCategory === c.id ? "bg-indigo-600 text-white shadow-sm" : "text-slate-500 hover:text-slate-800"}`}
                  >
                    {c.name.split(" ")[0]}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Trending, Recently Added, and Most Used Tools (Tab Sections) */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div className="space-y-1">
            <h3 className="text-xl font-extrabold tracking-tight text-slate-900 flex items-center gap-2">
              <Flame className="h-5 w-5 text-amber-500 animate-pulse" /> Highly Requested Collections
            </h3>
            <p className="text-xs text-slate-500 font-semibold">Our most popular automated digital workflows updated this hour.</p>
          </div>

          {/* Tab Button Selector */}
          <div className="flex bg-slate-100 p-1 rounded-xl w-fit border border-slate-200 shrink-0">
            <button
              onClick={() => setActiveTab("trending")}
              className={`px-4 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                activeTab === "trending" 
                  ? "bg-white text-slate-800 shadow" 
                  : "text-slate-500 hover:text-slate-805"
              }`}
            >
              Trending Now
            </button>
            <button
              onClick={() => setActiveTab("recent")}
              className={`px-4 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                activeTab === "recent" 
                  ? "bg-white text-slate-800 shadow" 
                  : "text-slate-500 hover:text-slate-805"
              }`}
            >
              Recently Added
            </button>
            <button
              onClick={() => setActiveTab("mostUsed")}
              className={`px-4 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                activeTab === "mostUsed" 
                  ? "bg-white text-slate-800 shadow" 
                  : "text-slate-500 hover:text-slate-805"
              }`}
            >
              Most Used Tools
            </button>
          </div>
        </div>

        {/* Tab content rendering */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {activeTabTools.map((tool) => (
            <div
              key={`tab-${tool.slug}`}
              onClick={() => navigateTo("tool", tool.slug)}
              className="bg-white relative hover:-translate-y-1 border border-slate-200 p-5 flex flex-col justify-between hover:border-indigo-400 hover:shadow-lg transition-all duration-300 group cursor-pointer rounded-2xl shadow-sm"
            >
              <div className="space-y-3.5">
                <div className="flex justify-between items-start">
                  <div className="p-2 bg-indigo-50 text-indigo-650 rounded-lg group-hover:scale-110 transition-transform duration-300">
                    <ToolIcon name={tool.icon} className="h-4.5 w-4.5" />
                  </div>
                  <div className="flex gap-1 items-center">
                    {tool.trending && (
                      <span className="text-[8px] font-black uppercase text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-100 leading-none">
                        Popular
                      </span>
                    )}
                    {tool.recentlyAdded && (
                      <span className="text-[8px] font-black uppercase text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-100 leading-none">
                        New
                      </span>
                    )}
                    <span className="text-[8px] font-black uppercase text-sky-700 bg-sky-50 px-1.5 py-0.5 rounded border border-sky-100 leading-none">
                      Secure
                    </span>
                  </div>
                </div>
                <div>
                  <h4 className="font-extrabold text-slate-800 text-xs sm:text-sm tracking-tight group-hover:text-indigo-600 transition leading-snug">
                    {tool.title}
                  </h4>
                  <p className="text-slate-450 text-[11px] line-clamp-2 leading-relaxed mt-1">
                    {tool.description}
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 mt-3 border-t border-slate-100">
                <span className="text-[9px] font-bold text-slate-500 group-hover:text-indigo-650 transition flex items-center gap-1">
                  Launch Suite &rarr;
                </span>
                <span className="text-[9px] text-emerald-600 font-bold bg-emerald-50 px-1.5 py-0.5 rounded">Safe Sandbox</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 5. Complete Tools Directory Grid */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div className="space-y-1">
            <h3 className="text-xl font-extrabold tracking-tight text-slate-900 flex items-center gap-2">
              <Sliders className="h-5 w-5 text-indigo-500" /> Utility Pipeline Core ({filteredTools.length})
            </h3>
            <p className="text-xs text-slate-500 font-semibold">List of all active utilities processing directly on the client.</p>
          </div>
          
          {/* Quick Clear Filter trigger */}
          {(activeCategory !== "all" || homeSearch) && (
            <button 
              onClick={() => { setActiveCategory("all"); setHomeSearch(""); }}
              className="text-xs font-bold text-indigo-600 hover:underline cursor-pointer flex items-center gap-1"
            >
              Clear active filter settings <Check className="h-3.5 w-3.5" />
            </button>
          )}
        </div>

        {/* Big Tools Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {isFiltering ? (
            Array.from({ length: filteredTools.length > 0 ? Math.min(filteredTools.length, 12) : 8 }).map((_, idx) => (
              <div 
                key={`skele-card-${idx}`}
                className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 animate-pulse relative overflow-hidden h-44 flex flex-col justify-between shadow-sm"
              >
                <div className="space-y-4">
                  <div className="flex justify-between items-start">
                    <div className="h-10 w-10 bg-slate-100 rounded-xl" />
                    <div className="h-4 w-12 bg-slate-50 rounded-full" />
                  </div>
                  <div className="space-y-2">
                    <div className="h-4 w-2/3 bg-slate-100 rounded" />
                    <div className="h-3 w-5/6 bg-slate-50 rounded" />
                  </div>
                </div>
                <div className="flex justify-between items-center pt-3 border-t border-slate-100">
                  <div className="h-2 w-16 bg-slate-50 rounded" />
                  <div className="h-3.5 w-20 bg-slate-50 rounded" />
                </div>
              </div>
            ))
          ) : (
            filteredTools.map((tool) => (
              <div
                key={`all-suites-${tool.slug}`}
                onClick={() => navigateTo("tool", tool.slug)}
                className="bg-white rounded-2xl border border-slate-200 p-5 flex flex-col justify-between hover:border-indigo-400 hover:shadow-lg hover:-translate-y-1 transition-all duration-300 group cursor-pointer relative overflow-hidden shadow-sm"
              >
                <div className="space-y-4">
                  <div className="flex justify-between items-start">
                    {/* Color Bubbles Mapper */}
                    <div className="p-2.5 bg-gradient-to-tr from-slate-50 to-indigo-50/50 text-slate-800 rounded-xl border border-slate-100 group-hover:bg-indigo-600 group-hover:text-white group-hover:scale-105 transition-all duration-300">
                      <ToolIcon name={tool.icon} className="h-5 w-5" />
                    </div>
                    
                    <div className="flex gap-1 items-center shrink-0">
                      {tool.trending && (
                        <span className="text-[8px] font-black uppercase text-amber-650 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/40 py-0.5 px-2 rounded border border-amber-250/50 dark:border-amber-900/60 flex items-center gap-0.5 shadow-sm">
                          <Flame className="h-2.5 w-2.5 text-amber-500 animate-pulse" /> Popular
                        </span>
                      )}
                      {tool.recentlyAdded && (
                        <span className="text-[8px] font-black uppercase text-emerald-650 dark:text-emerald-300 bg-emerald-55 bg-opacity-10 dark:bg-emerald-950/40 py-0.5 px-2 rounded border border-emerald-250/50 dark:border-emerald-900/60 flex items-center gap-0.5 shadow-sm">
                          <Sparkles className="h-2.5 w-2.5 text-emerald-550 dark:text-emerald-400" /> New
                        </span>
                      )}
                      {!tool.trending && !tool.recentlyAdded && (
                        <span className="text-[8px] font-black uppercase text-sky-600 dark:text-sky-305 bg-sky-55 bg-opacity-10 dark:bg-sky-950/40 py-0.5 px-2 rounded border border-sky-150 dark:border-sky-900/40 flex items-center gap-0.5">
                          <ShieldCheck className="h-2.5 w-2.5 text-sky-500" /> Secure
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <h4 className="font-extrabold text-slate-900 dark:text-slate-100 text-xs sm:text-sm tracking-tight group-hover:text-indigo-650 dark:group-hover:text-indigo-400 transition leading-snug">
                      {tool.title}
                    </h4>
                    <p className="text-slate-450 dark:text-slate-400 text-xs leading-relaxed line-clamp-2">
                      {tool.description}
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 mt-4 border-t border-slate-50 dark:border-slate-900">
                  <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition flex items-center gap-1">
                    Launch In-Browser <ArrowUpRight className="h-3 w-3" />
                  </span>
                  <span className="text-[9px] font-semibold text-slate-350 dark:text-slate-500 uppercase tracking-widest">Calculates Local</span>
                </div>
              </div>
            ))
          )}

          {!isFiltering && filteredTools.length === 0 && (
            <div className="col-span-full text-center py-16 bg-slate-50 border border-dashed border-slate-200 rounded-3xl space-y-3">
              <p className="text-slate-500 text-xs font-bold">No dynamic pipelines matched your active input limits.</p>
              <button 
                onClick={() => { setHomeSearch(""); setActiveCategory("all"); }}
                className="text-xs bg-indigo-600 text-white font-bold py-2 px-4 rounded-xl cursor-pointer"
              >
                Reset Search Filters
              </button>
            </div>
          )}
        </div>
      </section>

      {/* AdSpace placement inside middle frame */}
      <div className="px-4 max-w-7xl mx-auto">
        <AdPlacement type="content" />
      </div>

      {/* 6. Editorial featured Blogs section on homepage */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-6">
        <div className="flex items-end justify-between border-b border-slate-100 pb-4">
          <div className="space-y-1">
            <h3 className="text-xl font-extrabold tracking-tight text-slate-900 flex items-center gap-2">
              <BookOpen className="h-5 w-5 text-indigo-500" /> Editorial Guideline Column
            </h3>
            <p className="text-xs text-slate-500 font-semibold">Explore deep organic SEO optimization rules, meta tag standard schemas, and Core Web Vital audits.</p>
          </div>
          <button 
            onClick={() => navigateTo("blog")}
            className="text-xs font-extrabold text-indigo-600 hover:underline cursor-pointer shrink-0"
          >
            All Articles &rarr;
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {blogsList.slice(0, 3).map((post) => (
            <article 
              key={`home-blog-${post.slug}`}
              onClick={() => navigateTo("blog", post.slug)}
              className="bg-white border border-slate-200 rounded-2xl p-6 hover:shadow-lg transition cursor-pointer flex flex-col justify-between group shadow-sm"
            >
              <div className="space-y-3">
                <div className="flex justify-between items-center text-[10px] text-slate-500 font-extrabold">
                  <span className="uppercase tracking-wider px-2 py-0.5 bg-slate-100 rounded text-slate-600">{post.category}</span>
                  <span className="flex items-center gap-1"><Calendar className="h-3 w-3" /> {post.date}</span>
                </div>
                <h4 className="font-bold text-slate-800 text-sm leading-snug group-hover:text-indigo-650 transition">
                  {post.title}
                </h4>
                <p className="text-slate-500 text-xs line-clamp-3 leading-relaxed">
                  {post.excerpt}
                </p>
              </div>
              <div className="flex items-center justify-between text-[10px] text-slate-400 pt-4 mt-6 border-t border-slate-105">
                <span className="flex items-center gap-1 font-bold text-slate-500 group-hover:text-indigo-650">
                  Read Editorial <ArrowUpRight className="h-3.5 w-3.5" />
                </span>
                <span className="font-extrabold text-slate-500">{post.readTime}</span>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* 7. Comprehensive FAQ Accordion layout */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto space-y-6">
        <h3 className="text-lg font-black text-slate-900 tracking-tight text-center">Frequently Answered Queries</h3>
        <div className="divide-y divide-slate-100 border border-slate-200 rounded-2xl bg-white overflow-hidden text-xs shadow-sm">
          <div className="p-5 sm:p-6 bg-transparent">
            <h4 className="font-extrabold text-slate-800 text-xs sm:text-sm mb-1.5 flex items-center gap-1.5">
              <Sparkle className="h-3.5 w-3.5 text-amber-500 animate-pulse" />
              Is my private data uploaded to the server for processing?
            </h4>
            <p className="text-slate-500 leading-relaxed font-semibold">
              Absolutely not. Our enterprise-grade suite architecture operates purely local computing paradigms inside your web browser via advanced WebAssembly, HTML5 APIs, and React structures. Your personal PDFs, pictures, loans, or text files stay inside your local browser frame memory.
            </p>
          </div>
          <div className="p-5 sm:p-6 bg-transparent">
            <h4 className="font-extrabold text-slate-800 text-xs sm:text-sm mb-1.5 flex items-center gap-1.5">
              <Sparkle className="h-3.5 w-3.5 text-indigo-500" />
              How is MyToolsHub kept free of charge?
            </h4>
            <p className="text-slate-500 leading-relaxed font-semibold">
              Our tools are entirely funded by high-yield sponsor blocks running standard Google AdSense slots. By keeping ad units native with set container ratios, we prevent annoying Layout Shifts (CLS), securing a perfect Grade-A user experience according to Lighthouse Core Web Vitals.
            </p>
          </div>
          <div className="p-5 sm:p-6 bg-transparent">
            <h4 className="font-extrabold text-slate-800 text-xs sm:text-sm mb-1.5 flex items-center gap-1.5">
              <Sparkle className="h-3.5 w-3.5 text-purple-500" />
              Are these tools compatible with other devices or mobile platforms?
            </h4>
            <p className="text-slate-500 leading-relaxed font-semibold">
              Yes, our system utilizes a fully responsive, mobile-first design grid layout. It includes tailored touch interaction targets (44px+) and bottom floating quick-access indicators, proving as performant on a tablet, Android, or iPhone as on a desktop.
            </p>
          </div>
        </div>
      </section>

    </div>
  );
}
