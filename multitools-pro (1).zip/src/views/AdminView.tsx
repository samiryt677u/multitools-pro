import React, { useState, useEffect } from "react";
import { 
  BarChart, Layers, BookOpen, SearchCode, Database, RefreshCw, Plus, 
  Trash2, Edit, Save, ToggleLeft, ToggleRight, Check, Activity, 
  Terminal, ShieldCheck, Flame, Sparkles, Sliders, Globe, Eye, Code2
} from "lucide-react";
import { 
  getStoredBlogs, saveStoredBlogs, 
  getStoredTools, saveStoredTools, 
  getStoredSeoRules, saveStoredSeoRules,
  SEORule 
} from "../utils/storage";
import { BlogPost } from "../data/blogs";
import { ToolData } from "../data/tools";
import AdPlacement from "../components/AdPlacement";

export default function AdminView() {
  const [activeTab, setActiveTab] = useState<"diagnostics" | "tools" | "blogs" | "seo">("diagnostics");
  const [blogs, setBlogs] = useState<BlogPost[]>([]);
  const [tools, setTools] = useState<ToolData[]>([]);
  const [seoRules, setSeoRules] = useState<SEORule[]>([]);

  // Local state for adding/editing blogs
  const [editingBlogSlug, setEditingBlogSlug] = useState<string | null>(null);
  const [blogForm, setBlogForm] = useState<Partial<BlogPost>>({
    title: "",
    excerpt: "",
    content: "",
    category: "Productivity",
    readTime: "5 min read",
    author: "Administrator"
  });

  // Local state for adding SEO keyword rule
  const [newSeoRule, setNewSeoRule] = useState({
    keyword: "",
    densityTarget: 2.0,
    categoryTarget: "pdf"
  });

  // Live SEO checker text input
  const [auditText, setAuditText] = useState("");
  const [auditKeyword, setAuditKeyword] = useState("pdf compressor");
  const [densityResult, setDensityResult] = useState<number | null>(null);

  useEffect(() => {
    setBlogs(getStoredBlogs());
    setTools(getStoredTools());
    setSeoRules(getStoredSeoRules());
  }, []);

  // Sync state functions
  const saveBlogs = (updated: BlogPost[]) => {
    setBlogs(updated);
    saveStoredBlogs(updated);
  };

  const saveTools = (updated: ToolData[]) => {
    setTools(updated);
    saveStoredTools(updated);
  };

  const saveSeoRules = (updated: SEORule[]) => {
    setSeoRules(updated);
    saveStoredSeoRules(updated);
  };

  // SEO Density Checker
  useEffect(() => {
    if (!auditText || !auditKeyword) {
      setDensityResult(null);
      return;
    }
    const words = auditText.toLowerCase().split(/\s+/).filter(Boolean);
    if (words.length === 0) {
      setDensityResult(0);
      return;
    }
    const matches = (auditText.toLowerCase().match(new RegExp(auditKeyword.toLowerCase(), "g")) || []).length;
    // rough word count matching keyword phrase length
    const phraseWordCount = auditKeyword.split(/\s+/).length;
    const computed = (matches * phraseWordCount / words.length) * 100;
    setDensityResult(parseFloat(computed.toFixed(2)));
  }, [auditText, auditKeyword]);

  // Blogs commands
  const handleCreateOrUpdateBlog = (e: React.FormEvent) => {
    e.preventDefault();
    if (!blogForm.title || !blogForm.content) return;

    const slug = blogForm.slug || blogForm.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
    
    const preparedBlog: BlogPost = {
      title: blogForm.title,
      slug: slug,
      category: blogForm.category || "Productivity",
      excerpt: blogForm.excerpt || blogForm.content.slice(0, 100) + "...",
      content: blogForm.content,
      readTime: blogForm.readTime || "4 min read",
      author: blogForm.author || "Administrator",
      date: new Date().toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" }),
      featured: blogForm.featured || false
    };

    if (editingBlogSlug) {
      const index = blogs.findIndex(b => b.slug === editingBlogSlug);
      if (index !== -1) {
        const updated = [...blogs];
        updated[index] = preparedBlog;
        saveBlogs(updated);
      }
    } else {
      // Check duplicate slug
      if (blogs.some(b => b.slug === slug)) {
        alert("An article with this identical slug/title already exists. Please modify the heading.");
        return;
      }
      saveBlogs([preparedBlog, ...blogs]);
    }

    // Reset Form
    setEditingBlogSlug(null);
    setBlogForm({
      title: "",
      excerpt: "",
      content: "",
      category: "Productivity",
      readTime: "5 min read",
      author: "Administrator"
    });
  };

  const handleEditBlogClick = (b: BlogPost) => {
    setEditingBlogSlug(b.slug);
    setBlogForm(b);
  };

  const handleDeleteBlog = (slug: string) => {
    if (confirm("Are you absolutely sure you want to delete this editorial article?")) {
      const updated = blogs.filter(b => b.slug !== slug);
      saveBlogs(updated);
    }
  };

  const toggleToolTrendStatus = (slug: string, field: "trending" | "recentlyAdded" | "featured") => {
    const updated = tools.map(t => {
      if (t.slug === slug) {
        return {
          ...t,
          [field]: !t[field]
        };
      }
      return t;
    });
    saveTools(updated);
  };

  const handleAddSeoRule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSeoRule.keyword) return;
    const rule: SEORule = {
      id: Math.random().toString(36).substr(2, 9),
      keyword: newSeoRule.keyword,
      densityTarget: Number(newSeoRule.densityTarget),
      status: "active",
      categoryTarget: newSeoRule.categoryTarget
    };
    saveSeoRules([...seoRules, rule]);
    setNewSeoRule({ keyword: "", densityTarget: 2.0, categoryTarget: "pdf" });
  };

  const toggleSeoRuleStatus = (id: string) => {
    const updated = seoRules.map(r => {
      if (r.id === id) {
        return { ...r, status: r.status === "active" ? "deprecated" as const : "active" as const };
      }
      return r;
    });
    saveSeoRules(updated);
  };

  const handleDeleteSeoRule = (id: string) => {
    const updated = seoRules.filter(r => r.id !== id);
    saveSeoRules(updated);
  };

  // Mock server statistics calculations
  const [liveStats, setLiveStats] = useState({
    memory: "41.6 MB",
    cpu: "2.4%",
    activeUsers: 8,
    sitemapHealth: "Healthy (200 OK)",
    nodeEnv: "production"
  });

  const refreshLiveStats = () => {
    const randomCpu = (Math.random() * 4 + 1).toFixed(1) + "%";
    const randomMemory = (35 + Math.random() * 15).toFixed(1) + " MB";
    const randomUsers = Math.floor(Math.random() * 10 + 5);
    setLiveStats({
      ...liveStats,
      cpu: randomCpu,
      memory: randomMemory,
      activeUsers: randomUsers
    });
  };

  return (
    <div className="py-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8 font-sans selection:bg-indigo-600 select-text">
      
      {/* 1. Header Banner */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 relative overflow-hidden shadow-xl border border-slate-800">
        <div className="absolute top-0 right-0 h-44 w-44 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="space-y-1.5 animate-fade-in">
            <span className="text-[9px] font-black uppercase text-indigo-400 tracking-wider bg-slate-950/80 px-2 py-0.5 rounded border border-indigo-900/60">
              Admin Control Center
            </span>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight flex items-center gap-2">
              <Database className="h-7 w-7 text-indigo-400" /> Platform Administration
            </h2>
            <p className="text-xs text-slate-400 font-semibold max-w-xl">
              Local sandbox simulation environment logic. Update trending tools, compile custom blog articles, audit meta keywords density rules, and track virtual runtime metrics.
            </p>
          </div>
          <button 
            onClick={refreshLiveStats}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-950 hover:bg-slate-920 border border-slate-800 rounded-xl text-xs font-bold text-slate-300 transition"
          >
            <RefreshCw className="h-3.5 w-3.5" /> Force Refresh Stats
          </button>
        </div>
      </div>

      {/* 2. Admin Hub Tabs Row */}
      <div className="flex border-b border-slate-150 dark:border-slate-800 overflow-x-auto gap-2 py-1 scrollbar-none select-none">
        <button
          onClick={() => setActiveTab("diagnostics")}
          className={`px-4 py-2 text-xs font-extrabold uppercase tracking-wider rounded-xl transition flex items-center gap-1.5 cursor-pointer shrink-0 ${activeTab === "diagnostics" ? "bg-slate-900 text-white dark:bg-indigo-600" : "text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-900"}`}
        >
          <Activity className="h-4 w-4" /> Systems & Diagnostics
        </button>
        <button
          onClick={() => setActiveTab("tools")}
          className={`px-4 py-2 text-xs font-extrabold uppercase tracking-wider rounded-xl transition flex items-center gap-1.5 cursor-pointer shrink-0 ${activeTab === "tools" ? "bg-slate-900 text-white dark:bg-indigo-600" : "text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-900"}`}
        >
          <Sliders className="h-4 w-4" /> Tool Matrix ({tools.length})
        </button>
        <button
          onClick={() => setActiveTab("blogs")}
          className={`px-4 py-2 text-xs font-extrabold uppercase tracking-wider rounded-xl transition flex items-center gap-1.5 cursor-pointer shrink-0 ${activeTab === "blogs" ? "bg-slate-900 text-white dark:bg-indigo-600" : "text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-900"}`}
        >
          <BookOpen className="h-4 w-4" /> Article Publisher ({blogs.length})
        </button>
        <button
          onClick={() => setActiveTab("seo")}
          className={`px-4 py-2 text-xs font-extrabold uppercase tracking-wider rounded-xl transition flex items-center gap-1.5 cursor-pointer shrink-0 ${activeTab === "seo" ? "bg-slate-900 text-white dark:bg-indigo-600" : "text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-900"}`}
        >
          <SearchCode className="h-4 w-4" /> Keywords & SEO Auditor
        </button>
      </div>

      <AdPlacement type="header" />

      {/* 3. Tab Canvas Contents */}
      <div className="space-y-6">

        {/* TAB 1: Diagnostics */}
        {activeTab === "diagnostics" && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* Server Performance Counters */}
            <div className="bg-white dark:bg-slate-950 border border-slate-150/80 dark:border-slate-800 rounded-2xl p-6 sm:p-7 space-y-4 shadow-sm md:col-span-2">
              <h3 className="text-sm font-black text-slate-950 dark:text-slate-100 flex items-center gap-1.5">
                <BarChart className="h-4.5 w-4.5 text-indigo-500" /> Sandboxed Server Diagnostics
              </h3>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="border border-slate-100 dark:border-slate-900 bg-slate-50/50 dark:bg-slate-900/10 p-4 rounded-xl space-y-1">
                  <span className="text-[10px] text-slate-400 uppercase font-black">Memory Allocation</span>
                  <p className="text-xl font-black text-slate-800 dark:text-slate-100">{liveStats.memory}</p>
                  <p className="text-[9px] text-[#22c55e] font-semibold">Active Node heap allocation</p>
                </div>
                <div className="border border-slate-100 dark:border-slate-900 bg-slate-50/50 dark:bg-slate-900/10 p-4 rounded-xl space-y-1">
                  <span className="text-[10px] text-slate-400 uppercase font-black">CPU Processing Weight</span>
                  <p className="text-xl font-black text-slate-800 dark:text-slate-100">{liveStats.cpu}</p>
                  <p className="text-[9px] text-[#22c55e] font-semibold">Thread loop load</p>
                </div>
                <div className="border border-slate-100 dark:border-slate-900 bg-slate-50/50 dark:bg-slate-900/10 p-4 rounded-xl space-y-1">
                  <span className="text-[10px] text-slate-400 uppercase font-black">Simulated Concurrent Requests</span>
                  <p className="text-xl font-black text-slate-800 dark:text-slate-100">{liveStats.activeUsers} active</p>
                  <p className="text-[9px] text-[indigo-500] font-semibold">Client browsers calculating</p>
                </div>
                <div className="border border-slate-100 dark:border-slate-900 bg-slate-50/50 dark:bg-slate-900/10 p-4 rounded-xl space-y-1">
                  <span className="text-[10px] text-slate-400 uppercase font-black">Google Sitemap Auditing</span>
                  <p className="text-xl font-black text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                    <Globe className="h-4.5 w-4.5 text-emerald-500" /> 200 OK
                  </p>
                  <p className="text-[9px] text-emerald-500 font-semibold">Sitemaps indexing tags checked</p>
                </div>
              </div>

              {/* System status lines */}
              <div className="border-t border-slate-100 dark:border-slate-900 pt-5 space-y-3 font-semibold text-xs text-slate-550 dark:text-slate-400">
                <div className="flex justify-between">
                  <span>Development Port Node</span>
                  <span className="font-bold text-slate-900 dark:text-slate-200">PORT: 3000</span>
                </div>
                <div className="flex justify-between">
                  <span>HMR (Hot Module Replacement) Status</span>
                  <span className="text-slate-500 dark:text-slate-400">DISABLED_BY_PLATFORM (true)</span>
                </div>
                <div className="flex justify-between">
                  <span>Runtime Environment State</span>
                  <span className="font-mono text-[10px] bg-indigo-50 dark:bg-indigo-950/20 text-indigo-600 dark:text-indigo-400 px-2 rounded font-bold">production container</span>
                </div>
              </div>
            </div>

            {/* Crawling Terminal Simulator */}
            <div className="bg-slate-950 text-slate-200 border border-slate-800 rounded-2xl p-6 space-y-4 shadow-xl font-mono flex flex-col justify-between">
              <div className="space-y-3">
                <div className="flex items-center gap-1.5 border-b border-slate-900 pb-2.5">
                  <Terminal className="h-4 w-4 text-emerald-400" />
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none">Crawler Bot Simulator</span>
                </div>
                <div className="text-[10px] space-y-2 leading-relaxed">
                  <p className="text-slate-500"># Initializing crawler run...</p>
                  <p className="text-slate-400">User-Agent: Googlebot/2.1 (+http://www.google.com/bot.html)</p>
                  <p className="text-indigo-400">&gt; Loading canonical /robots.txt...</p>
                  <p className="text-emerald-400"># Sitemap found: https://mytoolshub.com/sitemap.xml (Active)</p>
                  <p className="text-slate-400">&gt; Auditing 6 Categories & 50+ WebApp schema structures...</p>
                  <p className="text-emerald-500 font-bold"># STATUS: 100% Crawlable. SEO markups healthy.</p>
                </div>
              </div>
              <div className="pt-4 border-t border-slate-900 text-center">
                <span className="text-[9px] text-indigo-400 font-bold uppercase tracking-wider bg-indigo-950/60 py-1 px-3.5 rounded border border-indigo-900/40">
                  Core Web Vitals Pass (99+)
                </span>
              </div>
            </div>

          </div>
        )}

        {/* TAB 2: Tool Matrix */}
        {activeTab === "tools" && (
          <div className="bg-white dark:bg-slate-950 border border-slate-150/80 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden">
            <div className="p-5 sm:p-6 bg-slate-50/50 dark:bg-slate-900/10 border-b border-slate-150/80 dark:border-slate-800 space-y-1">
              <h3 className="text-xs font-black uppercase text-slate-400 tracking-wider">Suite Tools Controls</h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-450 font-bold">
                Configure featured rankings, highlight newly added items, and test live hover status tags immediately.
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-100 dark:border-slate-900 text-slate-400 uppercase tracking-wider font-extrabold bg-slate-50/50 dark:bg-slate-900/10">
                    <th className="p-4">Utility Title & Category</th>
                    <th className="p-4 text-center">Featured Tab</th>
                    <th className="p-4 text-center">Trending (Popular)</th>
                    <th className="p-4 text-center">Recently Added (New)</th>
                    <th className="p-4 text-center">Compliance</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-900 font-medium">
                  {tools.map((t) => (
                    <tr key={t.slug} className="hover:bg-slate-50/30 dark:hover:bg-slate-920 transition">
                      <td className="p-4">
                        <div className="flex items-center gap-2.5">
                          <div className="p-1 px-2 border border-slate-100 dark:border-slate-800 rounded bg-slate-50 dark:bg-slate-900">
                            <span className="font-mono text-[9px] uppercase tracking-wider text-slate-500">{t.category}</span>
                          </div>
                          <div>
                            <span className="font-bold text-slate-800 dark:text-slate-100">{t.title}</span>
                          </div>
                        </div>
                      </td>
                      
                      <td className="p-4 text-center">
                        <button 
                          onClick={() => toggleToolTrendStatus(t.slug, "featured")}
                          className="mx-auto block text-slate-500 hover:text-indigo-600 transition cursor-pointer"
                        >
                          {t.featured ? (
                            <ToggleRight className="h-6 w-6 text-indigo-500 mx-auto" />
                          ) : (
                            <ToggleLeft className="h-6 w-6 text-slate-400 dark:text-slate-600 mx-auto" />
                          )}
                        </button>
                      </td>

                      <td className="p-4 text-center">
                        <button 
                          onClick={() => toggleToolTrendStatus(t.slug, "trending")}
                          className="mx-auto block text-slate-500 hover:text-indigo-600 transition cursor-pointer"
                        >
                          {t.trending ? (
                            <span className="text-[10px] font-bold text-amber-600 bg-amber-50 dark:bg-amber-950/20 px-2 py-0.5 rounded border border-amber-100 flex items-center justify-center gap-0.5 w-24 mx-auto">
                              <Flame className="h-3 w-3 text-amber-500 animate-pulse" /> Popular
                            </span>
                          ) : (
                            <span className="text-[10px] font-semibold text-slate-400 bg-slate-50 dark:bg-slate-900 px-2 py-0.5 rounded border border-slate-100 flex items-center justify-center w-24 mx-auto">
                              Normal
                            </span>
                          )}
                        </button>
                      </td>

                      <td className="p-4 text-center">
                        <button 
                          onClick={() => toggleToolTrendStatus(t.slug, "recentlyAdded")}
                          className="mx-auto block text-slate-500 hover:text-indigo-600 transition cursor-pointer"
                        >
                          {t.recentlyAdded ? (
                            <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/20 px-2 py-0.5 rounded border border-emerald-100 flex items-center justify-center gap-0.5 w-24 mx-auto">
                              <Sparkles className="h-3 w-3 text-emerald-500" /> New
                            </span>
                          ) : (
                            <span className="text-[10px] font-semibold text-slate-400 bg-slate-50 dark:bg-slate-900 px-2 py-0.5 rounded border border-slate-100 flex items-center justify-center w-24 mx-auto">
                              Standard
                            </span>
                          )}
                        </button>
                      </td>

                      <td className="p-4 text-center">
                        <span className="text-[10px] font-bold text-sky-600 bg-sky-50 dark:bg-sky-950/20 px-2.5 py-1 rounded inline-block">
                          Secure (Local)
                        </span>
                      </td>

                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 3: Article Publisher */}
        {activeTab === "blogs" && (
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
            
            {/* Editor Console Form - Spans 3 columns on lg */}
            <div className="bg-white dark:bg-slate-950 border border-slate-150/80 dark:border-slate-800 rounded-2xl p-6 space-y-4 shadow-sm lg:col-span-3">
              <div className="border-b border-slate-100 dark:border-slate-900 pb-3">
                <h3 className="text-sm font-black text-slate-950 dark:text-slate-150">
                  {editingBlogSlug ? "Modify Guideline Post" : "Compile New SEO Editorial Post"}
                </h3>
                <p className="text-xs text-slate-400 font-semibold">Publish rich-text sitemap-compatible tutorials inside your client database.</p>
              </div>

              <form onSubmit={handleCreateOrUpdateBlog} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Article Head Title</label>
                    <input
                      type="text" required
                      value={blogForm.title}
                      onChange={(e) => setBlogForm({ ...blogForm, title: e.target.value })}
                      className="w-full p-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-1 focus:ring-slate-900 dark:focus:ring-indigo-500 text-slate-800 dark:text-slate-100 text-xs font-semibold"
                      placeholder="E.g., How to Compress PDF File Sizes Perfectly"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Category Bracket</label>
                    <select
                      value={blogForm.category}
                      onChange={(e) => setBlogForm({ ...blogForm, category: e.target.value })}
                      className="w-full p-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-1 focus:ring-slate-900 dark:focus:ring-indigo-500 text-slate-800 dark:text-slate-100 text-xs font-semibold"
                    >
                      <option>Productivity</option>
                      <option>SEO & Web</option>
                      <option>Tech Guide</option>
                      <option>Local Security</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Author Name</label>
                    <input
                      type="text"
                      value={blogForm.author}
                      onChange={(e) => setBlogForm({ ...blogForm, author: e.target.value })}
                      className="w-full p-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-1 text-slate-800 dark:text-slate-100 text-xs font-semibold"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Read Time Estimate</label>
                    <input
                      type="text"
                      value={blogForm.readTime}
                      onChange={(e) => setBlogForm({ ...blogForm, readTime: e.target.value })}
                      className="w-full p-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-1 text-slate-800 dark:text-slate-100 text-xs font-semibold"
                      placeholder="e.g., 5 min read"
                    />
                  </div>
                  <div className="flex items-center gap-2 pt-5">
                    <input
                      type="checkbox"
                      id="blog-feat-chk"
                      checked={blogForm.featured || false}
                      onChange={(e) => setBlogForm({ ...blogForm, featured: e.target.checked })}
                      className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <label htmlFor="blog-feat-chk" className="text-xs font-bold text-slate-700 dark:text-slate-300">
                      Feature on Homepage
                    </label>
                  </div>
                </div>

                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Brief Excerpt Text (SEO description card)</label>
                  <input
                    type="text" required
                    value={blogForm.excerpt}
                    onChange={(e) => setBlogForm({ ...blogForm, excerpt: e.target.value })}
                    className="w-full p-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-1 text-slate-800 dark:text-slate-100 text-xs font-semibold"
                    placeholder="Short description summary..."
                  />
                </div>

                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Editorial Content Body</label>
                  <textarea
                    required rows={8}
                    value={blogForm.content}
                    onChange={(e) => setBlogForm({ ...blogForm, content: e.target.value })}
                    className="w-full p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-1 text-slate-800 dark:text-slate-100 text-xs font-mono"
                    placeholder="Provide detailed texts... Use '### Heading' for title segments inside content body."
                  />
                </div>

                <div className="flex justify-between items-center pt-2">
                  {editingBlogSlug && (
                    <button
                      type="button"
                      onClick={() => {
                        setEditingBlogSlug(null);
                        setBlogForm({
                          title: "",
                          excerpt: "",
                          content: "",
                          category: "Productivity",
                          readTime: "5 min read",
                          author: "Administrator"
                        });
                      }}
                      className="px-4 py-2 border border-slate-200 dark:border-slate-800 rounded-xl text-xs font-bold text-slate-500 hover:text-slate-800 dark:hover:text-white"
                    >
                      Cancel Editing
                    </button>
                  )}
                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-slate-900 hover:bg-slate-820 dark:bg-indigo-650 dark:hover:bg-indigo-505 text-white rounded-xl text-xs font-bold shadow transition flex items-center gap-1.5 ml-auto cursor-pointer"
                  >
                    <Save className="h-4 w-4" /> 
                    <span>{editingBlogSlug ? "Update Post Settings" : "Deploy Editorial Live"}</span>
                  </button>
                </div>
              </form>
            </div>

            {/* List of Published Articles - Spans 2 columns on lg */}
            <div className="bg-white dark:bg-slate-950 border border-slate-150/80 dark:border-slate-800 rounded-2xl p-5 space-y-4 shadow-sm lg:col-span-2 flex flex-col justify-between">
              <div>
                <h3 className="text-sm font-black text-slate-950 dark:text-slate-150 border-b border-slate-50 dark:border-slate-900 pb-2.5">
                  Live Articles Directory
                </h3>
                
                <div className="space-y-3.5 pt-3 max-h-[460px] overflow-y-auto pr-1">
                  {blogs.map((b) => (
                    <div 
                      key={b.slug}
                      className="p-3 border border-slate-100 dark:border-slate-900 rounded-xl hover:border-slate-200 dark:hover:border-slate-800 transition flex justify-between items-start gap-4 bg-slate-50/20 dark:bg-slate-950"
                    >
                      <div className="space-y-1 min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-[8px] font-black uppercase text-[#4f46e5] dark:text-[#818cf8] tracking-widest">{b.category}</span>
                          {b.featured && (
                            <span className="text-[7px] font-black bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600 px-1 py-0.2 rounded border border-emerald-100">Featured</span>
                          )}
                        </div>
                        <h4 className="font-extrabold text-slate-800 dark:text-slate-200 text-xs leading-snug truncate">{b.title}</h4>
                        <p className="text-[10px] text-slate-450 dark:text-slate-400 font-semibold">{b.date} · {b.readTime}</p>
                      </div>
                      
                      {/* Action buttons */}
                      <div className="flex gap-1.5 shrink-0 select-none">
                        <button 
                          onClick={() => handleEditBlogClick(b)}
                          className="p-1.5 bg-indigo-50 dark:bg-indigo-950/30 hover:bg-indigo-100 text-indigo-650 rounded-lg transition cursor-pointer"
                          title="Edit article specs"
                        >
                          <Edit className="h-3 w-3" />
                        </button>
                        <button 
                          onClick={() => handleDeleteBlog(b.slug)}
                          className="p-1.5 bg-red-50 dark:bg-red-950/30 hover:bg-red-100 text-red-650 rounded-lg transition cursor-pointer"
                          title="Delete article permanently"
                        >
                          <Trash2 className="h-3 w-3" />
                        </button>
                      </div>
                    </div>
                  ))}
                  {blogs.length === 0 && (
                    <p className="text-xs text-slate-400 font-semibold text-center py-10">No editorial blogs found.</p>
                  )}
                </div>
              </div>

              <div className="bg-slate-50 dark:bg-slate-900/40 border border-slate-100 dark:border-slate-900 rounded-xl p-3.5 space-y-1.5 text-[10px] text-slate-500 mt-4 leading-relaxed font-semibold">
                <span className="font-bold uppercase text-slate-800 dark:text-slate-300 flex items-center gap-1">
                  <ShieldCheck className="h-3.5 w-3.5 text-indigo-500" /> Database Mirror Syncing
                </span>
                <p>Saved articles are directly merged onto the sitemap cache structures. Visitors will find published contents updated instantly.</p>
              </div>
            </div>

          </div>
        )}

        {/* TAB 4: Keywords & SEO Auditor */}
        {activeTab === "seo" && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Live SEO Density Audit Frame */}
            <div className="bg-white dark:bg-slate-950 border border-slate-150/80 dark:border-slate-800 rounded-2xl p-6 space-y-4 shadow-sm lg:col-span-2">
              <div className="border-b border-slate-100 dark:border-slate-900 pb-3">
                <h3 className="text-sm font-black text-slate-950 dark:text-slate-150 flex items-center gap-1.5">
                  <SearchCode className="h-4.5 w-4.5 text-indigo-500" /> Keyword Density Analyzer (SEO Crawler Simulation)
                </h3>
                <p className="text-xs text-slate-400 font-semibold">Verify compliance against keywords stuffing guidelines which trigger Google indexing blocks.</p>
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Target Keyword Focus Phrase</label>
                    <select
                      value={auditKeyword}
                      onChange={(e) => setAuditKeyword(e.target.value)}
                      className="w-full p-2.5 bg-white dark:bg-slate-900 border border-slate-205 dark:border-slate-800 rounded-xl text-xs font-semibold focus:outline-none focus:ring-1 text-slate-850 dark:text-slate-100"
                    >
                      {seoRules.map(r => (
                        <option key={r.id} value={r.keyword}>{r.keyword} ({r.categoryTarget} target)</option>
                      ))}
                      <option value="multi-utility suite">multi-utility suite</option>
                      <option value="privacy sandbox">privacy sandbox</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Analyzer Status Metrics</label>
                    <div className="p-2 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl flex items-center justify-between min-h-[38px] px-3.5">
                      <span className="text-[10px] font-bold text-slate-400">Computed Density:</span>
                      {densityResult !== null ? (
                        <span className={`text-xs font-black ${densityResult > 3.0 ? "text-red-500 animate-pulse" : densityResult >= 1.0 ? "text-[#22c55e]" : "text-amber-500"}`}>
                          {densityResult}% {densityResult > 3.0 ? "(Overstuffed!)" : densityResult >= 1.0 ? "(Ideal)" : "(Low)"}
                        </span>
                      ) : (
                        <span className="text-slate-400 text-[10px]">Provide text body...</span>
                      )}
                    </div>
                  </div>
                </div>

                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Copy-paste Editorial Body or Meta Title under simulation</label>
                  <textarea
                    rows={8}
                    value={auditText}
                    onChange={(e) => setAuditText(e.target.value)}
                    className="w-full p-3 bg-white dark:bg-slate-900 border border-slate-205 dark:border-slate-850 rounded-xl focus:outline-none focus:ring-1 text-slate-800 dark:text-slate-100 font-sans text-xs placeholder-gray-400"
                    placeholder="Paste your text copy right here to trigger scanning algorithms automatically..."
                  />
                </div>

                <div className="bg-slate-50 dark:bg-slate-905 border border-slate-100 dark:border-slate-850 rounded-xl p-4 text-xs font-semibold text-slate-500 dark:text-slate-400 space-y-2 leading-relaxed">
                  <h4 className="font-bold text-slate-850 dark:text-slate-200">Recommended Metrics:</h4>
                  <ul className="list-disc pl-5 space-y-0.5 text-[10px]">
                    <li>Ensure keyword density oscillates between **1.2% and 2.8%** maximum.</li>
                    <li>Always include focus keyphrases within the initial **150 characters** of description schemas.</li>
                    <li>Bypass crawler penalties by choosing synonyms rather than repeating titles.</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Keyword Density Guidelines Registry */}
            <div className="bg-white dark:bg-slate-950 border border-slate-150/80 dark:border-slate-800 rounded-2xl p-5 space-y-4 shadow-sm flex flex-col justify-between">
              <div>
                <h3 className="text-sm font-black text-slate-950 dark:text-slate-150 border-b border-slate-50 dark:border-slate-900 pb-2.5">
                  SEO Keywords Policies
                </h3>

                <form onSubmit={handleAddSeoRule} className="space-y-3 pt-3">
                  <div>
                    <label className="text-[9px] uppercase font-black text-slate-400 block mb-1">Add SEO Target Keyword</label>
                    <input
                      type="text" required
                      value={newSeoRule.keyword}
                      onChange={(e) => setNewSeoRule({ ...newSeoRule, keyword: e.target.value })}
                      placeholder="e.g., pdf layout compressor"
                      className="w-full p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs font-bold text-slate-800 dark:text-slate-200"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[9px] uppercase font-black text-slate-400 block mb-1">Density Target (%)</label>
                      <input
                        type="number" step="0.1" min="0.5" max="6.0"
                        value={newSeoRule.densityTarget}
                        onChange={(e) => setNewSeoRule({ ...newSeoRule, densityTarget: parseFloat(e.target.value) })}
                        className="w-full p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs font-bold text-slate-800 dark:text-slate-200"
                      />
                    </div>
                    <div>
                      <label className="text-[9px] uppercase font-black text-slate-400 block mb-1">Topic Channel</label>
                      <select
                        value={newSeoRule.categoryTarget}
                        onChange={(e) => setNewSeoRule({ ...newSeoRule, categoryTarget: e.target.value })}
                        className="w-full p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs font-bold text-slate-800 dark:text-slate-200"
                      >
                        <option value="pdf">PDF Tools</option>
                        <option value="image">Image Tools</option>
                        <option value="calculators">Calculators</option>
                        <option value="seo">SEO & Web</option>
                      </select>
                    </div>
                  </div>
                  <button
                    type="submit"
                    className="w-full py-2 bg-slate-900 hover:bg-slate-800 dark:bg-indigo-600 dark:hover:bg-indigo-505 text-white text-xs font-bold rounded-xl transition flex justify-center items-center gap-1 cursor-pointer select-none"
                  >
                    <Plus className="h-3.5 w-3.5" /> Register Keyword Target
                  </button>
                </form>

                {/* List of active SEO keyword density policies */}
                <div className="space-y-2.5 pt-4 max-h-[220px] overflow-y-auto">
                  {seoRules.map((rule) => (
                    <div 
                      key={rule.id}
                      className="p-2.5 border border-slate-100 dark:border-slate-900 rounded-xl flex items-center justify-between text-[11px] font-semibold bg-slate-50/10"
                    >
                      <div className="space-y-0.5">
                        <p className="font-bold text-slate-800 dark:text-slate-200 uppercase tracking-tight text-[10px]">{rule.keyword}</p>
                        <span className="text-[9px] text-slate-400">Target of {rule.densityTarget}% density · {rule.categoryTarget} category</span>
                      </div>
                      
                      <div className="flex gap-1 items-center select-none">
                        <button 
                          onClick={() => toggleSeoRuleStatus(rule.id)}
                          className={`p-1.5 rounded-lg transition overflow-hidden text-center cursor-pointer ${rule.status === "active" ? "bg-emerald-50 text-emerald-600" : "bg-slate-100 text-slate-400"}`}
                          title="Toggle active status"
                        >
                          <Check className="h-3.5 w-3.5" />
                        </button>
                        <button 
                          onClick={() => handleDeleteSeoRule(rule.id)}
                          className="p-1.5 bg-red-50 text-red-650 rounded-lg hover:bg-red-100 transition cursor-pointer"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-indigo-50/20 dark:bg-indigo-950/10 border border-indigo-200/50 dark:border-indigo-900/40 rounded-xl p-3 text-[10px] leading-relaxed text-slate-500 font-semibold mt-4">
                Structured scripts map indexing regulations. Modifying SEO settings automatically compiles metadata guidelines for search engine crawlers dynamically.
              </div>
            </div>

          </div>
        )}

      </div>

    </div>
  );
}
