import React, { useState } from "react";
import { ShieldCheck, HelpCircle, FileText, Send, Check } from "lucide-react";

interface StaticViewProps {
  pageType: "about" | "contact" | "privacy" | "terms" | "disclaimer";
}

export default function StaticView({ pageType }: StaticViewProps) {
  const [formData, setFormData] = useState({ name: "", email: "", msg: "" });
  const [isSent, setIsSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSent(true);
    setFormData({ name: "", email: "", msg: "" });
    setTimeout(() => setIsSent(false), 5000);
  };

  return (
    <div className="py-16 px-6 sm:px-10 lg:px-12 max-w-3xl mx-auto bg-white border border-slate-250 rounded-3xl shadow-sm my-12 text-slate-700 select-text">
      
      {/* 1. ABOUT INFO PAGE */}
      {pageType === "about" && (
        <div className="space-y-6">
          <h2 className="text-3xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <HelpCircle className="h-6.5 w-6.5 text-indigo-500" /> About MyToolsHub
          </h2>
          <p className="text-slate-600 text-sm leading-relaxed text-justify font-medium">
            MyToolsHub represents a modern evolutionary shift in how digital utility services are made available to creatives and web developers. Standard systems commonly drag confidential user assets, local spreadsheets, private images, and accounting details onto centralized servers, presenting security holes.
          </p>
          <p className="text-slate-600 text-sm leading-relaxed text-justify font-medium">
            Our platform solves this problem completely by shipping high-performance processing algorithms directly inside the client browser. Your actions—ranging from PDF compression to cryptographic password parameters generation—compute locally. MyToolsHub operates as a free, sustainable, programmatic sandbox funded by clean non-obstructive Google AdSense advertising.
          </p>
          <div className="bg-slate-50 border border-slate-100 rounded-2xl p-5 space-y-2.5">
            <h4 className="font-bold text-slate-800 text-sm">Core Engineering Pillars:</h4>
            <ul className="list-disc pl-5 text-slate-600 text-xs gap-2 space-y-1.5 font-semibold">
              <li><strong>Absolute Confidentiality</strong>: Records remain strictly inside your browser.</li>
              <li><strong>Speed First</strong>: Instant computations with no remote cloud latency.</li>
              <li><strong>Pristine UX Standards</strong>: Fluid layouts optimized to achieve 100 on Google’s Core Web Vitals.</li>
            </ul>
          </div>
        </div>
      )}

      {/* 2. CONTACT US FORM */}
      {pageType === "contact" && (
        <div className="space-y-6">
          <div className="space-y-2">
            <h2 className="text-3xl font-black text-slate-900 tracking-tight">Contact Administration</h2>
            <p className="text-sm text-slate-500 font-semibold">Have questions about sandbox security or AdSense? Complete our administrative contact form below.</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4 pt-4">
            <div>
              <label className="text-xs font-bold uppercase text-slate-500 block mb-1">Your Full Name</label>
              <input
                type="text" required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-indigo-500 text-slate-800 text-sm font-semibold"
                placeholder="John Doe"
              />
            </div>
            <div>
              <label className="text-xs font-bold uppercase text-slate-500 block mb-1">Your Email Address</label>
              <input
                type="email" required
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-indigo-500 text-slate-800 text-sm font-semibold"
                placeholder="john@example.com"
              />
            </div>
            <div>
              <label className="text-xs font-bold uppercase text-slate-500 block mb-1">Detailed Message</label>
              <textarea
                required rows={4}
                value={formData.msg}
                onChange={(e) => setFormData({ ...formData, msg: e.target.value })}
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-indigo-500 text-slate-800 text-sm font-sans placeholder-slate-400"
                placeholder="Type your message description..."
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <Send className="h-4 w-4" /> Send Information Message
            </button>
          </form>

          {isSent && (
            <div className="bg-emerald-50 border border-emerald-250 text-emerald-800 p-4 rounded-xl flex items-center gap-2 text-xs font-bold">
              <Check className="h-4.5 w-4.5 text-emerald-600" />
              <span>Message submitted successfully! An administrator will contact you soon.</span>
            </div>
          )}
        </div>
      )}

      {/* 3. PRIVACY SCHEMAS */}
      {pageType === "privacy" && (
        <div className="space-y-6">
          <h2 className="text-3xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <ShieldCheck className="h-6.5 w-6.5 text-indigo-500" /> Privacy Policy Guidelines
          </h2>
          <p className="text-xs text-slate-400 font-semibold bg-slate-50 px-2 py-1 rounded inline-block">Effective Date: May 28, 2026</p>
          
          <div className="space-y-6 text-slate-600 text-xs sm:text-sm leading-relaxed text-justify font-medium">
            <p>
              At MyToolsHub, accessible from our primary web domains, protecting user confidentiality stands as our primary objective. This Privacy Guidelines document addresses standard metrics cached or logged by our framework and clarifies AdSense conditions.
            </p>
            
            <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider pt-4">No Personal Files Collection</h3>
            <p>
              All core utility computations, PDF adjustments, and image conversions operate locally inside your browser client. We never upload, save, inspect, or catalog user documents onto remote clouds. Operations remain secure inside local memory structures.
            </p>
            
            <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider pt-4">Cookie & AdSense Usage</h3>
            <p>
              Third-party vendors, including Google, use cookie technologies to deliver relevant advertising based on user visits. You can disable interest-based advertisements directly inside your browser settings or via Google Privacy control lines.
            </p>
          </div>
        </div>
      )}

      {/* 4. TERMS AND USES */}
      {pageType === "terms" && (
        <div className="space-y-6">
          <h2 className="text-3xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <FileText className="h-6.5 w-6.5 text-indigo-500" /> Terms and Conditions
          </h2>
          <p className="text-xs text-slate-400 font-semibold bg-slate-50 px-2 py-1 rounded inline-block">Last Revised: May 28, 2026</p>
          
          <div className="space-y-6 text-slate-600 text-xs sm:text-sm leading-relaxed text-justify font-medium">
            <p>
              These Terms of Service outline standard rules governing utilization of the MyToolsHub system. By visiting and loading the tools, you signify complete acceptance of these compliance parameters.
            </p>
            
            <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider pt-4 font-bold">Sandbox Fair Use</h3>
            <p>
              User accounts are provided zero-cost access to all browser services. You agree not to attempt payload script injections, distributed network floods (DDoS), or automated data scraping of source codes.
            </p>
            
            <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider pt-4 font-bold">Disclaimers & Warranties</h3>
            <p>
              MyToolsHub services are served "as is" and "as available". We provide no contractual guarantees that calculations—ranging from compounding loan interest rates to student text counter margins—represent complete legal authority. Use of results is at your sole discretion.
            </p>
          </div>
        </div>
      )}

      {/* 5. REGULATORY DISCLAIMER */}
      {pageType === "disclaimer" && (
        <div className="space-y-6">
          <h2 className="text-3xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <FileText className="h-6.5 w-6.5 text-indigo-500" /> Regulatory Disclaimer
          </h2>
          <p className="text-xs text-slate-400 font-semibold bg-slate-50 px-2 py-1 rounded inline-block">Compliance Standard Notice</p>
          
          <div className="space-y-6 text-slate-600 text-xs sm:text-sm leading-relaxed text-justify font-medium">
            <p>
              The materials and interactive calculator metrics rendered across MyToolsHub are provided as standard educational references only. Under no parameters do our results—specifically GST calculations, SIP compound estimations, or BMI metrics—replace customized physical consultations or certified banking authority advices.
            </p>
            <p>
              We decline any liability for investment losses, loan adjustments, or accounting deficits arising directly from parameters extracted using our browser tools. Consult professional financial advisors before taking real-world actions.
            </p>
          </div>
        </div>
      )}

    </div>
  );
}
