import React, { useState } from "react";
import { ArrowLeft, Share2, Bookmark, ShieldAlert, Check, Clock, Zap, Laptop } from "lucide-react";
import { ToolData } from "../data/tools";
import ToolTemplates from "../components/ToolTemplates";
import SeoContainer from "../components/SeoContainer";
import AdPlacement from "../components/AdPlacement";
import ToolIcon from "../components/ToolIcon";

interface ToolViewProps {
  tool: ToolData;
  navigateTo: (page: string, slug?: string) => void;
}

export default function ToolView({ tool, navigateTo }: ToolViewProps) {
  const [copied, setCopied] = useState(false);
  const [favorite, setFavorite] = useState(false);

  const handleShareClick = () => {
    const url = window.location.href;
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => {
      setCopied(false);
    }, 3000);
  };

  return (
    <div className="py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-10 font-sans selection:bg-indigo-600 select-text">
      
      {/* Detailed SEO Breadcrumbs Chain Row */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigateTo("home")}
            className="inline-flex items-center gap-1 text-xs font-black text-slate-500 hover:text-slate-900 cursor-pointer select-none transition"
            title="Go to main board"
          >
            <ArrowLeft className="h-4 w-4" /> Back
          </button>
          <span className="text-slate-300 font-normal">|</span>
          <nav className="flex items-center space-x-2 text-[10px] font-extrabold uppercase tracking-widest text-slate-400 select-none">
            <button
              onClick={() => navigateTo("home")}
              className="hover:text-indigo-600 transition cursor-pointer"
            >
              Home
            </button>
            <span>&rarr;</span>
            <button
              onClick={() => {
                navigateTo("home");
                setTimeout(() => {
                  window.location.hash = `#/category/${tool.category}`;
                }, 50);
              }}
              className="hover:text-indigo-600 transition cursor-pointer"
            >
              {tool.category} utilities
            </button>
            <span>&rarr;</span>
            <span className="text-slate-700 normal-case font-bold">{tool.title}</span>
          </nav>
        </div>

        {/* Action utility hooks without window.alert */}
        <div className="flex gap-2 items-center shrink-0">
          <button 
            onClick={handleShareClick}
            className={`px-3 py-2 bg-white border rounded-xl hover:bg-slate-50 text-slate-700 transition flex items-center gap-1.5 text-xs font-bold cursor-pointer select-none ${copied ? "border-emerald-500 text-emerald-650 bg-emerald-50" : "border-slate-200"}`}
            title="CopyToClipboard Link"
          >
            {copied ? (
              <>
                <Check className="h-4 w-4 text-emerald-600 shrink-0" />
                <span className="text-emerald-750">Link Copied!</span>
              </>
            ) : (
              <>
                <Share2 className="h-4 w-4 shrink-0" />
                <span>Share Suite</span>
              </>
            )}
          </button>

          <button 
            onClick={() => setFavorite(!favorite)}
            className={`p-2 bg-white border rounded-xl hover:bg-slate-50 transition cursor-pointer ${favorite ? "border-amber-400 text-amber-600 bg-amber-50" : "border-slate-200 text-slate-500"}`}
            title="Save to Favorite list"
          >
            <Bookmark className={`h-4 w-4 ${favorite ? "fill-amber-500 text-amber-500" : ""}`} />
          </button>
        </div>
      </div>

      {/* 1. Header Hero Panel */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 relative overflow-hidden shadow-sm">
        {/* Ambient background blur dot */}
        <div className="absolute top-0 right-0 h-40 w-44 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col sm:flex-row gap-5 items-start sm:items-center relative z-10">
          <div className="p-3 bg-indigo-600 text-white rounded-xl shadow-sm shrink-0">
            <ToolIcon name={tool.icon} className="h-7 w-7" />
          </div>
          <div className="space-y-2 max-w-3xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[10px] uppercase font-extrabold tracking-wider px-2 py-0.5 bg-slate-100 text-slate-550 rounded">
                Category: {tool.category}
              </span>
              <span className="text-[10px] uppercase font-extrabold tracking-wider px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded border border-emerald-100">
                Processed Locally
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight leading-none">
              {tool.title}
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 leading-relaxed font-semibold">
              {tool.description}
            </p>
          </div>
        </div>
      </div>

      {/* Top Banner Ad Place */}
      <AdPlacement type="header" />

      {/* 2. Main Tool Playground Layout Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        {/* Playboard core workspace panel */}
        <div className="lg:col-span-3 space-y-8">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-[0_8px_30px_rgb(0,0,0,0.015)]">
            <ToolTemplates slug={tool.slug} title={tool.title} />
          </div>
          
          <AdPlacement type="content" label="Sponsored Safe Workspace Frame (iLovePDF High-Yield Layout Match)" />
        </div>

        {/* Right sidebar metrics details */}
        <div className="space-y-6">
          <div className="bg-white border border-slate-205 rounded-2xl p-6 space-y-4 shadow-sm">
            <h3 className="text-xs font-black uppercase tracking-widest text-slate-400">Sandbox Diagnostics</h3>
            
            <div className="space-y-3.5 text-xs font-semibold">
              <div className="flex justify-between items-center text-slate-600 pb-2 border-b border-slate-100">
                <span className="flex items-center gap-1"><Zap className="h-3.5 w-3.5 text-emerald-550" /> Compile Speed</span>
                <span className="font-extrabold text-emerald-600">0.01s (Instant)</span>
              </div>
              <div className="flex justify-between items-center text-slate-600 pb-2 border-b border-slate-100">
                <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5 text-slate-400" /> Cache state</span>
                <span className="font-extrabold text-slate-700">Active Wasm</span>
              </div>
              <div className="flex justify-between items-center text-slate-600 pb-2 border-b border-slate-100">
                <span className="flex items-center gap-1"><Check className="h-3.5 w-3.5 text-indigo-500" /> Security logs</span>
                <span className="font-extrabold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">Isolated</span>
              </div>
              <div className="flex justify-between items-center text-slate-600">
                <span className="flex items-center gap-1"><Laptop className="h-3.5 w-3.5 text-[#3b82f6]" /> Processing</span>
                <span className="font-extrabold text-slate-700">Client Memory</span>
              </div>
            </div>
          </div>

          {/* Clean disclaimer card */}
          <div className="bg-amber-50/50 border border-amber-200/60 rounded-2xl p-5 text-xs text-slate-605 font-semibold space-y-2">
            <h4 className="flex items-center gap-1.5 font-bold text-amber-800">
              <ShieldAlert className="h-4 w-4 shrink-0" /> Local Processing Notice
            </h4>
            <p className="leading-relaxed">
              No files are uploaded to foreign sitemaps. All optimizations are calculated within browser frames. Secure for company use.
            </p>
          </div>

          <AdPlacement type="sidebar" />
        </div>

      </div>

      {/* 3. Broad SEO Dynamic Content systems */}
      <SeoContainer tool={tool} navigateTo={navigateTo} />

    </div>
  );
}
