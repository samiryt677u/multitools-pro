import React from "react";
import { ArrowLeft, Calendar, Clock, BookOpen, Terminal, ArrowUpRight } from "lucide-react";
import { getStoredBlogs } from "../utils/storage";
import AdPlacement from "../components/AdPlacement";

interface BlogViewProps {
  slug?: string;
  navigateTo: (page: string, slug?: string) => void;
}

export default function BlogView({ slug, navigateTo }: BlogViewProps) {
  const blogs = getStoredBlogs();
  
  // Find current post if slug is valid
  const post = blogs.find((p) => p.slug === slug);

  // If viewing a single post
  if (post) {
    const relatedPosts = blogs.filter((p) => p.slug !== post.slug).slice(0, 3);

    return (
      <div className="py-12 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto space-y-12">
        
        {/* Navigation back header */}
        <button
          onClick={() => navigateTo("blog")}
          className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-slate-900 cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" /> Back to Blog Editorial
        </button>

        {/* Article Primary Content */}
        <article className="space-y-6">
          <div className="flex flex-wrap gap-2.5 items-center text-xs text-slate-500 font-semibold">
            <span className="px-2.5 py-1 bg-slate-100 text-slate-700 border border-slate-200 rounded font-bold uppercase">{post.category}</span>
            <span className="w-1 h-1 bg-slate-300 rounded-full" />
            <span className="flex items-center gap-1"><Calendar className="h-3.5 w-3.5" /> {post.date}</span>
            <span className="w-1 h-1 bg-slate-300 rounded-full" />
            <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5" /> {post.readTime}</span>
          </div>

          <h2 className="text-2xl sm:text-4xl font-black text-slate-900 tracking-tight leading-tight">
            {post.title}
          </h2>

          <p className="text-base sm:text-lg text-slate-600 italic leading-relaxed border-l-4 border-indigo-500 pl-4">
            {post.excerpt}
          </p>

          <AdPlacement type="header" />

          {/* Render raw strings clearly with rich spacing */}
          <div className="prose max-w-none text-slate-700 space-y-4 text-xs sm:text-sm md:text-base leading-relaxed pt-4">
            {post.content.split("\n\n").map((para, i) => {
              if (para.startsWith("###")) {
                return (
                  <h3 key={i} className="text-lg font-black text-slate-900 pt-6 flex items-center gap-2">
                    <Terminal className="h-4.5 w-4.5 text-indigo-500" /> {para.replace("###", "").trim()}
                  </h3>
                );
              }
              if (para.startsWith("-")) {
                return (
                  <ul key={i} className="list-disc pl-6 space-y-2 text-slate-600 font-medium my-4">
                    {para.split("\n").map((li, j) => (
                      <li key={j}>{li.replace("-", "").trim()}</li>
                    ))}
                  </ul>
                );
              }
              return <p key={i} className="text-slate-600 font-sans leading-relaxed text-justify">{para.trim()}</p>;
            })}
          </div>
        </article>

        {/* Sponsor line */}
        <AdPlacement type="content" label="Blog Footer Native Sponsor Frame (AdSense Compatible)" />

        {/* Related Posts Link Column */}
        {relatedPosts.length > 0 && (
          <div className="border-t border-slate-200 pt-12 space-y-6">
            <h3 className="text-base font-black text-slate-900 tracking-tight">More from learning channel</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {relatedPosts.map((rel) => (
                <div 
                  key={rel.slug}
                  onClick={() => navigateTo("blog", rel.slug)}
                  className="p-5 border border-slate-200 bg-white rounded-2xl hover:border-indigo-400 hover:shadow-md transition cursor-pointer flex flex-col justify-between shadow-sm"
                >
                  <div className="space-y-2">
                    <span className="text-[10px] font-bold uppercase text-slate-400">{rel.category}</span>
                    <h4 className="font-bold text-slate-800 text-xs leading-snug hover:text-indigo-650">{rel.title}</h4>
                  </div>
                  <span className="text-[10px] font-bold text-slate-500 mt-4 flex items-center gap-1">Read article <ArrowUpRight className="h-3 w-3" /></span>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    );
  }

  // Blog list view
  return (
    <div className="py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-12">
      
      <div className="text-center max-w-2xl mx-auto space-y-4">
        <h2 className="text-2xl sm:text-4xl font-black text-slate-900 tracking-tight font-display">The MyToolsHub Editorial</h2>
        <p className="text-xs sm:text-sm text-slate-500 leading-relaxed font-semibold">
          High fidelity articles and guidelines detailing digital productivity, meta tag optimizations, and organic Google crawling requirements.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-6">
        {blogs.map((bp) => (
          <article
            key={bp.slug}
            onClick={() => navigateTo("blog", bp.slug)}
            className="bg-white border border-slate-200 rounded-3xl p-6 hover:shadow-lg hover:border-indigo-400 transition flex flex-col justify-between cursor-pointer shadow-sm"
          >
            <div className="space-y-4">
              <span className="px-2 py-0.5 bg-slate-100 border border-slate-250 text-slate-600 rounded text-[10px] font-bold uppercase">{bp.category}</span>
              <h3 className="font-bold text-slate-800 text-base leading-snug hover:text-indigo-600">{bp.title}</h3>
              <p className="text-slate-500 text-xs leading-relaxed line-clamp-35 font-medium">{bp.excerpt}</p>
            </div>

            <div className="flex items-center justify-between text-[10px] text-slate-400 pt-6 mt-6 border-t border-slate-100">
              <span className="flex items-center gap-1"><Calendar className="h-3 w-3" /> {bp.date}</span>
              <span className="font-bold text-slate-500">{bp.readTime}</span>
            </div>
          </article>
        ))}
      </div>

    </div>
  );
}
